<?php
//__NM____NM__FUNCTION__NM__//
function populateClasses()
{
	
	sc_lookup(rs, "SELECT count(*) FROM classes");

	if(isset({rs[0][0]}) && {rs[0][0]} == '0')
	{
		$base_date_year  = date("Y");
		$base_date_month = date("m");
		
		$arr_sqls_inserts = array();
		switch([sc_glo_tpbanco])
		{
			case 'pdo_mysql':
			case 'mysql':
			case 'mysqlt':
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('1', '10', '1', 'ttt', null, null, '0', '$base_date_year-$base_date_month-02', '10:00:00', '$base_date_year-$base_date_month-03', '12:00:00', '1', 'Yearly Insider Trading: 10-01-2010, 10:00 am-Newton Conference Room', null, '$base_date_year-$base_date_month-17 14:48:34', '16', '4', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('2', '15', '1', 'clacerda@gmail.com', null, null, '2', '$base_date_year-$base_date_month-03', '10:00:00', '$base_date_year-$base_date_month-15', '12:00:00', '3', 'SOX Compliance: 10-05-2010, 9:00 am-Peter Lacrosse Field', null, '$base_date_year-$base_date_month-17 14:48:47', '16', '2', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('3', '13', '1', 'ttt', null, null, '1', '$base_date_year-$base_date_month-04', '10:00:00', '$base_date_year-$base_date_month-22', '12:00:00', '0', 'Building a Perfect Presentation: 10-11-2010, 9:00 am-Amys Hotel and Casino', null, '$base_date_year-$base_date_month-17 14:49:00', '16', '3', '1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('4', '15', '2', 'example_ColleenGarton', null, null, '3', '$base_date_year-$base_date_month-07', '10:00:00', '$base_date_year-$base_date_month-23', '12:00:00', '0', 'Acronyms, the Organization and You: 10-07-2010, 10:00 am-Bills Windsurf Shop', null, '$base_date_year-$base_date_month-23 14:56:44', '17', '2', '1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('5', '1000', '1', 'ttt', null, null, '0', '$base_date_year-$base_date_month-04', '10:00:00', '$base_date_year-$base_date_month-25', '12:00:00', '1', 'Sexual Harrassment - Just Say No:', null, '$base_date_year-$base_date_month-17 14:50:55', '17', '3', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('6', '20', '1', 'clacerda@gmail.com', null, null, '0', '$base_date_year-$base_date_month-18', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '1', 'Sexual Harrassment - Just Say No: 12-04-2010, 9:00 am-Eric Stadium', null, '$base_date_year-$base_date_month-11 10:05:03', '17', '6', '8')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('7', '15', '1', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'Just an insetion test!!', '$base_date_year-$base_date_month-17 11:00:47', null, '16', '3', '1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('8', '20', '1', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '1', 'This is our first class in how to create a perfect presentation, dont miss it.', '$base_date_year-$base_date_month-22 16:38:25', null, '16', '4', '8')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('9', '30', '1', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'Just an insertion test!', '$base_date_year-$base_date_month-23 11:55:52', null, '16', '5', '6')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('10', '25', '2', '', null, null, '0', '$base_date_year-$base_date_month-24', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'Just some lessons about phone skills, don\'t miss it.', '$base_date_year-$base_date_month-24 15:53:09', null, '17', '7', '7')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('11', '20', '2', '', null, null, '0', '$base_date_year-$base_date_month-25', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'Some sport lessons for young children.', '$base_date_year-$base_date_month-24 15:54:10', null, '16', '6', '5')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('12', '15', '1', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'How to use MySQL', '$base_date_year-$base_date_month-25 15:45:12', null, '17', '8', '3')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('13', '15', '1', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'Advanced PHP', '$base_date_year-$base_date_month-26 09:12:04', null, '16', '3', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('14', '50', '1', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'Project Management with PMBOK', '$base_date_year-$base_date_month-26 09:12:24', null, '16', '3', '3')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('15', '30', '1', '', null, null, '0', '$base_date_year-$base_date_month-15', '12:00:00', '$base_date_year-$base_date_month-16', '16:00:00', '0', 'Helping you to inprove your helpdesk skills', '$base_date_year-$base_date_month-11 10:06:56', null, '17', '8', '4')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `classes` VALUES ('16', '60', '2', '', null, null, '0', '$base_date_year-$base_date_month-01', '12:00:00', '$base_date_year-$base_date_month-05', '14:00:00', '0', 'Don\'t be late!', '$base_date_year-$base_date_month-11 15:10:27', null, '17', '9', '1')
EOT;
			break;
			
			case 'pdosqlite':
			case 'sqlite':
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (1, 10, 1, 'ttt', null, null, 0, '$base_date_year-$base_date_month-02', '10:00:00', '$base_date_year-$base_date_month-03', '12:00:00', 1, 'Yearly Insider Trading: 10-01-2010, 10:00 am-Newton Conference Room', null, '$base_date_year-$base_date_month-17 14:48:34', 16, 4, 2)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (2, 15, 1, 'clacerda@gmail.com', null, null, 2, '$base_date_year-$base_date_month-03', '10:00:00', '$base_date_year-$base_date_month-15', '12:00:00', 3, 'SOX Compliance: 10-05-2010, 9:00 am-Peter Lacrosse Field', null, '$base_date_year-$base_date_month-17 14:48:47', 16, 2, 2)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (3, 13, 1, 'ttt', null, null, 1, '$base_date_year-$base_date_month-04', '10:00:00', '$base_date_year-$base_date_month-22', '12:00:00', 0, 'Building a Perfect Presentation: 10-11-2010, 9:00 am-Amys Hotel and Casino', null, '$base_date_year-$base_date_month-17 14:49:00', 16, 3, 1)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (4, 15, 2, 'example_ColleenGarton', null, null, 3, '$base_date_year-$base_date_month-07', '10:00:00', '$base_date_year-$base_date_month-23', '12:00:00', 0, 'Acronyms, the Organization and You: 10-07-2010, 10:00 am-Bills Windsurf Shop', null, '$base_date_year-$base_date_month-23 14:56:44', 17, 2, 1)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (5, 1000, 1, 'ttt', null, null, 0, '$base_date_year-$base_date_month-04', '10:00:00', '$base_date_year-$base_date_month-25', '12:00:00', 1, 'Sexual Harrassment - Just Say No:', null, '$base_date_year-$base_date_month-17 14:50:55', 17, 3, 2)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (6, 15, 1, 'clacerda@gmail.com', null, null, 0, '$base_date_year-$base_date_month-18', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 1, 'Sexual Harrassment - Just Say No: 12-04-2010, 9:00 am-Eric Stadium', null, '$base_date_year-$base_date_month-17 14:51:13', 17, 7, 8)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (7, 15, 1, '', null, null, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'Just an insetion test!!', '$base_date_year-$base_date_month-17 11:00:47', null, 16, 3, 1)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (8, 20, 1, '', null, null, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 1, 'This is our first class in how to create a perfect presentation, dont miss it.', '$base_date_year-$base_date_month-22 16:38:25', null, 16, 4, 8)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (9, 30, 1, '', null, null, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'Just an insertion test!', '$base_date_year-$base_date_month-23 11:55:52', null, 16, 5, 6)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (10, 25, 2, '', null, null, 0, '$base_date_year-$base_date_month-24', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'Just some lessons about phone skills, dont miss it.', '$base_date_year-$base_date_month-24 15:53:09', null, 17, 7, 7)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (11, 20, 2, '', null, null, 0, '$base_date_year-$base_date_month-25', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'Some sport lessons for young children.', '$base_date_year-$base_date_month-24 15:54:10', null, 16, 6, 5)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (12, 15, 1, '', null, null, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'aaa', '$base_date_year-$base_date_month-25 15:45:12', null, 17, 8, 3)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (13, 15, 1, '', null, null, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'testing', '$base_date_year-$base_date_month-26 09:12:04', null, 16, 3, 2)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (14, 50, 1, '', null, null, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'testing too', '$base_date_year-$base_date_month-26 09:12:24', null, 16, 3, 3)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (15, 50, 1, '', null, null, 0, '$base_date_year-$base_date_month-01', '13:00:00:000', '$base_date_year-$base_date_month-31', '12:00:00:000', 0, 'This course has the purpose of teaching the clients in how to manage a Support Center.', '$base_date_year-$base_date_month-31 16:39:49', null, 17, 6, 6)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "classes" VALUES (16, 15, 1, '', null, null, 0, '$base_date_year-$base_date_month-01', '12:00:00:000', '$base_date_year-$base_date_month-14', '16:00:00:000', 0, 'omg!', '$base_date_year-$base_date_month-14 14:33:11', null, 16, 9, 6)
EOT;
			break;
			
			case 'access':
			case 'ado_access':
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 1,10,1,'ttt',NULL,NULL,0,#$base_date_year-$base_date_month-02#,'10:00:00',#$base_date_year-$base_date_month-03#,'12:00:00',1,'Yearly Insider Trading: 10-01-2010, 10:00 am-Newton Conference Room',NULL,#$base_date_year-$base_date_month-17 14:48:34#,16,4,2
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 2,15,1,'clacerda@gmail.com',NULL,NULL,2,#$base_date_year-$base_date_month-03#,'10:00:00',#$base_date_year-$base_date_month-15#,'12:00:00',3,'SOX Compliance: 10-05-2010, 9:00 am-Peter Lacrosse Field',NULL,#$base_date_year-$base_date_month-17 14:48:47#,16,2,2
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 3,13,1,'ttt',NULL,NULL,1,#$base_date_year-$base_date_month-04#,'10:00:00',#$base_date_year-$base_date_month-22#,'12:00:00',0,'Building a Perfect Presentation: 10-11-2010, 9:00 am-Amys Hotel and Casino',NULL,#$base_date_year-$base_date_month-17 14:49:00#,16,3,1
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 4,15,2,'example_ColleenGarton',NULL,NULL,3,#$base_date_year-$base_date_month-07#,'10:00:00',#$base_date_year-$base_date_month-23#,'12:00:00',0,'Acronyms, the Organization and You: 10-07-2010, 10:00 am-Bills Windsurf Shop',NULL,#$base_date_year-$base_date_month-23 14:56:44#,17,2,1
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 5,1000,1,'ttt',NULL,NULL,0,#$base_date_year-$base_date_month-04#,'10:00:00',#$base_date_year-$base_date_month-25#,'12:00:00',1,'Sexual Harrassment - Just Say No:',NULL,#$base_date_year-$base_date_month-17 14:50:55#,17,3,2
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 6,20,1,'clacerda@gmail.com',NULL,NULL,0,#$base_date_year-$base_date_month-18#,'10:00:00',#$base_date_year-$base_date_month-18#,'12:00:00',1,'Sexual Harrassment - Just Say No: 12-04-2010, 9:00 am-Eric Stadium',NULL,#$base_date_year-$base_date_month-11 10:05:03#,17,6,8
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 7,15,1,'',NULL,NULL,0,#$base_date_year-$base_date_month-17#,'10:00:00',#$base_date_year-$base_date_month-18#,'12:00:00',0,'Just an insetion test!!',#$base_date_year-$base_date_month-17 11:00:47#,NULL,16,3,1
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 8,20,1,'',NULL,NULL,0,#$base_date_year-$base_date_month-17#,'10:00:00',#$base_date_year-$base_date_month-18#,'12:00:00',1,'This is our first class in how to create a perfect presentation, dont miss it.',#$base_date_year-$base_date_month-22 16:38:25#,NULL,16,4,8
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 9,30,1,'',NULL,NULL,0,#$base_date_year-$base_date_month-17#,'10:00:00',#$base_date_year-$base_date_month-18#,'12:00:00',0,'Just an insertion test!',#$base_date_year-$base_date_month-23 11:55:52#,NULL,16,5,6
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 10,25,2,'',NULL,NULL,0,#$base_date_year-$base_date_month-24#,'10:00:00',#$base_date_year-$base_date_month-18#,'12:00:00',0,'Just some lessons about phone skills, don''t miss it.',#$base_date_year-$base_date_month-24 15:53:09#,NULL,17,7,7
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 11,20,2,'',NULL,NULL,0,#$base_date_year-$base_date_month-25#,'10:00:00',#$base_date_year-$base_date_month-18#,'12:00:00',0,'Some sport lessons for young children.',#$base_date_year-$base_date_month-24 15:54:10#,NULL,16,6,5
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 12,15,1,'',NULL,NULL,0,#$base_date_year-$base_date_month-17#,'10:00:00',#$base_date_year-$base_date_month-18#,'12:00:00',0,'aaa',#$base_date_year-$base_date_month-25 15:45:12#,NULL,17,8,3
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 13,15,1,'',NULL,NULL,0,#$base_date_year-$base_date_month-17#,'10:00:00',#$base_date_year-$base_date_month-18#,'12:00:00',0,'testing',#$base_date_year-$base_date_month-26 09:12:04#,NULL,16,3,2
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 14,50,1,'',NULL,NULL,0,#$base_date_year-$base_date_month-17#,'10:00:00',#$base_date_year-$base_date_month-18#,'12:00:00',0,'testing too',#$base_date_year-$base_date_month-26 09:12:24#,NULL,16,3,3
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 15,30,1,'',NULL,NULL,0,#$base_date_year-$base_date_month-15#,'12:00:00',#$base_date_year-$base_date_month-16#,'16:00:00',0,'Helping you to inprove your helpdesk skills',#$base_date_year-$base_date_month-11 10:06:56#,NULL,17,8,4
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into classes(id_classes,class_size,status,instructor,start_date_time,end_date_time,confirmed_reservations,start_date,start_time,end_date,end_time,pending_reservations,class_information,date_created,date_modified,id_instructor,id_curso,id_venues)select 16,60,2,'',NULL,NULL,0,#$base_date_year-$base_date_month-01#,'12:00:00',#$base_date_year-$base_date_month-05#,'14:00:00',0,'Don''t be late!',#$base_date_year-$base_date_month-11 15:10:27#,NULL,17,9,1
EOT;
			break;
			
			case 'postgres7':
			case 'pdo_pgsql':
			case 'postgres64':
			case 'postgres':
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('1', '10', '2', 'ttt', null, null, '0', '$base_date_year-$base_date_month-02', '10:00:00', '$base_date_year-$base_date_month-03', '12:00:00', '1', 'Yearly Insider Trading: 10-01-2010, 10:00 am-Newton Conference Room', null, '$base_date_year-$base_date_month-17 14:48:34', '16', '4', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('2', '15', '2', 'clacerda@gmail.com', null, null, '2', '$base_date_year-$base_date_month-03', '10:00:00', '$base_date_year-$base_date_month-15', '12:00:00', '3', 'SOX Compliance: 10-05-2010, 9:00 am-Peter Lacrosse Field', null, '$base_date_year-$base_date_month-17 14:48:47', '16', '2', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('3', '13', '2', 'ttt', null, null, '1', '$base_date_year-$base_date_month-04', '10:00:00', '$base_date_year-$base_date_month-22', '12:00:00', '0', 'Building a Perfect Presentation: 10-11-2010, 9:00 am-Amys Hotel and Casino', null, '$base_date_year-$base_date_month-17 14:49:00', '16', '3', '1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('4', '15', '2', 'example_ColleenGarton', null, null, '3', '$base_date_year-$base_date_month-07', '10:00:00', '$base_date_year-$base_date_month-23', '12:00:00', '0', 'Acronyms, the Organization and You: 10-07-2010, 10:00 am-Bills Windsurf Shop', null, '$base_date_year-$base_date_month-23 14:56:44', '17', '2', '1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('5', '1000', '2', 'ttt', null, null, '0', '$base_date_year-$base_date_month-04', '10:00:00', '$base_date_year-$base_date_month-25', '12:00:00', '1', 'Sexual Harrassment - Just Say No:', null, '$base_date_year-$base_date_month-17 14:50:55', '17', '3', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('6', '20', '2', 'clacerda@gmail.com', null, null, '0', '$base_date_year-$base_date_month-18', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '1', 'Sexual Harrassment - Just Say No: 12-04-2010, 9:00 am-Eric Stadium', null, '$base_date_year-$base_date_month-11 10:05:03', '17', '6', '8')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('7', '15', '2', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'Just an insetion test!!', '$base_date_year-$base_date_month-17 11:00:47', null, '16', '3', '1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('8', '20', '2', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '1', 'This is our first class in how to create a perfect presentation, dont miss it.', '$base_date_year-$base_date_month-22 16:38:25', null, '16', '4', '8')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('9', '30', '2', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'Just an insertion test!', '$base_date_year-$base_date_month-23 11:55:52', null, '16', '5', '6')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('10', '25', '2', '', null, null, '0', '$base_date_year-$base_date_month-24', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'Just some lessons about phone skills, don''t miss it.', '$base_date_year-$base_date_month-24 15:53:09', null, '17', '7', '7')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('11', '20', '2', '', null, null, '0', '$base_date_year-$base_date_month-25', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'Some sport lessons for young children.', '$base_date_year-$base_date_month-24 15:54:10', null, '16', '6', '5')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('12', '15', '2', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'aaa', '$base_date_year-$base_date_month-25 15:45:12', null, '17', '8', '3')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('13', '15', '2', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'testing', '$base_date_year-$base_date_month-26 09:12:04', null, '16', '3', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('14', '50', '2', '', null, null, '0', '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', '0', 'testing too', '$base_date_year-$base_date_month-26 09:12:24', null, '16', '3', '3')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('15', '30', '2', '', null, null, '0', '$base_date_year-$base_date_month-15', '12:00:00', '$base_date_year-$base_date_month-16', '16:00:00', '0', 'Helping you to inprove your helpdesk skills', '$base_date_year-$base_date_month-11 10:06:56', null, '17', '8', '4')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('16', '60', '2', '', null, null, '0', '$base_date_year-$base_date_month-01', '12:00:00', '$base_date_year-$base_date_month-05', '14:00:00', '0', 'Don''t be late!', '$base_date_year-$base_date_month-11 15:10:27', null, '17', '9', '1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('17', '10', '2', '', null, null, '0', '$base_date_year-$base_date_month-11', '12:00:00', '$base_date_year-$base_date_month-13', '16:00:00', '0', '123123', '$base_date_year-$base_date_month-10 18:00:06', null, '16', '2', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('18', '666', '1', '', null, null, '0', '$base_date_year-$base_date_month-07', '16:16:00', '$base_date_year-$base_date_month-28', '21:21:00', '0', '123213', '$base_date_year-$base_date_month-10 18:08:57', null, '17', '2', '6')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('19', '100', '1', '', null, null, '0', '$base_date_year-$base_date_month-12', '12:00:00', '$base_date_year-$base_date_month-12', '14:00:00', '0', 'asdasd', '$base_date_year-$base_date_month-11 09:55:41', null, '17', '7', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."classes" VALUES ('20', '15', '1', '', null, null, '0', '$base_date_year-$base_date_month-15', '12:00:00', '$base_date_year-$base_date_month-20', '14:00:00', '0', 'lol', '$base_date_year-$base_date_month-11 09:56:26', null, '17', '4', '6')
EOT;
			break;
			
			case 'oci805':
			case 'odbc_oracle':
			case 'oci8':
			case 'oci8po':
			case 'oracle':
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('1', '10', '1', 'ttt', null, null, '0', TO_DATE('$base_date_year-$base_date_month-02 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-03 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '1', 'Yearly Insider Trading: 10-01-2010, 10:00 am-Newton Conference Room', null, TO_DATE('$base_date_year-$base_date_month-17 14:48:34', 'YYYY-MM-DD HH24:MI:SS'), '16', '4', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('2', '15', '1', 'clacerda@gmail.com', null, null, '2', TO_DATE('$base_date_year-$base_date_month-03 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-15 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '3', 'SOX Compliance: 10-05-2010, 9:00 am-Peter Lacrosse Field', null, TO_DATE('$base_date_year-$base_date_month-17 14:48:47', 'YYYY-MM-DD HH24:MI:SS'), '16', '2', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('3', '13', '1', 'ttt', null, null, '1', TO_DATE('$base_date_year-$base_date_month-04 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-22 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '0', 'Building a Perfect Presentation: 10-11-2010, 9:00 am-Amys Hotel and Casino', null, TO_DATE('$base_date_year-$base_date_month-17 14:49:00', 'YYYY-MM-DD HH24:MI:SS'), '16', '3', '1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('4', '15', '2', 'example_ColleenGarton', null, null, '3', TO_DATE('$base_date_year-$base_date_month-07 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-23 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '0', 'Acronyms, the Organization and You: 10-07-2010, 10:00 am-Bills Windsurf Shop', null, TO_DATE('$base_date_year-$base_date_month-23 14:56:44', 'YYYY-MM-DD HH24:MI:SS'), '17', '2', '1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('5', '1000', '1', 'ttt', null, null, '0', TO_DATE('$base_date_year-$base_date_month-04 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-25 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '1', 'Sexual Harrassment - Just Say No:', null, TO_DATE('$base_date_year-$base_date_month-17 14:50:55', 'YYYY-MM-DD HH24:MI:SS'), '17', '3', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('6', '20', '1', 'clacerda@gmail.com', null, null, '0', TO_DATE('$base_date_year-$base_date_month-18 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-18 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '1', 'Sexual Harrassment - Just Say No: 12-04-2010, 9:00 am-Eric Stadium', null, TO_DATE('$base_date_year-$base_date_month-11 10:05:03', 'YYYY-MM-DD HH24:MI:SS'), '17', '6', '8')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('7', '15', '1', null, null, null, '0', TO_DATE('$base_date_year-$base_date_month-17 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-18 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '0', 'Just an insetion test!!', TO_DATE('$base_date_year-$base_date_month-17 11:00:47', 'YYYY-MM-DD HH24:MI:SS'), null, '16', '3', '1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('8', '20', '1', null, null, null, '0', TO_DATE('$base_date_year-$base_date_month-17 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-18 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '1', 'This is our first class in how to create a perfect presentation, dont miss it.', TO_DATE('$base_date_year-$base_date_month-22 16:38:25', 'YYYY-MM-DD HH24:MI:SS'), null, '16', '4', '8')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('9', '30', '1', null, null, null, '0', TO_DATE('$base_date_year-$base_date_month-17 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-18 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '0', 'Just an insertion test!', TO_DATE('$base_date_year-$base_date_month-23 11:55:52', 'YYYY-MM-DD HH24:MI:SS'), null, '16', '5', '6')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('10', '25', '2', null, null, null, '0', TO_DATE('$base_date_year-$base_date_month-24 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-18 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '0', 'Just some lessons about phone skills, don''t miss it.', TO_DATE('$base_date_year-$base_date_month-24 15:53:09', 'YYYY-MM-DD HH24:MI:SS'), null, '17', '7', '7')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('11', '20', '2', null, null, null, '0', TO_DATE('$base_date_year-$base_date_month-25 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-18 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '0', 'Some sport lessons for young children.', TO_DATE('$base_date_year-$base_date_month-24 15:54:10', 'YYYY-MM-DD HH24:MI:SS'), null, '16', '6', '5')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('12', '15', '1', null, null, null, '0', TO_DATE('$base_date_year-$base_date_month-17 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-18 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '0', 'aaa', TO_DATE('$base_date_year-$base_date_month-25 15:45:12', 'YYYY-MM-DD HH24:MI:SS'), null, '17', '8', '3')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('13', '15', '1', null, null, null, '0', TO_DATE('$base_date_year-$base_date_month-17 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-18 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '0', 'testing', TO_DATE('$base_date_year-$base_date_month-26 09:12:04', 'YYYY-MM-DD HH24:MI:SS'), null, '16', '3', '2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('14', '50', '1', null, null, null, '0', TO_DATE('$base_date_year-$base_date_month-17 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-18 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), '0', 'testing too', TO_DATE('$base_date_year-$base_date_month-26 09:12:24', 'YYYY-MM-DD HH24:MI:SS'), null, '16', '3', '3')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('15', '30', '1', null, null, null, '0', TO_DATE('$base_date_year-$base_date_month-15 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-16 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 16:00:00', 'YYYY-MM-DD HH24:MI:SS'), '0', 'Helping you to inprove your helpdesk skills', TO_DATE('$base_date_year-$base_date_month-11 10:06:56', 'YYYY-MM-DD HH24:MI:SS'), null, '17', '8', '4')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES VALUES ('16', '60', '2', null, null, null, '0', TO_DATE('$base_date_year-$base_date_month-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-05 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-01 14:00:00', 'YYYY-MM-DD HH24:MI:SS'), '0', 'Don''t be late!', TO_DATE('$base_date_year-$base_date_month-11 15:10:27', 'YYYY-MM-DD HH24:MI:SS'), null, '17', '9', '1')
EOT;
			break;
			
			case 'borland_ibase';
			case 'ibase';
			case 'firebird';
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (1, 10, 1, 'ttt', NULL, NULL, 0, '$base_date_year-$base_date_month-02', '10:00:00', '$base_date_year-$base_date_month-03', '12:00:00', 1, 'Yearly Insider Trading: 10-01-2010, 10:00 am-Newton Conference Room', NULL, '$base_date_year-$base_date_month-17 14:48:34', 16, 4, 2)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (2, 15, 1, 'clacerda@gmail.com', NULL, NULL, 2, '$base_date_year-$base_date_month-03', '10:00:00', '$base_date_year-$base_date_month-15', '12:00:00', 3, 'SOX Compliance: 10-05-2010, 9:00 am-Peter Lacrosse Field', NULL, '$base_date_year-$base_date_month-17 14:48:47', 16, 2, 2)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (3, 13, 1, 'ttt', NULL, NULL, 1, '$base_date_year-$base_date_month-04', '10:00:00', '$base_date_year-$base_date_month-22', '12:00:00', 0, 'Building a Perfect Presentation: 10-11-2010, 9:00 am-Amys Hotel and Casino', NULL, '$base_date_year-$base_date_month-17 14:49:00', 16, 3, 1)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (4, 15, 2, 'example_ColleenGarton', NULL, NULL, 3, '$base_date_year-$base_date_month-07', '10:00:00', '$base_date_year-$base_date_month-23', '12:00:00', 0, 'Acronyms, the Organization and You: 10-07-2010, 10:00 am-Bills Windsurf Shop', NULL, '$base_date_year-$base_date_month-23 14:56:44', 17, 2, 1)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (5, 1000, 1, 'ttt', NULL, NULL, 0, '$base_date_year-$base_date_month-04', '10:00:00', '$base_date_year-$base_date_month-25', '12:00:00', 1, 'Sexual Harrassment - Just Say No:', NULL, '$base_date_year-$base_date_month-17 14:50:55', 17, 3, 2)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (6, 20, 1, 'clacerda@gmail.com', NULL, NULL, 0, '$base_date_year-$base_date_month-18', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 1, 'Sexual Harrassment - Just Say No: 12-04-2010, 9:00 am-Eric Stadium', NULL, '$base_date_year-$base_date_month-11 10:05:03', 17, 6, 8)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (7, 15, 1, '', NULL, NULL, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'Just an insetion test!!', '$base_date_year-$base_date_month-17 11:00:47', NULL, 16, 3, 1)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (8, 20, 1, '', NULL, NULL, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 1, 'This is our first class in how to create a perfect presentation, dont miss it.', '$base_date_year-$base_date_month-22 16:38:25', NULL, 16, 4, 8)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (9, 30, 1, '', NULL, NULL, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'Just an insertion test!', '$base_date_year-$base_date_month-23 11:55:52', NULL, 16, 5, 6)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (10, 25, 2, '', NULL, NULL, 0, '$base_date_year-$base_date_month-24', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'Just some lessons about phone skills, dont miss it.', '$base_date_year-$base_date_month-24 15:53:09', NULL, 17, 7, 7)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (11, 20, 2, '', NULL, NULL, 0, '$base_date_year-$base_date_month-25', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'Some sport lessons for young children.', '$base_date_year-$base_date_month-24 15:54:10', NULL, 16, 6, 5)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (12, 15, 1, '', NULL, NULL, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'How to use MySQL', '$base_date_year-$base_date_month-25 15:45:12', NULL, 17, 8, 3)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (13, 15, 1, '', NULL, NULL, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'Advanced PHP', '$base_date_year-$base_date_month-26 09:12:04', NULL, 16, 3, 2)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (14, 50, 1, '', NULL, NULL, 0, '$base_date_year-$base_date_month-17', '10:00:00', '$base_date_year-$base_date_month-18', '12:00:00', 0, 'Project Management with PMBOK', '$base_date_year-$base_date_month-26 09:12:24', NULL, 16, 3, 3)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (15, 30, 1, '', NULL, NULL, 0, '$base_date_year-$base_date_month-15', '12:00:00', '$base_date_year-$base_date_month-16', '16:00:00', 0, 'Helping you to inprove your helpdesk skills', '$base_date_year-$base_date_month-11 10:06:56', NULL, 17, 8, 4)
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO CLASSES
VALUES (16, 60, 2, '', NULL, NULL, 0, '$base_date_year-$base_date_month-01', '12:00:00', '$base_date_year-$base_date_month-05', '14:00:00', 0, 'Dont be late!', '$base_date_year-$base_date_month-11 15:10:27', NULL, 17, 9, 1)
EOT;
			
			case 'ado_mssql':
			case 'pdo_sqlsrv':
			case 'mssqlnative':
			case 'odbc_mssql':
			case 'mssql':

			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'1', N'10', N'1', N'ttt', N'$base_date_year-$base_date_month-02 10:00:00.000', N'$base_date_year-$base_date_month-03 12:00:00.000', N'0', N'$base_date_year-$base_date_month-02 10:00:00.000', N'$base_date_year-$base_date_month-02 10:00:00.000', N'$base_date_year-$base_date_month-03 12:00:00.000', N'$base_date_year-$base_date_month-03 12:00:00.000', N'1', N'Yearly Insider Trading: 10-01-2010, 10:00 am-Newton Conference Room', null, N'$base_date_year-$base_date_month-17 14:48:34.000', N'16', N'4', N'2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'2', N'15', N'1', N'clacerda@gmail.com', N'$base_date_year-$base_date_month-03 10:00:00.000', N'$base_date_year-$base_date_month-15 12:00:00.000', N'2', N'$base_date_year-$base_date_month-03 10:00:00.000', N'$base_date_year-$base_date_month-03 10:00:00.000', N'$base_date_year-$base_date_month-15 12:00:00.000', N'$base_date_year-$base_date_month-15 12:00:00.000', N'3', N'SOX Compliance: 10-05-2010, 9:00 am-Peter Lacrosse Field', null, N'$base_date_year-$base_date_month-17 14:48:47.000', N'16', N'2', N'2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'3', N'13', N'1', N'ttt', N'$base_date_year-$base_date_month-04 10:00:00.000', N'$base_date_year-$base_date_month-22 12:00:00.000', N'1', N'$base_date_year-$base_date_month-04 10:00:00.000', N'$base_date_year-$base_date_month-04 10:00:00.000', N'$base_date_year-$base_date_month-22 12:00:00.000', N'$base_date_year-$base_date_month-22 12:00:00.000', N'0', N'Building a Perfect Presentation: 10-11-2010, 9:00 am-Amys Hotel and Casino', null, N'$base_date_year-$base_date_month-17 14:49:00.000', N'16', N'3', N'1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'4', N'15', N'2', N'example_ColleenGarton', N'$base_date_year-$base_date_month-07 10:00:00.000', N'$base_date_year-$base_date_month-23 12:00:00.000', N'3', N'$base_date_year-$base_date_month-07 10:00:00.000', N'$base_date_year-$base_date_month-07 10:00:00.000', N'$base_date_year-$base_date_month-23 12:00:00.000', N'$base_date_year-$base_date_month-23 12:00:00.000', N'0', N'Acronyms, the Organization and You: 10-07-2010, 10:00 am-Bills Windsurf Shop', null, N'$base_date_year-$base_date_month-23 14:56:44.000', N'17', N'2', N'1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'5', N'1000', N'1', N'ttt', N'$base_date_year-$base_date_month-04 10:00:00.000', N'$base_date_year-$base_date_month-25 12:00:00.000', N'0', N'$base_date_year-$base_date_month-04 10:00:00.000', N'$base_date_year-$base_date_month-04 10:00:00.000', N'$base_date_year-$base_date_month-25 12:00:00.000', N'$base_date_year-$base_date_month-25 12:00:00.000', N'1', N'Sexual Harrassment - Just Say No:', null, N'$base_date_year-$base_date_month-17 14:50:55.000', N'17', N'3', N'2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'6', N'20', N'1', N'clacerda@gmail.com', N'$base_date_year-$base_date_month-18 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'$base_date_year-$base_date_month-18 10:00:00.000', N'$base_date_year-$base_date_month-18 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'1', N'Sexual Harrassment - Just Say No: 12-04-2010, 9:00 am-Eric Stadium', null, N'$base_date_year-$base_date_month-11 10:05:03.000', N'17', N'6', N'8')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'7', N'15', N'1', N'', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'Just an insetion test!!', N'$base_date_year-$base_date_month-17 11:00:47.000', null, N'16', N'3', N'1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'8', N'20', N'1', N'', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'1', N'This is our first class in how to create a perfect presentation, dont miss it.', N'$base_date_year-$base_date_month-22 16:38:25.000', null, N'16', N'4', N'8')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'9', N'30', N'1', N'', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'Just an insertion test!', N'$base_date_year-$base_date_month-23 11:55:52.000', null, N'16', N'5', N'6')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'10', N'25', N'2', N'', N'$base_date_year-$base_date_month-24 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'$base_date_year-$base_date_month-24 10:00:00.000', N'$base_date_year-$base_date_month-24 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'Just some lessons about phone skills, don''t miss it.', N'$base_date_year-$base_date_month-24 15:53:09.000', null, N'17', N'7', N'7')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'11', N'20', N'2', N'', N'$base_date_year-$base_date_month-25 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'$base_date_year-$base_date_month-25 10:00:00.000', N'$base_date_year-$base_date_month-25 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'Some sport lessons for young children.', N'$base_date_year-$base_date_month-24 15:54:10.000', null, N'16', N'6', N'5')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'12', N'15', N'1', N'', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'aaa', N'$base_date_year-$base_date_month-25 15:45:12.000', null, N'17', N'8', N'3')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'13', N'15', N'1', N'', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'testing', N'$base_date_year-$base_date_month-26 09:12:04.000', null, N'16', N'3', N'2')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'14', N'50', N'1', N'', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-17 10:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'$base_date_year-$base_date_month-18 12:00:00.000', N'0', N'testing too', N'$base_date_year-$base_date_month-26 09:12:24.000', null, N'16', N'3', N'3')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'15', N'30', N'2', N'', N'$base_date_year-$base_date_month-15 12:00:00.000', N'$base_date_year-$base_date_month-16 16:00:00.000', N'0', N'$base_date_year-$base_date_month-15 12:00:00.000', N'$base_date_year-$base_date_month-15 12:00:00.000', N'$base_date_year-$base_date_month-16 16:00:00.000', N'$base_date_year-$base_date_month-16 16:00:00.000', N'0', N'Helping you to inprove your helpdesk skills', N'$base_date_year-$base_date_month-11 10:06:56.000', null, N'17', N'8', N'4')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
SET IDENTITY_INSERT dbo.classes ON
INSERT INTO dbo.classes (id_classes, class_size, status, instructor, start_date_time, end_date_time, confirmed_reservations, start_date, start_time, end_date, end_time, pending_reservations, class_information, date_created, date_modified, id_instructor, id_curso, id_venues) VALUES (N'16', N'60', N'2', N'', N'$base_date_year-$base_date_month-01 12:00:00.000', N'$base_date_year-$base_date_month-05 14:00:00.000', N'0', N'$base_date_year-$base_date_month-01 12:00:00.000', N'$base_date_year-$base_date_month-01 12:00:00.000', N'$base_date_year-$base_date_month-05 14:00:00.000', N'$base_date_year-$base_date_month-05 14:00:00.000', N'0', N'Don''t be late!', N'$base_date_year-$base_date_month-11 15:10:27.000', null, N'17', N'9', N'1')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.classes OFF;
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'31', N'3', N'Finished', null, N'3', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'32', N'3', N'Finished', null, N'2', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'38', N'3', N'Finished', null, N'2', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'39', N'3', N'Finished', null, N'4', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'40', N'3', N'Finished', null, N'4', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'41', N'3', N'Finished', null, N'2', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'42', N'3', N'Finished', null, N'2', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'43', N'3', N'Finished', null, N'4', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'44', N'3', N'Finished', null, N'2', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'45', N'3', N'Finished', null, N'3', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'46', N'3', N'Finished', null, N'2', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'47', N'3', N'Finished', null, N'2', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'48', N'3', N'Finished', null, N'4', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'49', N'3', N'Finished', null, N'4', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'50', N'3', N'Finished', null, N'3', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'51', N'3', N'Finished', null, N'4', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'52', N'3', N'Finished', null, N'2', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'82', N'2', N'Finished', null, N'8', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'84', N'2', N'Finished', null, N'13', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'86', N'2', N'Confirmed', null, N'5', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'87', N'2', N'Finished', null, N'11', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'94', N'3', N'Confirmed', null, N'12', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'97', N'103', N'Confirmed', null, N'12', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'100', N'17', N'Confirmed', null, N'5', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation ON
INSERT INTO dbo.reservation (id_reservation, id_student, status, comments, id_class, date_created, date_modified) VALUES (N'102', N'103', N'Finished', null, N'15', null, null)
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET IDENTITY_INSERT dbo.reservation OFF;
EOT;
			
			break;
		}

		if(is_array($arr_sqls_inserts) && !empty($arr_sqls_inserts))
		{
			foreach($arr_sqls_inserts as $sql)
			{
				sc_exec_sql($sql);
			}
		}
	}
}
?>