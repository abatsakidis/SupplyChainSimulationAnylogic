PRAGMA foreign_keys = OFF;

-- ----------------------------
-- Table structure for "main"."classes"
-- ----------------------------

CREATE TABLE classes (
  id_classes INTEGER PRIMARY KEY AUTOINCREMENT,
  class_size INTEGER DEFAULT NULL,
  status INTEGER DEFAULT NULL,
  instructor varchar(60) DEFAULT NULL,
  start_date_time datetime DEFAULT NULL,
  end_date_time datetime DEFAULT NULL,
  confirmed_reservations INTEGER DEFAULT NULL,
  start_date date DEFAULT NULL,
  start_time time DEFAULT NULL,
  end_date date DEFAULT NULL,
  end_time time DEFAULT NULL,
  pending_reservations INTEGER DEFAULT NULL,
  class_information varchar(200) DEFAULT NULL,
  date_created datetime DEFAULT NULL,
  date_modified datetime DEFAULT NULL,
  id_instructor INTEGER NOT NULL,
  id_curso int(10) NOT NULL,
  id_venues int(10) NOT NULL,
  CONSTRAINT classes_ibfk_3 FOREIGN KEY (id_venues) REFERENCES venues (id_venues),
  CONSTRAINT classes_ibfk_1 FOREIGN KEY (id_instructor) REFERENCES instructors (id_instructor),
  CONSTRAINT classes_ibfk_2 FOREIGN KEY (id_curso) REFERENCES course_catalog (id_curso)
);

-- ----------------------------
-- Table structure for "main"."course_catalog"
-- ----------------------------

CREATE TABLE course_catalog (
  id_curso INTEGER PRIMARY KEY AUTOINCREMENT,
  course_title varchar(60) DEFAULT NULL,
  course_description varchar(300) DEFAULT NULL,
  course_lenght varchar(200) DEFAULT NULL,
  course_track varchar(100) DEFAULT NULL,
  date_created datetime DEFAULT NULL,
  date_modified datetime DEFAULT NULL
);

-- ----------------------------
-- Records of course_catalog
-- ----------------------------
INSERT INTO "course_catalog" VALUES (2, 'CSR: Customer Service Representative', 'Training Customer Service Representative (CSR) is intended for support center professionals who have direct contact with the client and are responsible for the level of care given.', 220, 'HR Essentials', null, null);
INSERT INTO "course_catalog" VALUES (3, 'SCA: Support Center Analyst', 'The HDI Support Center Analyst (SCA) is an intensive course designed for technical support and customer service that regardless of the level of knowledge are responsible for the so-called solution.', 80, 'Finance', null, null);
INSERT INTO "course_catalog" VALUES (4, 'DST: Desktop Support Technician', 'This course proves that professional field support, field support and on site have the ability to support customer service, for service management, as well as master the best practices for providing service and support high quality to customers.', 40, 'Business Skills', null, null);
INSERT INTO "course_catalog" VALUES (5, 'SCTL: Team Leader Support Center', 'This course is designed for team managers, leaders, coordinators or supervisors Support Centers that need to have leadership skills, learn best practices for managing people, processes, tools and resources from the Support Center as well as understand the value added service in the business', 16, 'HR Essentials', null, null);
INSERT INTO "course_catalog" VALUES (6, 'Support Center Manager', 'The Support Center Manager course covers in detail the best management practices of a tactical and operational support center. Entenda como gerir sua opera��o como uma organiza��o prestadora de servi�os ao neg�cio, controlando indicadores t�cnicos e associando-os aos objetivos da empresa, gerenciand', 4, 'HR Essentials', null, null);
INSERT INTO "course_catalog" VALUES (7, 'Customer Phone Skills', 'Or- How not to talk to a customer when a customer talks to you.', 10, 'Customer Service Skills', null, null);
INSERT INTO "course_catalog" VALUES (8, 'Endomarketing to Service Desk', 'Aimed at directors, managers, coordinators and supervisors of technology that has relationship with the users or any aspects of the business, the workshop Endomarketing for Service Desk is intended to present the benefits of communication in relation to the results obtained by IT to effectively by', 4, 'HR Essentials', null, null);
INSERT INTO "course_catalog" VALUES (9, 'Computer Maintenance', 'Computer Maintenance', 10, 'Computer Maintenance', '2012-05-14 14:30:43', null);

-- ----------------------------
-- Table structure for "main"."course_materials"
-- ----------------------------

CREATE TABLE course_materials (
  record_id INTEGER PRIMARY KEY AUTOINCREMENT,
  title varchar(80) DEFAULT NULL,
  description varchar(80) DEFAULT NULL,
  file_attachment varchar(80) DEFAULT NULL,
  url varchar(80) DEFAULT NULL,
  related_course varchar(80) DEFAULT NULL,
  date_created datetime DEFAULT NULL,
  date_modified datetime DEFAULT NULL
);

-- ----------------------------
-- Records of course_materials
-- ----------------------------
INSERT INTO "course_materials" VALUES (1, 'Course Presentation', 'This is a sample of an attachment to the course', 'sample.ppt.zip', 'ttt', 2, null, null);
INSERT INTO "course_materials" VALUES (2, 'SEC Website for Insider Training', 'This is the definition of Insider Trading', 'ttt', 'http://www.sec.gov/answers/insider.htm', 2, null, null);

-- ----------------------------
-- Table structure for "main"."instructors"
-- ----------------------------

CREATE TABLE instructors (
  id_instructor INTEGER PRIMARY KEY AUTOINCREMENT,
  instructors varchar(60) DEFAULT NULL,
  email_address varchar(60) DEFAULT NULL,
  phone varchar(40) DEFAULT NULL,
  cell_phone varchar(60) DEFAULT NULL,
  fax varchar(60) DEFAULT NULL,
  address varchar(60) DEFAULT NULL,
  name varchar(40) DEFAULT NULL,
  date_created datetime DEFAULT NULL,
  date_modified datetime DEFAULT NULL
);

-- ----------------------------
-- Records of instructors
-- ----------------------------
INSERT INTO "instructors" VALUES (3, 'clacerda@gmail.com', 'carlos@netmake.com.br', '(925) 555-1740', '(925) 555-7301', '', '100 Anytown St. Sunnydale, CA', 'Carlos Lacerda', null, '2011-08-26 18:35:49');
INSERT INTO "instructors" VALUES (4, 'chrisbaker@example.com', 'support@scriptcase.net', '(925) 555-1740', '(925) 555-7301', '', '100 Anytown St.Sunnydale, CA', 'Chris Laker', null, '2011-12-02 15:51:59');
INSERT INTO "instructors" VALUES (5, 'example_ToniOsheku', 'support@scriptcase.net', '(925) 555-1740', '(925) 555-7301', '', '100 Anytown St.Sunnydale, CA', 'Toni Oshoa', null, '2011-12-02 15:52:14');
INSERT INTO "instructors" VALUES (16, 'instructor@scriptcase.com.br', 'instructor@scriptcase.com.br', '', '', '', '', 'Pasquale', '2011-08-30 09:05:52', '2011-12-02 15:51:27');
INSERT INTO "instructors" VALUES (17, 'instructor@scriptcase.net', 'instructor@scriptcase.net', '', '', '', '', 'Steve Jobs', '2011-08-30 09:06:26', '2011-12-02 15:39:44');

-- ----------------------------
-- Table structure for "main"."reservation"
-- ----------------------------

CREATE TABLE reservation (
  id_reservation INTEGER PRIMARY KEY AUTOINCREMENT,
  id_student INTEGER DEFAULT NULL,
  status varchar(60) DEFAULT NULL,
  comments varchar(60) DEFAULT NULL,
  id_class INTEGER DEFAULT NULL,
  date_created datetime DEFAULT NULL,
  date_modified datetime DEFAULT NULL,
  CONSTRAINT reservation_ibfk_2 FOREIGN KEY (id_student) REFERENCES students (id_student),
  CONSTRAINT reservation_ibfk_1 FOREIGN KEY (id_class) REFERENCES classes (id_classes)
);

-- ----------------------------
-- Records of reservation
-- ----------------------------
INSERT INTO "reservation" VALUES (31, 3, 'Finished', null, 3, null, null);
INSERT INTO "reservation" VALUES (32, 3, 'Finished', null, 2, null, null);
INSERT INTO "reservation" VALUES (38, 3, 'Finished', null, 2, null, null);
INSERT INTO "reservation" VALUES (39, 3, 'Finished', null, 4, null, null);
INSERT INTO "reservation" VALUES (40, 3, 'Finished', null, 4, null, null);
INSERT INTO "reservation" VALUES (41, 3, 'Finished', null, 2, null, null);
INSERT INTO "reservation" VALUES (42, 3, 'Finished', null, 2, null, null);
INSERT INTO "reservation" VALUES (43, 3, 'Finished', null, 4, null, null);
INSERT INTO "reservation" VALUES (44, 3, 'Finished', null, 2, null, null);
INSERT INTO "reservation" VALUES (45, 3, 'Finished', null, 3, null, null);
INSERT INTO "reservation" VALUES (46, 3, 'Finished', null, 2, null, null);
INSERT INTO "reservation" VALUES (47, 3, 'Finished', null, 2, null, null);
INSERT INTO "reservation" VALUES (48, 3, 'Finished', null, 4, null, null);
INSERT INTO "reservation" VALUES (49, 3, 'Finished', null, 4, null, null);
INSERT INTO "reservation" VALUES (50, 3, 'Finished', null, 3, null, null);
INSERT INTO "reservation" VALUES (51, 3, 'Finished', null, 4, null, null);
INSERT INTO "reservation" VALUES (52, 3, 'Finished', null, 2, null, null);
INSERT INTO "reservation" VALUES (82, 2, 'Finished', null, 8, null, null);
INSERT INTO "reservation" VALUES (84, 2, 'Finished', null, 13, null, null);
INSERT INTO "reservation" VALUES (86, 2, 'Confirmed', null, 5, null, null);
INSERT INTO "reservation" VALUES (87, 2, 'Finished', null, 11, null, null);
INSERT INTO "reservation" VALUES (94, 3, 'Confirmed', null, 12, null, null);
INSERT INTO "reservation" VALUES (96, 103, 'Confirmed', null, 6, null, null);
INSERT INTO "reservation" VALUES (97, 103, 'Confirmed', null, 12, null, null);
INSERT INTO "reservation" VALUES (98, 103, 'Confirmed', null, 5, null, null);
INSERT INTO "reservation" VALUES (100, 17, 'Confirmed', null, 5, null, null);
INSERT INTO "reservation" VALUES (102, 103, 'Pending', null, 9, null, null);
INSERT INTO "reservation" VALUES (103, 103, 'Pending', null, 2, null, null);

-- ----------------------------
-- Table structure for "main"."status"
-- ----------------------------

CREATE TABLE status (
  id_status INTEGER PRIMARY KEY AUTOINCREMENT,
  desc_status varchar(120) DEFAULT NULL
);

-- ----------------------------
-- Records of status
-- ----------------------------
INSERT INTO "status" VALUES (1, 'Open for Registration');
INSERT INTO "status" VALUES (2, 'Finished');

-- ----------------------------
-- Table structure for "main"."students"
-- ----------------------------

CREATE TABLE students (
  id_student INTEGER PRIMARY KEY AUTOINCREMENT,
  first_name varchar(30) DEFAULT NULL,
  last_name varchar(30) DEFAULT NULL,
  full_name varchar(30) DEFAULT NULL,
  email_address varchar(60) DEFAULT NULL,
  completed_courses varchar(60) DEFAULT NULL,
  company varchar(80) DEFAULT NULL,
  job_title varchar(80) DEFAULT NULL,
  street_address varchar(80) DEFAULT NULL,
  city varchar(80) DEFAULT NULL,
  state varchar(80) DEFAULT NULL,
  zip varchar(80) DEFAULT NULL,
  country varchar(80) DEFAULT NULL,
  fax varchar(40) DEFAULT NULL,
  phone varchar(80) DEFAULT NULL,
  mobile_phone varchar(80) DEFAULT NULL,
  date_created datetime DEFAULT NULL,
  date_modified datetime DEFAULT NULL
);

-- ----------------------------
-- Records of students
-- ----------------------------
INSERT INTO "students" VALUES (1, 'Robert', 'Adams', 'Robert Adams', 'radams@scriptcase.net', 'radams@scriptcase.net', 'Corellian Engineering Corp', 'CEO', '156 Sleepy Autumn Acres', 'Binghamton', 'New York', 77486, 'USA', '(992) 555-1752', '(992) 555-1963', '(992) 555-1766', null, '2011-08-23 09:23:54');
INSERT INTO "students" VALUES (2, 'Jonathan', 'Alexander', 'Jonathan Alexander', 'jalexander@scriptcase.net', 'jalexander@scriptcase.net', 'Oceanic Airlines', 'IT Manager', '84 Heather Beacon Arbor', 'Boulder', 'Colorado', 88555, 'USA', '(418) 555-9074', '(418) 555-9349', '(418) 555-6114', null, '2011-08-26 11:28:20');
INSERT INTO "students" VALUES (3, 'Samuel', 'Allen', 'Samuel Allen', 'sallen@scriptcase.net', 'sallen@scriptcase.net', 'Wayne Enterprises', 'CTO', '74 Little Bluff Bank', 'Koloa', 'Hawaii', 55867, 'USA', '(147) 555-8806', '(147) 555-9205', '(147) 555-7676', null, null);
INSERT INTO "students" VALUES (4, 'Andrea', 'Anderson', 'Andrea Anderson', 'aanderson@scriptcase.net', 'aanderson@scriptcase.net', 'Central Services', 'ttt', '198 Indian Brook Bend', 'Brooklyn', 'New York', 26568, 'USA', 'ttt', '(381) 555-4902', '(381) 555-3244', null, null);
INSERT INTO "students" VALUES (5, 'Larry', 'Andrews', 'Larry Andrews', 'landrews@scriptcase.net', 'landrews@scriptcase.net', 'Oceanic Airlines', 'IT Manager', '145 Lazy Cloud Canyon', 'Omaha', 'Nebraska', 84741, 'USA', '(744) 555-2928', '(744) 555-7666', '(744) 555-0301', null, null);
INSERT INTO "students" VALUES (6, 'Eric', 'Armstrong', 'Eric Armstrong', 'earmstrong@scriptcase.net', 'earmstrong@scriptcase.net', 'Wayne Enterprises', 'CTO', '57 Ridge Creek Corner', 'Atlanta', 'Georgia', 39804, 'USA', '(268) 555-7706', '(268) 555-3300', '(268) 555-5339', null, null);
INSERT INTO "students" VALUES (7, 'Thomas', 'Arnold', 'Thomas Arnold', 'tarnold@scriptcase.net', 'tarnold@scriptcase.net', 'Wayne Enterprises', 'IT Manager', '60 Wishing Dale Chase', 'Owego', 'New York', 23177, 'USA', '(993) 555-1179', '(993) 555-7934', '(993) 555-2086', null, null);
INSERT INTO "students" VALUES (8, 'Juan', 'Austin', 'Juan Austin', 'jaustin@scriptcase.net', 'jaustin@scriptcase.net', 'Blue Sun Corp', 'ttt', '93 Colonial Deer Court', 'Scottsdale', 'Arizona', 45316, 'USA', 'ttt', '(383) 555-7563', '(383) 555-3719', null, null);
INSERT INTO "students" VALUES (9, 'Sandra', 'Bailey', 'Sandra Bailey', 'sbailey@scriptcase.net', 'sbailey@scriptcase.net', 'Blue Sun Corp', 'ttt', '5 Old Falls Cove', 'Cincinatti', 'Ohio', 47303, 'USA', '(422) 555-4946', '(422) 555-9771', '(422) 555-9743', null, null);
INSERT INTO "students" VALUES (10, 'Frank', 'Baker', 'Frank Baker', 'fbaker@scriptcase.net', 'fbaker@scriptcase.net', 'Oceanic Airlines', 'IT Manager', '43 Quiet Fox Crest', 'Poipu', 'Hawaii', 36514, 'USA', '(886) 555-3873', '(886) 555-9314', '(886) 555-0390', null, null);
INSERT INTO "students" VALUES (11, 'Martha', 'Barnes', 'Martha Barnes', 'mbarnes@scriptcase.net', 'mbarnes@scriptcase.net', 'Blue Sun Corp', 'Director of Marketing', '106 Pleasant Gate Drive', 'Tuscon', 'Arizona', 3968, 'USA', 'ttt', 'ttt', '(991) 555-0976', null, null);
INSERT INTO "students" VALUES (12, 'Jerry', 'Bell', 'Jerry Bell', 'jbell@scriptcase.net', 'jbell@scriptcase.net', 'Blue Sun Corp', 'Vice President of Sales', '13 Fawn Hills Edge', 'Toronto', 'Ontario', 'A47 B12', 'Canada', 'ttt', '(367) 555-7729', '(367) 555-6090', null, null);
INSERT INTO "students" VALUES (13, 'Cynthia', 'Bennett', 'Cynthia Bennett', 'cbennett@scriptcase.net', 'cbennett@scriptcase.net', 'Mainway Toys', 'Vice President of Sales', '25 Bright Island Estates', 'Phoenix', 'Arizona', 10761, 'USA', '(961) 555-4376', '(961) 555-3772', '(961) 555-5812', null, null);
INSERT INTO "students" VALUES (14, 'Mark', 'Berry', 'Mark Berry', 'mberry@scriptcase.net', 'mberry@scriptcase.net', 'Blue Sun Corp', 'ttt', '22 Round Jute Farms', 'Washington, DC', 'District of Columbia', 53020, 'USA', '(983) 555-6278', '(983) 555-0710', '(983) 555-0301', null, null);
INSERT INTO "students" VALUES (15, 'Steve', 'Black', 'Steve Black', 'sblack@scriptcase.net', 'sblack@scriptcase.net', 'Blue Sun Corp', 'IT Manager', '66 Silent Lagoon Gardens', 'Brooklyn', 'New York', 13132, 'USA', '(159) 555-2244', '(159) 555-5186', '(159) 555-9582', null, null);
INSERT INTO "students" VALUES (16, 'Roger', 'Boyd', 'Roger Boyd', 'rboyd@scriptcase.net', 'rboyd@scriptcase.net', 'Wayne Enterprises', 'Manager', '53 Crystal Lake Glen', 'Little Desert Island', 'Maine', 3017, 'USA', '(869) 555-4944', '(869) 555-8956', '(869) 555-1101', null, null);
INSERT INTO "students" VALUES (17, 'Stephen', 'Bradley', 'Stephen Bradley', 'sbradley@scriptcase.net', 'sbradley@scriptcase.net', 'Oceanic Airlines', 'ttt', '26 Cozy Meadow Grove', 'Boulder', 'Colorado', 58562, 'USA', '(484) 555-7582', '(484) 555-9754', '(484) 555-9375', null, null);
INSERT INTO "students" VALUES (18, 'Kevin', 'Brooks', 'Kevin Brooks', 'kbrooks@scriptcase.net', 'kbrooks@scriptcase.net', 'Mainway Toys', 'CEO', '87 Noble Mountain Hollow', 'Phoenix', 'Arizona', 67001, 'USA', '(103) 555-0460', '(103) 555-7215', '(103) 555-7917', null, null);
INSERT INTO "students" VALUES (19, 'Robin', 'Brown', 'Robin Brown', 'rbrown@scriptcase.net', 'rbrown@scriptcase.net', 'Blue Sun Corp', 'Vice President of Sales', '172 Cotton Nectar Isle', 'New York', 'New York', 79020, 'USA', 'ttt', '(872) 555-6424', '(872) 555-3517', null, null);
INSERT INTO "students" VALUES (20, 'Margaret', 'Bryant', 'Margaret Bryant', 'mbryant@scriptcase.net', 'mbryant@scriptcase.net', 'Wayne Enterprises', 'Vice President of Sales', '30 Harvest Oak Jetty', 'Lomax', 'New York', 65039, 'USA', '(622) 555-7880', '(622) 555-1495', '(622) 555-6080', null, null);
INSERT INTO "students" VALUES (21, 'Adam', 'Burns', 'Adam Burns', 'aburns@scriptcase.net', 'aburns@scriptcase.net', 'Oceanic Airlines', 'IT Manager', '195 Silver Panda Knoll', 'Fielddale', 'Alabama', 88500, 'USA', '(633) 555-2964', '(633) 555-3763', '(633) 555-2436', null, null);
INSERT INTO "students" VALUES (22, 'Louise', 'Butler', 'Louise Butler', 'lbutler@scriptcase.net', 'lbutler@scriptcase.net', 'Oceanic Airlines', 'Team Lead', '176 Cinder Pioneer Landing', 'Pleasantville', 'Kansas', 46199, 'USA', '(617) 555-2393', '(617) 555-9545', '(617) 555-7288', null, null);
INSERT INTO "students" VALUES (23, 'Stephanie', 'Campbell', 'Stephanie Campbell', 'scampbell@scriptcase.net', 'scampbell@scriptcase.net', 'Oceanic Airlines', 'ttt', '7 Green Pond Ledge', 'Borride', 'Arizona', 71270, 'USA', 'ttt', '(492) 555-2640', '(492) 555-5372', null, null);
INSERT INTO "students" VALUES (24, 'Diana', 'Carpenter', 'Diana Carpenter', 'dcarpenter@scriptcase.net', 'dcarpenter@scriptcase.net', 'Oceanic Airlines', 'ttt', '13 Tawny Prairie Manor', 'Cheyenne', 'Wyoming', 89557, 'USA', '(596) 555-9049', '(596) 555-4329', '(596) 555-8217', null, null);
INSERT INTO "students" VALUES (25, 'Kathryn', 'Carroll', 'Kathryn Carroll', 'kcarroll@scriptcase.net', 'kcarroll@scriptcase.net', 'Mainway Toys', 'Team Lead', '195 Dewy Quail Nook', 'Marquette', 'Arizona', 78686, 'USA', '(616) 555-3101', 'ttt', '(616) 555-8159', null, null);
INSERT INTO "students" VALUES (26, 'Douglas', 'Carter', 'Douglas Carter', 'dcarter@scriptcase.net', 'dcarter@scriptcase.net', 'Blue Sun Corp', 'Team Lead', '199 Sunny Race Orchard', 'Plato', 'South Dakota', 29878, 'USA', '(117) 555-8643', '(117) 555-8749', '(117) 555-8674', null, null);
INSERT INTO "students" VALUES (27, 'Shawn', 'Chavez', 'Shawn Chavez', 'schavez@scriptcase.net', 'schavez@scriptcase.net', 'Oceanic Airlines', 'ttt', '188 Iron Rustic Park', 'Socrates', 'Arizona', 97915, 'USA', 'ttt', '(500) 555-7366', '(500) 555-9746', null, null);
INSERT INTO "students" VALUES (28, 'Paula', 'Clark', 'Paula Clark', 'pclark@scriptcase.net', 'Clark, Pat', 'Wayne Enterprises', 'ttt', '79 Emerald Rise Path', 'Aristotle', 'Kentucky', 30459, 'USA', '(268) 555-8142', '(268) 555-4128', '(268) 555-9332', null, null);
INSERT INTO "students" VALUES (29, 'Dennis', 'Cole', 'Dennis Cole', 'dcole@scriptcase.net', 'dcole@scriptcase.net', 'Central Services', 'IT Manager', '137 Golden River Place', 'Ukulele', 'Hawaii', 74364, 'USA', '(260) 555-4778', '(260) 555-2674', '(260) 555-3009', null, null);
INSERT INTO "students" VALUES (30, 'Anthony', 'Coleman', 'Anthony Coleman', 'acoleman@scriptcase.net', 'acoleman@scriptcase.net', 'Oceanic Airlines', 'ttt', '69 Stony Sky Point', 'Moraga', 'California', 46097, 'USA', '(275) 555-5490', '(275) 555-5860', '(275) 555-5779', null, null);
INSERT INTO "students" VALUES (31, 'Frances', 'Collins', 'Frances Collins', 'fcollins@scriptcase.net', 'fcollins@scriptcase.net', 'Wayne Enterprises', 'IT Manager', '92 Misty Spring Run', 'Atlanta', 'Georgia', 29382, 'USA', '(535) 555-2107', '(535) 555-2696', '(535) 555-2941', null, null);
INSERT INTO "students" VALUES (32, 'Kelly', 'Cook', 'Kelly Cook', 'kcook@scriptcase.net', 'kcook@scriptcase.net', 'Wayne Enterprises', 'ttt', '26 Rocky Timber Trace', 'Vestal', 'New York', 37057, 'USA', '(891) 555-3822', '(891) 555-7329', '(891) 555-2575', null, null);
INSERT INTO "students" VALUES (33, 'Carlos', 'Cooper', 'Carlos Cooper', 'ccooper@scriptcase.net', 'ccooper@scriptcase.net', 'Blue Sun Corp', 'HR Admin', '158 Broad Treasure Valley', 'Lafayette', 'California', 74387, 'USA', '(621) 555-4711', '(621) 555-9416', '(621) 555-8027', null, null);
INSERT INTO "students" VALUES (34, 'Gloria', 'Cox', 'Gloria Cox', 'gcox@scriptcase.net', 'gcox@scriptcase.net', 'Blue Sun Corp', 'Team Lead', '64 Shady View Vista', 'ttt', 'ttt', 'E32 11A', 'UK', '(619) 555-9077', '(619) 555-7248', '(619) 555-7894', null, null);
INSERT INTO "students" VALUES (35, 'Lois', 'Crawford', 'Lois Crawford', 'lcrawford@scriptcase.net', 'lcrawford@scriptcase.net', 'Oceanic Airlines', 'Team Lead', '2 Hidden Willow Way', 'Annapolis', 'Maryland', 61249, 'USA', '(353) 555-9227', '(353) 555-2169', '(353) 555-4968', null, null);
INSERT INTO "students" VALUES (36, 'Michelle', 'Cruz', 'Michelle Cruz', 'mcruz@scriptcase.net', 'mcruz@scriptcase.net', 'Blue Sun Corp', 'CEO', '168 Velvet Zephyr Woods', 'Dickson', 'Colorado', 6236, 'USA', 'ttt', '(595) 555-9800', '(595) 555-4486', null, null);
INSERT INTO "students" VALUES (37, 'Cheryl', 'Cunningham', 'Cheryl Cunningham', 'ccunningham@scriptcase.net', 'ccunningham@scriptcase.net', 'Blue Sun Corp', 'Managing Director', '34 Wishing View Landing', 'Vail', 'Colorado', 20019, 'USA', '(993) 555-3093', '(993) 555-5073', '(993) 555-1484', null, null);
INSERT INTO "students" VALUES (38, 'Patricia', 'Daniels', 'Patricia Daniels', 'pdaniels@scriptcase.net', 'pdaniels@scriptcase.net', 'Mainway Toys', 'Director of Marketing', '87 Silver Falls Vista', 'Happy Valley', 'Georgia', 54443, 'USA', '(630) 555-8584', '(630) 555-8010', '(630) 555-2962', null, null);
INSERT INTO "students" VALUES (39, 'Kathy', 'Davis', 'Kathy Davis', 'kdavis@scriptcase.net', 'kdavis@scriptcase.net', 'Blue Sun Corp', 'IT Manager', '165 Tawny Sky Park', 'Sim City', 'North Carolina', 85333, 'USA', '(321) 555-7403', '(321) 555-6199', '(321) 555-9207', null, null);
INSERT INTO "students" VALUES (40, 'Albert', 'Diaz', 'Albert Diaz', 'adiaz@scriptcase.net', 'adiaz@scriptcase.net', 'Blue Sun Corp', 'Team Lead', '51 Hidden Island Drive', 'Anne Arundel', 'Maryland', 69840, 'USA', '(811) 555-5296', '(811) 555-9253', '(811) 555-0621', null, null);
INSERT INTO "students" VALUES (41, 'Mildred', 'Dixon', 'Mildred Dixon', 'mdixon@scriptcase.net', 'mdixon@scriptcase.net', 'Wayne Enterprises', 'Manager', '57 Harvest Brook Cove', 'Fish Cove', 'Maryland', 25470, 'USA', '(343) 555-8995', '(343) 555-3530', '(343) 555-4330', null, null);
INSERT INTO "students" VALUES (42, 'Peter', 'Duncan', 'Peter Duncan', 'pduncan@scriptcase.net', 'pduncan@scriptcase.net', 'Mainway Toys', 'ttt', '78 Cinder Timber Chase', 'Morganville', 'New York', 99110, 'USA', '(857) 555-2636', '(857) 555-6317', '(857) 555-1451', null, null);
INSERT INTO "students" VALUES (43, 'Jessica', 'Dunn', 'Jessica Dunn', 'jdunn@scriptcase.net', 'jdunn@scriptcase.net', 'Mainway Toys', 'CTO', '58 Cotton Rise Acres', 'Sagebrush', 'Arizona', 69358, 'USA', 'ttt', '(281) 555-1659', '(281) 555-5061', null, null);
INSERT INTO "students" VALUES (44, 'Joe', 'Edwards', 'Joe Edwards', 'jedwards@scriptcase.net', 'jedwards@scriptcase.net', 'Blue Sun Corp', 'ttt', '140 Fawn Lake Orchard', 'ttt', 'ttt', 'B29 A10', 'Canada', '(357) 555-2764', 'ttt', '(357) 555-1578', null, null);
INSERT INTO "students" VALUES (45, 'Alan', 'Elliott', 'Alan Elliott', 'aelliott@scriptcase.net', 'aelliott@scriptcase.net', 'Wayne Enterprises', 'ttt', '100 Dewy Pond Corner', 'Honolulu', 'Hawaii', 83685, 'USA', 'ttt', '(356) 555-7900', '(356) 555-0756', null, null);
INSERT INTO "students" VALUES (47, 'Willie', 'Evans', 'Willie Evans', 'wevans@scriptcase.net', 'wevans@scriptcase.net', 'Oceanic Airlines', 'ttt', '17 Lazy River Knoll', 'Annapolis', 'Maryland', 10810, 'USA', '(462) 555-1443', '(462) 555-8858', '(462) 555-8060', null, null);
INSERT INTO "students" VALUES (49, 'Gary', 'Fisher', 'Gary Fisher', 'gfisher@scriptcase.net', 'gfisher@scriptcase.net', 'Oceanic Airlines', 'Director of Marketing', '75 Velvet Jute Court', 'Storrs', 'Connecticut', 23745, 'USA', '(295) 555-7217', '(295) 555-9304', '(295) 555-3540', null, null);
INSERT INTO "students" VALUES (50, 'Jeremy', 'Flores', 'Jeremy Flores', 'jflores@scriptcase.net', 'jflores@scriptcase.net', 'Mainway Toys', 'ttt', '193 Golden Deer Trace', 'Honolulu', 'Hawaii', 9043, 'USA', '(111) 555-6300', '(111) 555-7266', '(111) 555-3872', null, null);
INSERT INTO "students" VALUES (51, 'Janet', 'Ford', 'Janet Ford', 'jford@scriptcase.net', 'jford@scriptcase.net', 'Blue Sun Corp', 'IT Manager', '40 Silent Quail Nook', 'Boot Hill', 'Arizona', 15746, 'USA', 'ttt', '(528) 555-6061', '(528) 555-0859', null, null);
INSERT INTO "students" VALUES (52, 'Emily', 'Foster', 'Emily Foster', 'efoster@scriptcase.net', 'efoster@scriptcase.net', 'Oceanic Airlines', 'CEO', '70 Old Mountain Glen', 'New Orleans', 'Louisiana', 35555, 'USA', '(605) 555-2668', '(605) 555-4480', '(605) 555-9617', null, null);
INSERT INTO "students" VALUES (54, 'Ruby', 'Franklin', 'Ruby Franklin', 'rfranklin@scriptcase.net', 'rfranklin@scriptcase.net', 'Central Services', 'Manager', '18 Pleasant Fox Hollow', 'Centralia', 'Washington', 22523, 'USA', '(742) 555-7801', '(742) 555-0731', '(742) 555-9613', null, null);
INSERT INTO "students" VALUES (55, 'Antonio', 'Freeman', 'Antonio Freeman', 'afreeman@scriptcase.net', 'afreeman@scriptcase.net', 'Oceanic Airlines', 'Team Lead', '106 Emerald Pioneer Valley', 'Marquette', 'Maryland', 14284, 'USA', '(328) 555-1739', '(328) 555-3612', '(328) 555-3165', null, null);
INSERT INTO "students" VALUES (56, 'Sean', 'Garcia', 'Sean Garcia', 'sgarcia@scriptcase.net', 'sgarcia@scriptcase.net', 'Wayne Enterprises', 'ttt', '168 Bright Cloud Point', 'ttt', 'ttt', '393B90', 'France', '(644) 555-4852', '(644) 555-5892', '(644) 555-4185', null, null);
INSERT INTO "students" VALUES (57, 'Paul', 'Gardner', 'Paul Gardner', 'pgardner@scriptcase.net', 'pgardner@scriptcase.net', 'Wayne Enterprises', 'ttt', '189 Colonial Zephyr Manor', 'Portland', 'Oregon', 31207, 'USA', 'ttt', '(642) 555-4066', '(642) 555-1761', null, null);
INSERT INTO "students" VALUES (58, 'Peggy', 'Gibson', 'Peggy Gibson', 'pgibson@scriptcase.net', 'pgibson@scriptcase.net', 'Blue Sun Corp', 'CTO', '182 Iron Oak Canyon', 'Hanapepe', 'Hawaii', 88518, 'USA', '(288) 555-0295', '(288) 555-2491', '(288) 555-0542', null, null);
INSERT INTO "students" VALUES (59, 'Christine', 'Gomez', 'Christine Gomez', 'cgomez@scriptcase.net', 'gomez, c', 'Blue Sun Corp', 'ttt', '43 Shady Panda Ledge', 'Crab Apple Cove', 'Maine', 27711, 'USA', '(555) 555-4429', '(555) 555-1744', '(555) 555-1876', null, null);
INSERT INTO "students" VALUES (60, 'Phillip', 'Gonzales', 'Phillip Gonzales', 'pgonzales@scriptcase.net', 'pgonzales@scriptcase.net', 'Oceanic Airlines', 'ttt', '94 Sunny Autumn Crest', 'ttt', 'ttt', '123B8', 'France', '(852) 555-1351', '(852) 555-5481', '(852) 555-2275', null, null);
INSERT INTO "students" VALUES (61, 'Irene', 'Gonzalez', 'Irene Gonzalez', 'igonzalez@scriptcase.net', 'igonzalez@scriptcase.net', 'Blue Sun Corp', 'ttt', '146 Broad Willow Jetty', 'Phoenix', 'Arizona', 49462, 'USA', '(457) 555-0743', '(457) 555-3347', '(457) 555-3565', null, null);
INSERT INTO "students" VALUES (62, 'Beverly', 'Gordon', 'Beverly Gordon', 'bgordon@scriptcase.net', 'bgordon@scriptcase.net', 'Blue Sun Corp', 'IT Manager', '66 Indian Spring Arbor', 'St. Louis', 'Missouri', 34878, 'USA', 'ttt', '(587) 555-3750', '(587) 555-3278', null, null);
INSERT INTO "students" VALUES (63, 'Arthur', 'Graham', 'Arthur Graham', 'agraham@scriptcase.net', 'agraham@scriptcase.net', 'Mainway Toys', 'IT Manager', '136 Sleepy Beacon Way', 'Gary', 'Indiana', 66439, 'USA', '(688) 555-4543', '(688) 555-2142', '(688) 555-6829', null, null);
INSERT INTO "students" VALUES (66, 'Roy', 'Green', 'Roy Green', 'rgreen@scriptcase.net', 'rgreen@scriptcase.net', 'Wayne Enterprises', 'HR Admin', '87 Crystal Nectar Isle', 'Breckenridge', 'Colorado', 39923, 'USA', '(179) 555-1112', '(179) 555-6949', '(179) 555-8520', null, null);
INSERT INTO "students" VALUES (67, 'Maria', 'Greene', 'Maria Greene', 'mgreene@scriptcase.net', 'mgreene@scriptcase.net', 'Mainway Toys', 'ttt', '62 Rocky Hills Bend', 'ttt', 'ttt', '068 E43', 'Canada', '(379) 555-3342', '(379) 555-7502', '(379) 555-9814', null, null);
INSERT INTO "students" VALUES (68, 'Angela', 'Griffin', 'Angela Griffin', 'agriffin@scriptcase.net', 'agriffin@scriptcase.net', 'Mainway Toys', 'CEO', '56 Little Creek Farms', 'ttt', 'ttt', 'ttt', 'Brazil', '(284) 555-3826', '(284) 555-1026', '(284) 555-2606', null, null);
INSERT INTO "students" VALUES (69, 'Jimmy', 'Hall', 'Jimmy Hall', 'jhall@scriptcase.net', 'jhall@scriptcase.net', 'Blue Sun Corp', 'Team Lead', '166 Quiet Lagoon Place', 'Getier', 'South Carolina', 74237, 'ttt', 'ttt', '(818) 555-8026', '(818) 555-5184', null, null);
INSERT INTO "students" VALUES (70, 'William', 'Hamilton', 'William Hamilton', 'whamilton@scriptcase.net', 'whamilton@scriptcase.net', 'Wayne Enterprises', 'CTO', '116 Cozy Meadow Grove', 'Scottsdale', 'Arizona', 55619, 'ttt', '(511) 555-7704', 'ttt', '(511) 555-4804', null, null);
INSERT INTO "students" VALUES (71, 'Donna', 'Harper', 'Donna Harper', 'dharper@scriptcase.net', 'dharper@scriptcase.net', 'Oceanic Airlines', 'Vice President of Sales', '55 Misty Bluff Estates', 'Oakland', 'California', 1092, 'USA', '(788) 555-7944', '(788) 555-2894', '(788) 555-7265', null, null);
INSERT INTO "students" VALUES (72, 'Theresa', 'Harris', 'Theresa Harris', 'tharris@scriptcase.net', 'tharris@scriptcase.net', 'Oceanic Airlines', 'Director of Marketing', '15 Green Race Bank', 'Grosse Pointe', 'Michigan', 'B39 181', 'UK', '(185) 555-6466', '(185) 555-5975', '(185) 555-5771', null, null);
INSERT INTO "students" VALUES (73, 'Brandon', 'Harrison', 'Brandon Harrison', 'bharrison@scriptcase.net', 'bharrison@scriptcase.net', 'Oceanic Airlines', 'CEO', 'ttt', 'Tuscaloosa', 'Alabama', 75973, 'USA', '(630) 555-8785', '(630) 555-9078', '(630) 555-6192', null, null);
INSERT INTO "students" VALUES (74, 'Jacqueline', 'Hawkins', 'Jacqueline Hawkins', 'jhawkins@scriptcase.net', 'jhawkins@scriptcase.net', 'Oceanic Airlines', 'IT Manager', 'ttt', 'Boise', 'Idaho', 38505, 'USA', '(855) 555-5362', '(855) 555-6291', '(855) 555-3220', null, null);
INSERT INTO "students" VALUES (75, 'Ashley', 'Hayes', 'Ashley Hayes', 'ahayes@scriptcase.net', 'ahayes@scriptcase.net', 'Mainway Toys', 'ttt', 'ttt', 'ttt', 'ttt', 'D871 123', 'Mexico', '(608) 555-7840', '(608) 555-4588', '(608) 555-4646', null, null);
INSERT INTO "students" VALUES (76, 'Aaron', 'Henderson', 'Aaron Henderson', 'ahenderson@scriptcase.net', 'ahenderson@scriptcase.net', 'Blue Sun Corp', 'VP of Product Management', 'ttt', 'Paige', 'Arizona', 20492, 'USA', 'ttt', '(986) 555-3186', '(986) 555-3595', null, null);
INSERT INTO "students" VALUES (77, 'Rebecca', 'Henry', 'Rebecca Henry', 'rhenry@scriptcase.net', 'rhenry@scriptcase.net', 'Oceanic Airlines', 'CTO', 'ttt', 'Oklahoma City', 'Oklahoma', 85684, 'USA', '(462) 555-9378', '(462) 555-4370', '(462) 555-6044', null, null);
INSERT INTO "students" VALUES (78, 'Amy', 'Hernandez', 'Amy Hernandez', 'ahernandez@scriptcase.net', 'ahernandez@scriptcase.net', 'Wayne Enterprises', 'CTO', 'ttt', 'ttt', 'ttt', 'ttt', 'Brazil', '(422) 555-2018', 'ttt', '(422) 555-4080', null, null);
INSERT INTO "students" VALUES (79, 'Tina', 'Hicks', 'Tina Hicks', 'thicks@scriptcase.net', 'thicks@scriptcase.net', 'Central Services', 'ttt', 'ttt', 'Pittsburgh', 'Pennsylvania', 76035, 'USA', '(912) 555-4755', 'ttt', '(912) 555-4600', null, null);
INSERT INTO "students" VALUES (80, 'Julie', 'Hill', 'Julie Hill', 'jhill@scriptcase.net', 'jhill@scriptcase.net', 'Oceanic Airlines', 'CEO', 'ttt', 'Atlanta', 'Georgia', 24401, 'USA', '(768) 555-6340', 'ttt', '(768) 555-2498', null, null);
INSERT INTO "students" VALUES (103, 'student', 'internacional', 'student internacional', 'student@scriptcase.net', '', '', '', '', '', '', '', '', '', '', '', '2011-08-26 17:56:24', '2012-01-31 16:28:33');
INSERT INTO "students" VALUES (104, 'student brasil', 'student brasil', 'student brasil student brasil', 'student@scriptcase.com.br', '', '', '', '', '', '', '', '', '', '', '', '2011-08-26 17:58:05', null);

-- ----------------------------
-- Table structure for "main"."tb_applications"
-- ----------------------------

CREATE TABLE tb_applications (
  name varchar(150) NOT NULL,
  description varchar(170) DEFAULT NULL,
  PRIMARY KEY (name)
);

-- ----------------------------
-- Records of tb_applications
-- ----------------------------
INSERT INTO "tb_applications" VALUES ('blank', 'blank');
INSERT INTO "tb_applications" VALUES ('blank_teste_email', 'blank_teste_email');
INSERT INTO "tb_applications" VALUES ('calendar_classes', 'calendar_classes');
INSERT INTO "tb_applications" VALUES ('container', 'container');
INSERT INTO "tb_applications" VALUES ('container_instructor', 'container_instructor');
INSERT INTO "tb_applications" VALUES ('control_change_password', 'control_change_password');
INSERT INTO "tb_applications" VALUES ('control_login', 'control_login');
INSERT INTO "tb_applications" VALUES ('control_synchronize', 'control_synchronize');
INSERT INTO "tb_applications" VALUES ('form_add_instructors', 'form_add_instructors');
INSERT INTO "tb_applications" VALUES ('form_add_students', 'form_add_students');
INSERT INTO "tb_applications" VALUES ('form_confirm_classes_label', 'form_confirm_classes_label');
INSERT INTO "tb_applications" VALUES ('form_conf_email', 'form_conf_email');
INSERT INTO "tb_applications" VALUES ('form_course_catalog', 'form_course_catalog');
INSERT INTO "tb_applications" VALUES ('form_course_materials', 'form_course_materials');
INSERT INTO "tb_applications" VALUES ('form_edit_instructor', 'form_edit_instructor');
INSERT INTO "tb_applications" VALUES ('form_instructors', 'form_instructors');
INSERT INTO "tb_applications" VALUES ('form_instructor_confirm_classes_label', 'form_instructor_confirm_classes_label');
INSERT INTO "tb_applications" VALUES ('form_register_class', 'form_register_class');
INSERT INTO "tb_applications" VALUES ('form_reservation_label', 'form_reservation_label');
INSERT INTO "tb_applications" VALUES ('form_students', 'form_students');
INSERT INTO "tb_applications" VALUES ('form_tb_applications', 'form_tb_applications');
INSERT INTO "tb_applications" VALUES ('form_tb_groups', 'form_tb_groups');
INSERT INTO "tb_applications" VALUES ('form_tb_users', 'form_tb_users');
INSERT INTO "tb_applications" VALUES ('form_unregister_reservation', 'form_unregister_reservation');
INSERT INTO "tb_applications" VALUES ('form_update_students', 'form_update_students');
INSERT INTO "tb_applications" VALUES ('form_venues', 'form_venues');
INSERT INTO "tb_applications" VALUES ('grid_classes_list', 'grid_classes_list');
INSERT INTO "tb_applications" VALUES ('grid_course_catalog', 'grid_course_catalog');
INSERT INTO "tb_applications" VALUES ('grid_course_catalog_self', 'grid_course_catalog_self');
INSERT INTO "tb_applications" VALUES ('grid_course_materials', 'grid_course_materials');
INSERT INTO "tb_applications" VALUES ('grid_instructors', 'grid_instructors');
INSERT INTO "tb_applications" VALUES ('grid_instructors_details', 'grid_instructors_details');
INSERT INTO "tb_applications" VALUES ('grid_instructor_classes', 'grid_instructor_classes');
INSERT INTO "tb_applications" VALUES ('grid_reservation', 'grid_reservation');
INSERT INTO "tb_applications" VALUES ('grid_reservation_list', 'grid_reservation_list');
INSERT INTO "tb_applications" VALUES ('grid_reservation_list_instructor', 'grid_reservation_list_instructor');
INSERT INTO "tb_applications" VALUES ('grid_reservation_student_detail', 'grid_reservation_student_detail');
INSERT INTO "tb_applications" VALUES ('grid_students', 'grid_students');
INSERT INTO "tb_applications" VALUES ('grid_student_classes', 'grid_student_classes');
INSERT INTO "tb_applications" VALUES ('grid_student_classes_detail', 'grid_student_classes_detail');
INSERT INTO "tb_applications" VALUES ('grid_student_classes_details', 'grid_student_classes_details');
INSERT INTO "tb_applications" VALUES ('grid_student_classes_list', 'grid_student_classes_list');
INSERT INTO "tb_applications" VALUES ('grid_student_reservation_pending', 'grid_student_reservation_pending');
INSERT INTO "tb_applications" VALUES ('grid_tb_applications', 'grid_tb_applications');
INSERT INTO "tb_applications" VALUES ('grid_tb_groups', 'grid_tb_groups');
INSERT INTO "tb_applications" VALUES ('grid_tb_users', 'grid_tb_users');
INSERT INTO "tb_applications" VALUES ('grid_venues', 'grid_venues');
INSERT INTO "tb_applications" VALUES ('grid_venues_details', 'grid_venues_details');
INSERT INTO "tb_applications" VALUES ('login', 'login');
INSERT INTO "tb_applications" VALUES ('login_2', 'Aplicacao Inicial');
INSERT INTO "tb_applications" VALUES ('menu', 'menu');
INSERT INTO "tb_applications" VALUES ('menu_system', 'menu_system');


-- ----------------------------
-- Table structure for "main"."tb_email"
-- ----------------------------

CREATE TABLE tb_email (
  idmail INTEGER NOT NULL,
  smtp varchar(60) DEFAULT NULL,
  user_name varchar(60) DEFAULT NULL,
  pswd varchar(60) DEFAULT NULL,
  from_mail varchar(40) DEFAULT NULL,
  fld_use INTEGER DEFAULT NULL,
  PRIMARY KEY (idmail)
);

-- ----------------------------
-- Records of tb_email
-- ----------------------------
INSERT INTO "tb_email" VALUES (1, 'smtp.gmail.com', 'yuri@netmake.com.br', 'c2FvcGF1bG8xMjM=', 'yuri@netmake.com.br', 0);

-- ----------------------------
-- Table structure for "main"."tb_groups"
-- ----------------------------

CREATE TABLE tb_groups (
  code INTEGER PRIMARY KEY AUTOINCREMENT,
  description varchar(50) DEFAULT NULL,
  UNIQUE (code)
);

-- ----------------------------
-- Records of tb_groups
-- ----------------------------
INSERT INTO "tb_groups" VALUES (1, 'Administrator');
INSERT INTO "tb_groups" VALUES (9, 'Student');
INSERT INTO "tb_groups" VALUES (10, 'Instructor');

-- ----------------------------
-- Table structure for "main"."tb_groups_x_apps"
-- ----------------------------

CREATE TABLE tb_groups_x_apps (
  cod_group INTEGER NOT NULL DEFAULT '0',
  cod_application varchar(150) NOT NULL,
  PRIMARY KEY (cod_group,cod_application),
  UNIQUE (cod_group,cod_application),
  CONSTRAINT tb_groups_x_apps_ibfk_1 FOREIGN KEY (cod_group) REFERENCES tb_groups (code),
  CONSTRAINT tb_groups_x_apps_ibfk_2 FOREIGN KEY (cod_application) REFERENCES tb_applications (name)
);

-- ----------------------------
-- Records of tb_groups_x_apps
-- ----------------------------
INSERT INTO "tb_groups_x_apps" VALUES (1, 'blank');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'blank');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'blank');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'calendar_classes');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'container');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'container');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'container');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'container_instructor');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'container_instructor');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'control_change_password');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'control_change_password');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'control_change_password');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'control_login');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'control_login');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'control_login');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'control_synchronize');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_add_instructors');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_add_students');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_confirm_classes_label');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'form_confirm_classes_label');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_conf_email');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_course_catalog');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'form_course_catalog');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'form_edit_instructor');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_instructors');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_register_class');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'form_register_class');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_reservation_label');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'form_reservation_label');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_students');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_tb_applications');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_tb_groups');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_tb_users');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_unregister_reservation');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'form_unregister_reservation');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'form_unregister_reservation');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'form_update_students');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'form_venues');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'form_venues');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_classes_list');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'grid_classes_list');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_course_catalog');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'grid_course_catalog');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'grid_course_catalog');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_course_catalog_self');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'grid_course_catalog_self');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_instructors');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_instructors_details');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'grid_instructors_details');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_instructor_classes');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'grid_instructor_classes');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_reservation');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_reservation_list');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'grid_reservation_list');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'grid_reservation_list');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_reservation_list_instructor');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'grid_reservation_list_instructor');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_reservation_student_detail');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'grid_reservation_student_detail');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_students');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_student_classes');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'grid_student_classes');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_student_classes_detail');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_student_classes_details');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'grid_student_classes_details');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_student_classes_list');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_student_reservation_pending');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'grid_student_reservation_pending');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_tb_applications');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_tb_groups');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_tb_users');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_venues');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'grid_venues');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'grid_venues_details');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'grid_venues_details');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'login');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'menu');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'menu');
INSERT INTO "tb_groups_x_apps" VALUES (10, 'menu');
INSERT INTO "tb_groups_x_apps" VALUES (1, 'menu_system');
INSERT INTO "tb_groups_x_apps" VALUES (9, 'menu_system');

-- ----------------------------
-- Table structure for "main"."tb_users"
-- ----------------------------

CREATE TABLE tb_users (
  email varchar(80) NOT NULL DEFAULT '''''',
  pswd varchar(40) DEFAULT NULL,
  name char(50) DEFAULT NULL,
  id_user INTEGER DEFAULT NULL,
  PRIMARY KEY (email)
);

-- ----------------------------
-- Records of tb_users
-- ----------------------------
INSERT INTO "tb_users" VALUES ('admin@scriptcase.com.br', '21232f297a57a5a743894a0e4a801fc3', 'Administrador Nacional', 0);
INSERT INTO "tb_users" VALUES ('admin@scriptcase.net', '21232f297a57a5a743894a0e4a801fc3', 'Administrador Internacional', 0);
INSERT INTO "tb_users" VALUES ('carlos@netmake.com.br', '25d55ad283aa400af464c76d713c07ad', null, 3);
INSERT INTO "tb_users" VALUES ('instructor@scriptcase.com.br', '175cca0310b93021a7d3cfb3e4877ab6', null, 16);
INSERT INTO "tb_users" VALUES ('instructor@scriptcase.net', '175cca0310b93021a7d3cfb3e4877ab6', null, 17);
INSERT INTO "tb_users" VALUES ('student@scriptcase.com.br', 'cd73502828457d15655bbd7a63fb0bc8', null, 104);
INSERT INTO "tb_users" VALUES ('student@scriptcase.net', 'cd73502828457d15655bbd7a63fb0bc8', null, 103);

-- ----------------------------
-- Table structure for "main"."tb_users_x_groups"
-- ----------------------------

CREATE TABLE tb_users_x_groups (
  email varchar(80) NOT NULL DEFAULT '',
  cod_group INTEGER NOT NULL DEFAULT '0',
  PRIMARY KEY (email),
  UNIQUE (cod_group,email),
  CONSTRAINT tb_users_x_groups_ibfk_1 FOREIGN KEY (email) REFERENCES tb_users (email),
  CONSTRAINT tb_users_x_groups_ibfk_2 FOREIGN KEY (cod_group) REFERENCES tb_groups (code)
);

-- ----------------------------
-- Records of tb_users_x_groups
-- ----------------------------
INSERT INTO "tb_users_x_groups" VALUES ('admin@scriptcase.com.br', 1);
INSERT INTO "tb_users_x_groups" VALUES ('admin@scriptcase.net', 1);
INSERT INTO "tb_users_x_groups" VALUES ('student@scriptcase.com.br', 9);
INSERT INTO "tb_users_x_groups" VALUES ('student@scriptcase.net', 9);
INSERT INTO "tb_users_x_groups" VALUES ('carlos@netmake.com.br', 10);
INSERT INTO "tb_users_x_groups" VALUES ('instructor@scriptcase.com.br', 10);
INSERT INTO "tb_users_x_groups" VALUES ('instructor@scriptcase.net', 10);

-- ----------------------------
-- Table structure for "main"."tb_user_applications"
-- ----------------------------

CREATE TABLE tb_user_applications (
  fk_user_email varchar(80) NOT NULL,
  fk_interface_name varchar(150) NOT NULL,
  PRIMARY KEY (fk_user_email,fk_interface_name),
  CONSTRAINT tb_user_applications_ibfk_1 FOREIGN KEY (fk_user_email) REFERENCES tb_users (email),
  CONSTRAINT tb_user_applications_ibfk_2 FOREIGN KEY (fk_interface_name) REFERENCES tb_applications (name)
);

-- ----------------------------
-- Records of tb_user_applications
-- ----------------------------

-- ----------------------------
-- Table structure for "main"."venues"
-- ----------------------------

CREATE TABLE venues (
  id_venues INTEGER PRIMARY KEY AUTOINCREMENT,
  venue_name varchar(40) DEFAULT NULL,
  venue_type varchar(40) DEFAULT NULL,
  address varchar(100) DEFAULT NULL,
  city varchar(60) DEFAULT NULL,
  state varchar(60) DEFAULT NULL,
  zip_code varchar(60) DEFAULT NULL,
  date_created datetime DEFAULT NULL,
  date_modified datetime DEFAULT NULL
);

-- ----------------------------
-- Records of venues
-- ----------------------------
INSERT INTO "venues" VALUES (1, 'Newton Conference Room', 'Internal Classroom', '100 5th Avenue', 'Waltham', 'Massachusetts', 02451, null, null);
INSERT INTO "venues" VALUES (2, 'Cambridge Conference Room', 'Internal Classroom', '100 Fifth Avenue', 'Waltham', 'Massachusetts', 02451, null, null);
INSERT INTO "venues" VALUES (3, 'Sales Representative', 'Event Location', 'Obere Str. 57', 'Berlin', 'Utah', '', null, '2011-08-30 09:15:15');
INSERT INTO "venues" VALUES (4, 'Phils Vegetarian Burger Barn', 'Banquet', 'Avda. de la Constituci�n, 2222', 'M�xico D.F.', 'Tennessee', '', null, '2011-08-30 09:18:52');
INSERT INTO "venues" VALUES (5, 'Peter Lacrosse Field', 'Event Location', '120 Hanover Sq.', 'London', 'Georgia', '', null, '2011-08-30 09:19:30');
INSERT INTO "venues" VALUES (6, 'Eric Stadium', 'External Classroom', 'Mataderos, 2312', 'Buenos Aires', 'Arkansas', '', null, '2011-08-30 09:18:17');
INSERT INTO "venues" VALUES (7, 'Bills Windsurf Shop', 'Event Location', 'Berguvsv�gen', 'Falkenberg', 'Colorado', '', null, '2011-08-30 09:19:58');
INSERT INTO "venues" VALUES (8, 'Elizabeth Arena', 'Event Location', 'Forsterstr. 57', 'Mannheim', 'Maine', '', null, '2011-08-30 09:20:37');
INSERT INTO "venues" VALUES (9, 'Scriptcase Conference Room', 'Outside', 'Av. Presidente Kenedy', 'Olinda', 'PE', 52060, '2012-01-31 16:40:40', null);
