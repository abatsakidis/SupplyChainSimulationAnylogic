<?php
//__NM____NM__FUNCTION__NM__//

function MailSend($destination,$subject='SC Tickets',$message='<b>message template not found!</b>'){

	if($destination == '' || empty($destination)){ return false; }

	$arr_settings = $_SESSION['ticketsettings'];
	
	$smtp_server = (!empty($arr_settings['smtpserver']))?$arr_settings['smtpserver']:'localhost';
	$smtp_user = (!empty($arr_settings['smtpuser']))?$arr_settings['smtpuser']:'';
	$smtp_pass = (!empty($arr_settings['smtppassword']))?$arr_settings['smtppassword']:'';
	$smtp_security_flag = (!empty($arr_settings['smtpsecurityflag']))?$arr_settings['smtpsecurityflag']:'';
	$smtp_port = (!empty($arr_settings['smtpport']))?$arr_settings['smtpport']:false;
	$smtp_email = (!empty($arr_settings['emailaccount']))?$arr_settings['emailaccount']:'helpdesk@scriptcase.net';
	
	 
	if($smtp_security_flag == 'Y' && $smtp_port == false){
		$smtp_port = '465';		
		
	}
	elseif($smtp_security_flag == '' && $smtp_port == false){
		$smtp_port = '25';

	}
	
	
	
	
	sc_mail_send($smtp_server, $smtp_user, 
	             $smtp_pass, $smtp_email, $destination, $subject, 
	             $message, "H", "" , "", $smtp_port, $smtp_security_flag, "");
	             
	
}


function P_MailSend($destination,$subject='SC Tickets',$message='<b>message template not found!</b>',$conn_id){

	if($destination == '' || empty($destination)){ return false; }

	$arr_settings = $_SESSION['ticketsettings'];		
	
	$smtp_email = (!empty($arr_settings['emailaccount']))?$arr_settings['emailaccount']:'helpdesk@scriptcase.net';

	sc_mail_send2($conn_id,  $smtp_email, $destination, $subject, $message, "H", "", "",  "");	 		
}

function P_MailConnect($conn_id)
{
	
	$arr_settings = $_SESSION['ticketsettings'];
	
	$smtp_server = (!empty($arr_settings['smtpserver']))?$arr_settings['smtpserver']:'localhost';
	$smtp_user = (!empty($arr_settings['smtpUser']))?$arr_settings['smtpuser']:'';
	$smtp_pass = (!empty($arr_settings['smtppassword']))?$arr_settings['smtppassword']:'';
	$smtp_security_flag = (!empty($arr_settings['smtpsecurityflag']))?$arr_settings['smtpsecurityflag']:'';
	$smtp_port = (!empty($arr_settings['smtpport']))?$arr_settings['smtpport']:false;
	
	if($smtp_security_flag == 'Y' && $smtp_port == false){
		$smtp_port = '465';		
		
	}
	elseif($smtp_security_flag == '' && $smtp_port == false){
		$smtp_port = '25';

	}

	sc_mail_connect($conn_id, $smtp_server, $smtp_user, $smtp_pass,  $smtp_port, $smtp_security_flag);

}

function P_MailDisconnect($conn_id)
{
	sc_mail_disconnect($conn_id);
}

function GetCustomerEmail($customerid){

	$str_sql = "SELECT customeremail FROM customer WHERE customerid = $customerid";
	sc_lookup(dataset,$str_sql);
	
	if({dataset} == false){
		return false;
	}	
	else{
		return {dataset}[0][0];
	}
}

function GetTemplateEmailStaff($status_id,$staff_id){

	if($staff_id == ''){ return false; }
	
	$str_sql = "SELECT stafflanguage FROM staff where staffid = $staff_id";
	sc_lookup(dataset,$str_sql);
	
	$languageid = {dataset}[0][0];
	
	if ($languageid == '') { return false; }
	
	$str_sql = "SELECT content,title FROM ticket_email_tpl M 
                    WHERE (M.ticketlanguage = '$languageid') and
	                  (M.statusid = '$status_id') and
	                  (M.usertype = 2) and 
	                  (M.enabled = 'Y') ";	

	sc_lookup(dataset1,$str_sql);

	if({dataset1} == false){
		return false;
	}	
	else{
		$arr_result['MESSAGE'] = {dataset1}[0][0];
		$arr_result['TITLE'] = {dataset1}[0][1];
		return $arr_result;
	}
	
}



function GetTemplateEmailCustomer($status_id,$customerid){

	if($customerid == ''){ return false; }

	$str_sql = "SELECT customerlanguage FROM customer WHERE customerid = $customerid";
	sc_lookup(dataset,$str_sql);
	
	$languageid = {dataset}[0][0];

	if($status_id == ''){ return false; }
	if($languageid == ''){ return false; }

	$str_sql = "SELECT content,title FROM ticket_email_tpl M 
                    WHERE (M.ticketlanguage = '$languageid') and
	                  (M.statusid = '$status_id') and
	                  (M.usertype = 1) and 
	                  (M.enabled = 'Y')";
			
	sc_lookup(dataset1,$str_sql);

	if({dataset1} == false){ 
		return false; 
	}	
	else{
		$arr_result['MESSAGE'] = {dataset1}[0][0];
		$arr_result['TITLE'] = {dataset1}[0][1];
		return $arr_result; 
	}
}

?>