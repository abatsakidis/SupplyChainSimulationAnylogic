<?php
//__NM__retrieves necessary data for chars__NM__FUNCTION__NM__//

function get_project_data($id_project){

    sc_lookup(prj,"SELECT * FROM projects WHERE projectid = $id_project ");
    
    $arr_project_data['recordowner'] 		= {prj[0][1]};
    $arr_project_data['projectlead'] 		= {prj[0][2]};
    $arr_project_data['lastmodifiedby'] 	= {prj[0][3]};
    $arr_project_data['projectname'] 		= {prj[0][4]};
    $arr_project_data['company'] 		= {prj[0][5]};
    $arr_project_data['contactname'] 		= {prj[0][6]};
    $arr_project_data['summary'] 		= {prj[0][7]};
    $arr_project_data['estimatedprojectstart'] 	= {prj[0][8]};
    $arr_project_data['estimatedprojectend'] 	= {prj[0][9]};
    $arr_project_data['projectpriority'] 	= {prj[0][10]};
    $arr_project_data['projectstatus'] 		= {prj[0][11]};
    $arr_project_data['notes'] 			= {prj[0][12]};
    $arr_project_data['start'] 			= {prj[0][13]};
    $arr_project_data['plannedfinishdate'] 	= {prj[0][14]};
    $arr_project_data['percentecomplete'] 	= {prj[0][15]};
    $arr_project_data['customercontact'] 	= {prj[0][16]};
    $arr_project_data['actualcost'] 		= {prj[0][17]};
    $arr_project_data['estimatedcost'] 		= {prj[0][18]};    
    $arr_project_data['actualhours'] 		= {prj[0][19]};
    $arr_project_data['estimetedhours'] 	= {prj[0][20]};
    $arr_project_data['percentoverbudget'] 	= {prj[0][21]};
    $arr_project_data['datecreated'] 		= {prj[0][22]};
    $arr_project_data['datemodified'] 		= {prj[0][23]};
    
    
    $arr_project_info['project'] = $arr_project_data;
    
    return($arr_project_info);
    
}

function get_projects_tasks($id_project){

    sc_lookup(tasks,"SELECT
			   tasks.taskid,
			   tasks.taskname,
			   tasks.startdate,
			   tasks.finishdate
		     FROM
			   projects INNER JOIN tasks ON projects.projectid = tasks.projectid
		     WHERE 
			   projects.projectid = $id_project ");

    			   
    foreach({tasks} as $task)
    {
        $arr_tasks[$task[0]]['id']     = $task[0];
        $arr_tasks[$task[0]]['name']   = $task[1];
        $arr_tasks[$task[0]]['start']  = $task[2];
        $arr_tasks[$task[0]]['finish'] = $task[3];
                                
    } 			   
    
    return($arr_tasks);

}

?>