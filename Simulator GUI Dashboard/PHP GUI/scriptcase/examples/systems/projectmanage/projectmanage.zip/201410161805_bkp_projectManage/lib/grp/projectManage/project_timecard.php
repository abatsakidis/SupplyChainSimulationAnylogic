<?php
//__NM____NM__FUNCTION__NM__//

	function UpdateProjectBudget($int_timecardid,$int_projectid,$int_resourceid){
		
		
		$str_sql = "select (Sun+Mon+Tue+Wed+Fri+Sat) from timecard 
		            where timecardid = $int_timecardid";
		
		sc_lookup(dataset,$str_sql);
		
		$int_totalhours = {dataset}[0][0];
		
		$str_sql = "select rate from resources where resourceid = $int_resourceid";
		
		sc_lookup(dsresource,$str_sql);
		
		$int_resourcerate = {dsresource}[0][0];
		$int_totalcost = ($int_resourcerate*$int_totalhours);
					
		$str_update = "UPDATE 
		                   projects 
		               SET actualcost = actualcost + $int_totalcost,
		                   actualhours = actualhours + $int_totalhours
		               Where
		                   projectid = $int_projectid";    
	
		sc_exec_sql($str_update);
		
	
	}


	function deleteTimecardProjectBudget($int_timecardid,$int_projectid,$int_resourceid){
		     
		
		
		$str_sql = "select (sun+mon+tue+wed+fri+sat) from timecard 
		            where timecardid = $int_timecardid";
		
		sc_lookup(dataset,$str_sql);
		
		$int_totalhours = {dataset}[0][0];
		
		$str_sql = "select rate from resources where resourceid = $int_resourceid";
		
		sc_lookup(dsresource,$str_sql);
		
		$int_resourcerate = {dsresource}[0][0];
		$int_totalcost = ($int_resourcerate*$int_totalhours);
					
		$str_update = "UPDATE 
		                   projects 
		               SET actualcost = actualcost - $int_totalcost,
		                   actualhours = actualhours - $int_totalhours
		               Where
		                   projectid = $int_projectid";    
	
		sc_exec_sql($str_update);	
	
	}




?>