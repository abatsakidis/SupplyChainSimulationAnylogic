<?php
//__NM____NM__FUNCTION__NM__//

	function getDocumentRevision($int_document){
		$int_revision = 1;
		
		$str_sql = "SELECT COUNT(*) FROM documenthistory
		            WHERE documentlibraryid = $int_document";
		
		sc_lookup(dataset,$str_sql);
		$int_revision = (!empty({dataset}[0][0]))?(int){dataset}[0][0]+1:1;
		return $int_revision;
	
	}
	
	function unsetDocumentCurrent($int_document){
	
		$str_sql = "UPDATE documenthistory SET documentcurrent = 'N' 
		            WHERE documentlibraryid = $int_document";
		sc_exec_sql($str_sql);            
	
	}
	
	
	
	
	function getFieldByTable($str_table){
	
		$str_delete = "DELETE FROM lookup WHERE Key = '$str_table'";
		sc_exec_sql($str_delete);
		
		$str_sql = "PRAGMA table_info($str_table)";
		
		sc_lookup(dstable,$str_sql);
		
		foreach({dstable} as $arr_field){
			$code = $arr_field[1];
			$desc = $arr_field[1];
			$type = $arr_field[2];
			$key  = $str_table; 
			$str_insert = "INSERT INTO lookup VALUES ('$code','$key','$desc','$type');";
			print_r($str_insert.'<br />');
			//sc_exec_sql();
		}
				
	}
	
	function calcProjectPercentOverBudget(){
	
		{percentoverbudget} = ({actualcost}/{estimatedcost})*100;
	
	}
	
	function projectStartDate(){

		if(strtoupper({projectstatus}) == 'OPEN' && {start} == 'null'){
			{start} = date('Y-m-d');
		}	
	}
	
	function projectPlannedFinishDate(){
	
		if(strtoupper({projectstatus}) == 'COMPLETED' && {plannedfinishdate} == 'null'){
			{plannedfinishdate} = date('Y-m-d');
		}
	
	}
	
	function projectPercenteComplete(){
	
		$str_sql = "SELECT
			      avg(percentcomplete)
			    FROM
			       tasks
			    WHERE 
			       (projectid = {projectid})";
		sc_lookup(dataset,$str_sql);
		
		$int_percentecomplete = {dataset}[0][0];
		
		$str_update = "UPDATE projects SET percentecomplete = $int_percentecomplete
		               WHERE projectid = {projectid} ";

		sc_exec_sql($str_update);
		
		return $int_percentecomplete;
	
	}
	
	function refreshParent(){
	
		echo "<script>window.openner.nm_recarga_form();</script>";
	}
	
	function warningForm($str_title, $str_message, $int_left=100, $int_top=100, $int_width=400,$action=''){

	$str_possition = "position:absolute; left:".$int_left."px; top:".$int_top."px; ";
 	if($action == 'RETURN') $str_possition = '';
 
		 $str_html = "
			<table id='scwarningid' cellspacing='0' cellpading='0' 
			 style='".$str_possition." border:1px solid #d1dceb; width:".$int_width."px; z-index:300; background-color:#FFFFFF' >
			<tr>
			  <td background='../_lib/img/bgGrid.png' style='font-size:12px; font-weight:bolder;' >
			  <a href='#' onclick=\"document.getElementById('scwarningid').style.display='none';\">
			    <img src='../_lib/img/grp__NM__ok.gif' border='0' /></a>
			  ".$str_title."
			  </td>
			</tr>
			<tr>
			  <td style='font-size:12px; padding:10px'>".$str_message."  
			  </td>
			</tr>
			</table>
		"; 
 
	 	if($action == 'RETURN') return $str_html;
	 	else echo $str_html;
 
 
	}
	
	function alertForm($str_message){
		echo "<script>alert('".$str_message."');</script>";
	}
	
	
	

?>