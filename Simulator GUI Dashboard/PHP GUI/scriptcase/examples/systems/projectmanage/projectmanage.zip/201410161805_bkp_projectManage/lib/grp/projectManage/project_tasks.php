<?php
//__NM____NM__FUNCTION__NM__//


function projectTaskComplete(){

	if(strtoupper({taskstatus})== 'COMPLETED'){

		{percentcomplete} = 100;
		sc_field_readonly({percentcomplete},'on');
		{actualfinishdate} = date('Y-m-d');
		sc_field_readonly({actualfinishdate},'on');
		sc_field_display({actualfinishdate},'on');
	}
	else{

		sc_field_readonly({percentcomplete},'off');	
		sc_field_display({actualfinishdate},'off');
		{actualfinishdate} = 'null';
	}
}


function taskDaysOverDue(){

	$result = sc_dif_date({actualfinishdate}, "aaaa-mm-dd", {finishdate}, "aaaa-mm-dd");

	if($result > 0 ){
		{daysoverdue} = $result;
	}

}


function updateTaskDaysOverdue(){

	$str_sql = "select taskid,taskstatus, actualfinishdate, finishdate from tasks";
	sc_lookup(dataset,$str_sql);
	
	if(empty({dataset})) return false;
	
	foreach({dataset} as $arr_task){
		
		$taskid = $arr_task[0];
		$status = $arr_task[1];
		$actualfinishdate = $arr_task[2];
		$finishdate = $arr_task[3];
		

		if($status != 'COMPLETED'){
			$result = sc_dif_date(date('Y-m-d'), "aaaa-mm-dd", $finishdate, "aaaa-mm-dd");
			if($result  > 0 ){
				$str_update = "UPDATE tasks SET daysoverdue = $result 
				               WHERE taskid = $taskid";
				sc_exec_sql($str_update);
			}
		
		}
		elseif($actualfinishdate == '' || $actualfinishdate == '0000-00-00'){

			$actualfinishdate = date('Y-m-d');
			$result = sc_dif_date(date('Y-m-d'), "aaaa-mm-dd", $finishdate, "aaaa-mm-dd");

			if($result  > 0 ){
				$str_update = "UPDATE tasks SET daysoverdue = $result,
				                                actualfinishdate = '".date('Y-m-d')."' 
				               WHERE taskid = $taskid";
				sc_exec_sql($str_update);
			}
			else{
				$str_update = "UPDATE tasks SET actualfinishdate = '".date('Y-m-d')."' 
				               WHERE taskid = $taskid";
				sc_exec_sql($str_update);
			
			}
			
		}
	
	}
	
}


?>