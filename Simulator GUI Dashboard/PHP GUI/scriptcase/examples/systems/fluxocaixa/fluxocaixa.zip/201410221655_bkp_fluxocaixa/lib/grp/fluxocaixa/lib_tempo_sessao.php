<?php
//__NM__Biblioteca tempo de sessão__NM__FUNCTION__NM__//
function Tempo()
{
  // aplicacao que sera direcionado em caso de vencer a sessao
  $aplicacao = sc_make_link(grid_sessao_expirada);

// recuperando tempo em segundos
  sc_lookup(rsttempo,"SELECT tempo_sessao FROM tbl_configuracoes");

  $tempo = {rsttempo[0][0]};

echo "<table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#A2C833' width='100%'>
  <tr>
    <td width='100%' bordercolorlight='#A2C833' bordercolordark='#A2C833' bgcolor='#A2C833'>
    <font color='#FFFFFF'>Sess�o encerra-se em: </font>
    <font id='ur' size='02' face='Trebuchet MS, Verdana, Arial, sans-serif' color='#FFFFFF'></font>
    </td>
  </tr>
</table>
   <script>
	UR_Nu = ".$tempo.";
function UR_Start()
{
    if(UR_Nu==".$tempo.")
       UR_Indhold = convminuto(UR_Nu);
    else if(UR_Nu<".$tempo." && UR_Nu>0)
     	UR_Indhold = convminuto(UR_Nu);
    else
        parent.location.href='".$aplicacao."';

        document.getElementById('ur').innerHTML = UR_Indhold;
	setTimeout('UR_Start()',1000);
	UR_Nu = UR_Nu - 1;

}

function convminuto(valor)
{
     minuto  = Math.floor(valor/60);
     segundo = eval(valor%60);

     segundo = Math.round(segundo);

     if(segundo<10)
         return '0'+minuto+':'+'0'+segundo;
     else
          return '0'+minuto+':'+segundo;
}
UR_Start();
</script>";
}
?>