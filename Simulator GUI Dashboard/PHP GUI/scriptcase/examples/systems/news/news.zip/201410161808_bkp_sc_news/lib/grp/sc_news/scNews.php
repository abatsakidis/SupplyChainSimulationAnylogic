<?php
//__NM____NM__FUNCTION__NM__//
function populateNews()
{
	
sc_lookup(rs, "SELECT count(*) FROM news_noticias");

if(isset({rs[0][0]}) && {rs[0][0]} == '0')
{
	$base_date_year  = date("Y");
	$base_date_month = date("m");
	$base_date_day   = date("d");
	$arr_sqls_inserts = array();
	switch([sc_glo_tpbanco])
	{
		case 'pdo_mysql':
		case 'mysql':
		case 'mysqlt':
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `news_noticias` VALUES ('5', '3', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '00:00:00', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:36:13', 'The obama agenda', '<p>Obama transition began before Election Day \nEven before Sen. Barack Obama won the presidential election, he was quietly \nbuilding a transition team. On Wednesday, the president-elect met with key \nadvisers and began making decisions about his transition team, including who will \nserve as his White House chief of staff. Reports say Obama is close to naming \nIllinois Rep. Rahm Emanuel to that post, but that has not been confirmed</p>', 0x6F62616D612E6A7067, 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `news_noticias` VALUES ('6', '1', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '00:00:00', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:52:00', 'Swede Stenson leads Champions tournament', '<p>Henrik Stenson \nfires a 7-under 65 in Shanghai on Thursday for a one-stroke first round lead in the \nHSBC Champions tournament ahead of defending champion Phil Mickelson, Sergio \nGarcia, Anthony Kim and Adam Scott. full story</p>', 0x676F6C662E6A7067, 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `news_noticias` VALUES ('7', '4', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '00:00:00', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:50:44', 'Law and Order goes for a record', '<p>The outburst comes from \nAnthony Anderson, who is describing the essential qualities of Kevin Bernard, the \nlatest detective to join NBC-TV\'s long-running Law & Order. The fun-loving and \nfunny Anderson debuted last season as Bernard and resumes busting bad guys on \nWednesday, 10 p.m. ET, with the season opener.</p>', 0x6C61772E6A7067, 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `news_noticias` VALUES ('8', '3', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '00:00:00', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:45:01', 'Ahmadinejad\'s visit to Brazil draws criticism', '<p>Iranian President \nMahmoud Ahmadinejad and Brazilian counterpart Luiz Inacio Lula da Silva signed a \nseries of agreements Monday after the controversial Iranian leader arrived at the \nfirst of three Latin American nations he will visit this week.</p>n<p>Ahmadinejad \nalready visited Gambia on a five-nation trip that also will take him to Bolivia and \nVenezuela in South America and Senegal in Africa</p>n<p>...</p>', 0x6C756C612E6A7067, 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `news_noticias` VALUES ('10', '3', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '14:58:57', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:47:24', 'Obama will change', '<p>Obama sad that in your mandat the United \nStates will break and lost the title of First Economy of the World.</p>', 0x6F62616D61312E6A7067, 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `news_noticias` VALUES ('11', '3', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '16:04:55', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:48:46', ' Obama: \'It is time for us to transition to the Iraqis\'', '<p>President \nObama lauded the U.S. military in Baghdad on Tuesday during an unannounced \nvisit to Iraq, reminding troops that the next 18 months will be difficult as the United \nStates plans to start withdrawing its forces.<br /><br />I was just discussing this \nwith your commander, but I think it\'s something that all of you know. It is time for \nus to transition to the Iraqis, Obama said, according to a transcript from the White \nHouse. They need to take responsibility for their country and for their \nsovereignty.<br /><br />And in order for them to do that, they have got to make \npolitical accommodations. They\'re going to have to decide that they want to \nresolve their differences through constitutional means and legal means. They are \ngoing to have to focus on providing government services that encourage \nconfidence among their citizens.<br /><br />A new CNN/Opinion Research \nCorporation poll found that 79 percent of Americans surveyed feel that Obama has \nhad a more positive effect on how people in other countries view the U.S. Only 19 \npercent of those surveyed thought he\'s had a more negative effect.<br /><br \n/>The poll also indicated that only 35 percent of Americans currently approve of \nthe U.S. war in Iraq; 65 percent disapprove.<br />Almost seven in 10 Americans \nagree with Obama\'s plan to remove most U.S. troops from Iraq by next August, \nwhile leaving a residual force of between 35,000 and 50,000 troops.</p>', 0x6F62616D61332E6A7067, 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `news_noticias` VALUES ('12', '1', 'reporter', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '16:04:04', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:32:13', 'Tar Heels Tourney Romp Ends With Title', '<p>DETROIT -- The heckling \nalways came in summertime pickup games at the Dean Dome, when players from \nNorth Carolina\'s 2005 national-title team would square off against the ringless \nmembers of the program\'s current roster. The worst offenders were <strong>Sean \nMay</strong>, <strong>Raymond Felton</strong>, and <strong>Melvin \nScott</strong>, who tended to end any dispute -- over things as trivial as foul calls \nanswer, for the entire careers of current stars <strong>Ty Lawson</strong>, \n<strong>Wayne Ellington</strong> and <strong>Tyler Hansbrough</strong>, had \nbeen no. And so in the aftermath of Monday\'s 89-72 national-championship game \nrout of Michigan State, some of the Tar Heels\' thoughts turned to bragging rights. \nAs Lawson said, before breaking into one of his trademark, devilish grins, I mean, \nwhat can they say now?<br /><br />Nothing, really, given the magnitude of the \nrout: The Tar Heels scored 55 first-half points and led by 21 at the break -- both \ntitle-game records -- and essentially put the game away in the first 10 minutes. It \nwas an epic beatdown that brought Carolina its fifth championship and sucked the \nlife out of a record crowd of 72,922 in Detroit, an economically struggling city that \nhad rallied around Michigan State\'s fairy-tale ride to the final. Ellington was named \nMOP after scoring 19 points, but it was Lawson who was masterful, getting to the \nfree-throw line for 18 attempts (and converting 15 of them) to finish with 21 points, \nsix assists and an amazing eight steals.<br /><br />On Sunday, he had reminisced \nabout acting out approximately 20 different NCAA-championship buzzer-beater \nscenarios on his Fisher Price hoop as a child: Sometimes I needed a three to win \nit, sometimes I was on the free-throw line, sometimes I was making a last-second \ndrive when we were down one, Lawson said, and we won every single time. But \nwhen a writer tried to goad Lawson into saying that he was dreaming of making an \nactual, last-second shot on Monday, he said, I hope it won\'t be that close. I like \nblowouts better.<br /><br />A blowout is exactly what Lawson got -- one much \nlike the 35-point massacre that occurred the first time the two teams met, on Dec. \n3, in the same building. He and Ellington had talked to each other about not starting \nslow, the way they did against Kansas in last year\'s Final Four, when they came \nout shell-shocked and fell behind 40-12. Instead, they were the ones giving \nMichigan State what coach <strong>Tom Izzo</strong> described as that deer-in-\nthe-headlights look, as the Spartans trailed 21-7, then 32-11, then 46-22 and 55-\n34 at half. Izzo\'s floor leader, senior guard <strong>Travis Walton</strong>, \nadmitted that it was a blur the first five minutes, when they jumped out on us so \nfast.<br /><br />When the Tar Heels finally subbed out their starters, en masse, \nwith 1:03 left in the game, they led 89-70, and Lawson still hadn\'t broken much of \na sweat. Close games are nerve-wracking, Lawson said. When you have a \nblowout, everyone has fun. Even my boy Marc -- he nodded toward walk-on \n<strong>Marc Campbell</strong>, who had replaced him -- got in and got some \ntime on a national stage.<br /><br />As confetti streamed down from the Ford \nField ceiling in the aftermath, the player who appeared to be having the most fun \nwas the one who had, up to that point, been the most robotic and businesslike. \nHansbrough, who arrived in <strong>Roy Williams</strong>\' first recruiting class \nfollowing that \'05 national title, beamed as he bear-hugged his coach on the court, \nand later jumped into the arms of Carolina strength coach <strong>Jonas \nSahratian</strong>, the man responsible for giving Hansbrough the nickname \nPsycho T during his freshman year. This, Sahratian said, was the biggest day of \nTyler\'s life, I think. It\'s what he\'d been working for.<br /><br />Despite winning \nthe Wooden and Naismith Awards as a junior, Hansbrough\'s legacy was ultimately \ngoing to be defined by whether or not he added a banner to the Dean Dome \nrafters. Sitting in the locker room with one of the nets around his neck, and 18 \npoints and seven rebounds in the box score, Hansbrough felt he had put an \nappropriate coda on his college career, and declared, Whoever said [I\'m] not \nvalidated, I\'m validated right now.<br /><br />This win over Michigan State also \nvalidated the entire North Carolina team, which, like it or not, would have been \nregarded as an underachiever had it not won the national title. The Heels began the \nseason as the AP Poll\'s unanimous No. 1, and were also heavy title favorites in Las \nVegas -- but then they started 0-2 in the ACC, with losses to Boston College and \nWake Forest, and, as Williams said, everybody jumped off the ship. Their defense \nappeared to be lacking with senior specialist <strong>Marcus Ginyard</strong> \nout of the lineup, and Lawson in particular was being shown up by guards such as \n<strong>Tyrese Rice</strong> and <strong>Jeff Teague</strong>. But Williams \ngathered them together in the locker room after that second loss in Winston-Salem, \nand, in front of everyone, asked a question to assistant coach <strong>Steve \nRobinson</strong>, who had also been on Williams\' staff at Kansas: Coach, do \nyou remember 1991, what we started out the season?<br /><br />We started \nout 0-2, Robinson said.<br />Do you remember where we finished that \nseason?<br />We played Duke for the national championship.<br /><br />And \nso Williams told his team that, if they did what the coaching staff asked, then \nthey\'d have a chance and be there at the end.<br /><br />The Tar Heels were \nmore than just <em>there</em> in this NCAA tournament. They blitzed their way \nthrough the bracket, beating Radford by 43 in the first round, LSU by 14 in the \nsecond, Gonzaga by 21 in the Sweet 16, Oklahoma by 12 in the Elite Eight, \nVillanova by 14 in the Final Four and Michigan State by 17 in the final. Carolina only \ntrailed its opponents for 10 minutes during the entire dance. They stepped up their \ndefense, especially on the perimeter, when it became necessary, and put on an \nexhibition in the title game, forcing the Spartans in to 21 turnovers and just 40 \npercent shooting. Carolina lost just four games all season, but, as senior guard \n<strong>Bobby Frasor</strong> said, If we had played D like this all year, it \ncould have been special.<br /><br />There was a sense, coming into Monday \nnight\'s title game, that the Tar Heels might be running up against something \nspecial -- a pre-ordained, fairy-tale story for the state of Michigan. Legendary \nSpartans point guard <strong>Earvin </strong>Magic<strong> \nJohnson</strong> had called them a team of destiny on Saturday, and it seemed \nthat Michigan State could be the right team (having knocked off two-straight No. 1 \nseeds), playing at the right time (the 30th anniversary of Magic\'s title) in the right \ncity (Detroit, which desperately needed an emotional diversion from its failing auto \nindustry). When the Spartans ran out of their locker room, point guard \n<strong>Kalin Lucas</strong> -- one of two Motor City products -- yelled, Let\'s \nwin this for the city!<br /><br />A raucous crowd -- clad in approximately 65 \npercent green and white -- was waiting for them in the stands, and those same fans \nlustily booed Carolina when it took the floor. Late Saturday night, after they beat \nVillanova to clinch a trip to the title game against the home-state team, Williams \nhad told his players to prepare for the atmosphere at Ford Field as if it were more \nfamiliar, hostile territory: Coach said, \'It\'s like going into Cameron again,\' said \nFrasor, referring to Duke\'s home court, where he and Hansbrough are 4-0. And \nfor us to make them quiet from the get-go, that was huge.<br /><br />As the \nSpartans faded quickly, so did the power of their fan advantage. It took them until \nthe 7:33 mark of the second half to reach the 55 points Carolina had scored in the \nfirst half, and the building was so quiet with 3:25 left in the game, and Carolina up \n15, that a Michigan State dance team member could be heard saying, C\'mon, \nState! We still believe in you! Not many others in the stands seemed to share that \nfeeling. Seconds later, Lawson sunk two free throws to extend UNC\'s lead to \n17.<br /><br />Carolina came into the game exuding the confidence of a club \nthat, as even Johnson admitted in a pregame press conference with 1979 NCAA \nfinal foe <strong>Larry Bird</strong>, was the best team in basketball, when you \nlook at it talent-wise. Izzo said on Sunday that the only way the Spartans could \nwin was to have a game plan that altered Carolina\'s identity, because, If we play \ngood and they play good, we\'re losing. The Heels were unfazed by Izzo scheming \nthat took them out of their transition game; they managed to win despite scoring \njust four fast-break points -- the same amount that Michigan State did. They \ntaunted Sparty, Michigan State\'s mascot, in the tunnel beforehand -- \n<strong>Danny Green</strong> yelled in his face a few times, and someone said \nfrom a distance, Sparty\'s just a b----! When the Heels charged out of their locker \nroom for the final time before the game began, they created an intimidating \namount of noise in the tunnel, by clapping in rhythm, barking, and chanting Here \n... We ... Go!<br /><br />From there the Heels went, unfazed by the crowd, and \nsteamrolled Michigan State to win what was expected of them in the preseason: the \nnational title. After they\'d watched <em>One Shining Moment</em> together on \nthe floor, with Williams, who had the other net around his neck, standing amongst \nthem, they raced back to the locker room to perform a final ceremony. As is \nWilliams\' tradition during the dance, there was an empty box drawn on their \nwhiteboard prior to the game, waiting to be filled in. What goes inside the box is the \nnumber of teams left in the NCAA tournament. They\'ll typically gather \'round \nWilliams to calculate the figure, but this time the math was easy. All that needed to \nbe written was a giant number one.</p>', 0x6368616D70696F6E732E6A7067, 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `news_noticias` VALUES ('13', '2', 'reporter', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '16:04:17', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:33:22', 'Fatal shooting at German courthouse', '<p>Two people were killed and \ntwo were severely wounded Tuesday in a shooting at a courthouse in Landshut, \nGermany, police said.<br /><br />The gunman, a 60-year-old man, was among \nthe dead, Bavarian Police said in a statement.<br /><br />It happened around \n10:15 a.m. (4:15 a.m. ET) during a break in a court proceeding about inheritance, \nLandshut police spokesman Leonard Mayer told CNN.<br /><br />The man began \nshooting once he stepped outside the courtroom, police said.<br /><br />He \nwounded three people before turning the gun on himself, Mayer said. One of the \nvictims, a woman, died about 2 1/2 hours later, Bavarian Police said.<br /><br \n/>The lives of the two wounded victims are not in danger, he told CNN.<br /><br \n/>The courthouse has no metal detectors or security checks that would have \nturned up the shooter\'s weapon, Mayer said.<br /><br />This latest shooting in \nGermany took place less than a month after a school massacre in the southwestern \ntown of Winnenden, in which a total of 16 people were killed.</p>', 0x706F6C6963652E6A7067, 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO `news_noticias` VALUES ('14', '4', 'reporter', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '14:30:49', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:45:03', 'The greatest car chases in movie history', '<p>LONDON, England ? What is it about the car chase? This action staple isrnalmost as old as cinema itself, and the incredible success of ?Fastrn& Furious? the latest high-octane joyride to hit cinema screensrnshows the almost supernatural allure the prospect of a quality chasernexerts on a certain kind of movie-goer.</p>\n<p>rn</p>\n<p>Although they date back to silent film series like the ?KeystonernCops? in 1912, most agree the modern car chase was born with ?Bullitt?rnin 1968, which features Steve McQueen as the titular hard-nosed coprndetailed to protect a star witness.</p>\n<p>rn</p>\n<p>In this endlessly imitated sequence, Bullitt screeches up and downrnthe hilly streets of San Francisco at the wheel of a Ford Mustang GT,rnhitting speeds of up to 185km/hour (115 miles/hour). An expertrnautomobile and motorcycle racer in real life, the sequence is all thernmore impressive when you find out McQueen did almost all his own stuntrndriving.</p>\n<p>rn</p>\n<p>William Friedkin upped the realism in ?The French Connection?rn(1971), which stars a fresh-faced Gene Hackman as New York City policerndetective Jimmy ?Popeye? Doyle who wrestles an increasinglyrnbattered-looking 1971 Pontiac LeMans around the road underneath anrnelevated train he is chasing in Brooklyn.</p>\n<p>rn</p>\n<p>Many of the scenes in this chase are real, including the car crash,rnwhich was unplanned and caused when a local man drove onto the set notrnrealizing what was happening. The producers later paid for repairs.</p>\n<p>rn</p>\n<p>Other honorable mentions include: ?Cannonball Run? (1981) for thernspectacular cars including a Ferrari 308 GTS and Aston Martin DB5, ?ThernItalian Job? (1969) for an incredibly hip car chase featuring red,rnwhite and blue Minis that personify swinging 60s London, StevenrnSpielberg?s 1971 TV movie ?Duel,? which is really just one extendedrnchase scene.</p>\n<p>rn</p>\n<p>Car chases have gotten progressively more complicated since the 70s,rnwith computer graphics (CGI) allowing filmmakers to conjure up scenesrnthat would have been unthinkable using only stuntmen ? just think ofrnthe impossibly violent crashes in the main chase scene in last year?srn?The Dark Knight.?</p>\n<p>rn</p>\n<p>Some critics say all this CGI tomfoolery makes chase scenes lookrnfake; that they don?t require the same amount of skill from stuntmen.rnThe dodgy CGI chase scene in Luc Besson?s otherwise brilliant ?ThernFifth Element? (1997) could be held up as an example of this ? althoughrnquite how they would have made taxis really hover 12 stories up isrnanother question entirely.</p>\n<p>rn</p>\n<p>One of the most famous proponents of this view is Quentin Tarantino,rnwho put his money where his mouth is with ?Death Proof? (2007) whichrnfeatures a long, climactic chase scene featuring stripped down 1969rnDodge Charger and a heavily modified 1970 Dodge Challenger completernwith a girl clinging precariously to the hood ? and absolutely no CGI.</p>\n<p>rn</p>\n<p>Other contemporary chase scenes that deserve an honorable mentionrninclude the BMW vs. Peugeot car chase through the streets of Paris and,rnnerve-wrackingly, the wrong way up an autoroute in espionage caperrn?Ronin? (1998) and Paul Greengrass? ?Bourne? trilogy.</p>', 0x6361722E6A7067, 'S')
EOT;

		break;
		case 'pdosqlite':
		case 'sqlite':
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "news_noticias" ("noticia_id", "categoria_id", "reporter_id", "noticia_data_noticia", "noticia_hora_noticia", "noticia_data_pub", "noticia_hora_pub", "noticia_titulo", "noticia_corpo", "noticia_img", "noticia_flag_man_editorial") VALUES (5,	3,	'editor',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'00:00:00',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'11:36:13',	'The obama agenda',	'<p>Obama transition began before Election Day 
Even before Sen. Barack Obama won the presidential election, he was quietly 
building a transition team. On Wednesday, the president-elect met with key 
advisers and began making decisions about his transition team, including who will 
serve as his White House chief of staff. Reports say Obama is close to naming 
Illinois Rep. Rahm Emanuel to that post, but that has not been confirmed</p>',	'obama.jpg',	'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "news_noticias" ("noticia_id", "categoria_id", "reporter_id", "noticia_data_noticia", "noticia_hora_noticia", "noticia_data_pub", "noticia_hora_pub", "noticia_titulo", "noticia_corpo", "noticia_img", "noticia_flag_man_editorial") VALUES (6,	1,	'editor',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'00:00:00',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'11:52:00',	'Swede Stenson leads Champions tou ament',	'<p>Henrik Stenson 
fires a 7-under 65 in Shanghai on Thursday for a one-stroke first round lead in the 
HSBC Champions tou ament ahead of defending champion Phil Mickelson, Sergio 
Garcia, Anthony Kim and Adam Scott. full story</p>',	'golf.jpg',	'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "news_noticias" ("noticia_id", "categoria_id", "reporter_id", "noticia_data_noticia", "noticia_hora_noticia", "noticia_data_pub", "noticia_hora_pub", "noticia_titulo", "noticia_corpo", "noticia_img", "noticia_flag_man_editorial") VALUES (7,	4,	'editor',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'00:00:00',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'11:50:44',	'Law and Order goes for a record',	'<p>The outburst comes from 
Anthony Anderson, who is describing the essential qualities of Kevin Be ard, the 
latest detective to join NBC-TV''s long-running "Law & Order." The fun-loving and 
funny Anderson debuted last season as Be ard and resumes busting bad guys on 
Wednesday, 10 p.m. ET, with the season opener.</p>',	'law.jpg',	'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "news_noticias" ("noticia_id", "categoria_id", "reporter_id", "noticia_data_noticia", "noticia_hora_noticia", "noticia_data_pub", "noticia_hora_pub", "noticia_titulo", "noticia_corpo", "noticia_img", "noticia_flag_man_editorial") VALUES (8,	3,	'editor',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'00:00:00',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'11:45:01',	'Ahmadinejad''s visit to Brazil draws criticism',	'<p>Iranian President 
Mahmoud Ahmadinejad and Brazilian counterpart Luiz Inacio Lula da Silva signed a 
series of agreements Monday after the controversial Iranian leader arrived at the 
first of three Latin American nations he will visit this week.</p>n<p>Ahmadinejad 
already visited Gambia on a five-nation trip that also will take him to Bolivia and 
Venezuela in South America and Senegal in Africa</p>n<p>...</p>',	'lula.jpg',	'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "news_noticias" ("noticia_id", "categoria_id", "reporter_id", "noticia_data_noticia", "noticia_hora_noticia", "noticia_data_pub", "noticia_hora_pub", "noticia_titulo", "noticia_corpo", "noticia_img", "noticia_flag_man_editorial") VALUES (10,	3,	'editor',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'14:58:57',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'11:47:24',	'Obama will change',	'<p>Obama sad that in your mandat the United 
States will break and lost the title of First Economy of the World.</p>',	'obama1.jpg',	'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "news_noticias" ("noticia_id", "categoria_id", "reporter_id", "noticia_data_noticia", "noticia_hora_noticia", "noticia_data_pub", "noticia_hora_pub", "noticia_titulo", "noticia_corpo", "noticia_img", "noticia_flag_man_editorial") VALUES (11,	3,	'editor',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'16:04:55',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'11:48:46',	' Obama: ''It is time for us to transition to the Iraqis''',	'<p>President 
Obama lauded the U.S. military in Baghdad on Tuesday during an unannounced 
visit to Iraq, reminding troops that the next 18 months will be difficult as the United 
States plans to start withdrawing its forces.<br /><br />"I was just discussing this 
with your commander, but I think it''s something that all of you know. It is time for 
us to transition to the Iraqis," Obama said, according to a transcript from the White 
House. "They need to take responsibility for their country and for their 
sovereignty.<br /><br />"And in order for them to do that, they have got to make 
political accommodations. They''re going to have to decide that they want to 
resolve their differences through constitutional means and legal means. They are 
going to have to focus on providing gove ment services that encourage 
confidence among their citizens."<br /><br />A new CNN/Opinion Research 
Corporation poll found that 79 percent of Americans surveyed feel that Obama has 
had a "more positive" effect on how people in other countries view the U.S. Only 19 
percent of those surveyed thought he''s had a "more negative" effect.<br /><br 
/>The poll also indicated that only 35 percent of Americans currently approve of 
the U.S. war in Iraq; 65 percent disapprove.<br />Almost seven in 10 Americans 
agree with Obama''s plan to remove most U.S. troops from Iraq by next August, 
while leaving a residual force of between 35,000 and 50,000 troops.</p>',	'obama3.jpg',	'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "news_noticias" ("noticia_id", "categoria_id", "reporter_id", "noticia_data_noticia", "noticia_hora_noticia", "noticia_data_pub", "noticia_hora_pub", "noticia_titulo", "noticia_corpo", "noticia_img", "noticia_flag_man_editorial") VALUES (12,	1,	'reporter',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'16:04:04',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'11:32:13',	'Tar Heels Tou ey Romp Ends With Title',	'<p>DETROIT -- The heckling 
always came in summertime pickup games at the Dean Dome, when players from 
North Carolina''s 2005 national-title team would square off against the ringless 
members of the program''s current roster. The worst offenders were <strong>Sean 
May</strong>, <strong>Raymond Felton</strong>, and <strong>Melvin 
Scott</strong>, who tended to end any dispute -- over things as trivial as foul calls 
answer, for the entire careers of current stars <strong>Ty Lawson</strong>, 
<strong>Wayne Ellington</strong> and <strong>Tyler Hansbrough</strong>, had 
been no. And so in the aftermath of Monday''s 89-72 national-championship game 
rout of Michigan State, some of the Tar Heels'' thoughts tu ed to bragging rights. 
As Lawson said, before breaking into one of his trademark, devilish grins, "I mean, 
what can they say now?"<br /><br />Nothing, really, given the magnitude of the 
rout: The Tar Heels scored 55 first-half points and led by 21 at the break -- both 
title-game records -- and essentially put the game away in the first 10 minutes. It 
was an epic beatdown that brought Carolina its fifth championship and sucked the 
life out of a record crowd of 72,922 in Detroit, an economically struggling city that 
had rallied around Michigan State''s fairy-tale ride to the final. Ellington was named 
MOP after scoring 19 points, but it was Lawson who was masterful, getting to the 
free-throw line for 18 attempts (and converting 15 of them) to finish with 21 points, 
six assists and an amazing eight steals.<br /><br />On Sunday, he had reminisced 
about acting out approximately 20 different NCAA-championship buzzer-beater 
scenarios on his Fisher Price hoop as a child: "Sometimes I needed a three to win 
it, sometimes I was on the free-throw line, sometimes I was making a last-second 
drive when we were down one," Lawson said, "and we won every single time." But 
when a writer tried to goad Lawson into saying that he was dreaming of making an 
actual, last-second shot on Monday, he said, "I hope it won''t be that close. I like 
blowouts better."<br /><br />A blowout is exactly what Lawson got -- one much 
like the 35-point massacre that occurred the first time the two teams met, on Dec. 
3, in the same building. He and Ellington had talked to each other about not starting 
slow, the way they did against Kansas in last year''s Final Four, when they came 
out shell-shocked and fell behind 40-12. Instead, they were the ones giving 
Michigan State what coach <strong>Tom Izzo</strong> described as that "deer-in-
the-headlights look," as the Spartans trailed 21-7, then 32-11, then 46-22 and 55-
34 at half. Izzo''s floor leader, senior guard <strong>Travis Walton</strong>, 
admitted that "it was a blur the first five minutes, when they jumped out on us so 
fast."<br /><br />When the Tar Heels finally subbed out their starters, en masse, 
with 1:03 left in the game, they led 89-70, and Lawson still hadn''t broken much of 
a sweat. "Close games are nerve-wracking," Lawson said. "When you have a 
blowout, everyone has fun. Even my boy Marc" -- he nodded toward walk-on 
<strong>Marc Campbell</strong>, who had replaced him -- "got in and got some 
time on a national stage."<br /><br />As confetti streamed down from the Ford 
Field ceiling in the aftermath, the player who appeared to be having the most fun 
was the one who had, up to that point, been the most robotic and businesslike. 
Hansbrough, who arrived in <strong>Roy Williams</strong>'' first recruiting class 
following that ''05 national title, beamed as he bear-hugged his coach on the court, 
and later jumped into the arms of Carolina strength coach <strong>Jonas 
Sahratian</strong>, the man responsible for giving Hansbrough the nickname 
Psycho T during his freshman year. "This," Sahratian said, "was the biggest day of 
Tyler''s life, I think. It''s what he''d been working for."<br /><br />Despite winning 
the Wooden and Naismith Awards as a junior, Hansbrough''s legacy was ultimately 
going to be defined by whether or not he added a banner to the Dean Dome 
rafters. Sitting in the locker room with one of the nets around his neck, and 18 
points and seven rebounds in the box score, Hansbrough felt he had put an 
appropriate coda on his college career, and declared, "Whoever said [I''m] not 
validated, I''m validated right now."<br /><br />This win over Michigan State also 
validated the entire North Carolina team, which, like it or not, would have been 
regarded as an underachiever had it not won the national title. The Heels began the 
season as the AP Poll''s unanimous No. 1, and were also heavy title favorites in Las 
Vegas -- but then they started 0-2 in the ACC, with losses to Boston College and 
Wake Forest, and, as Williams said, "everybody jumped off the ship." Their defense 
appeared to be lacking with senior specialist <strong>Marcus Ginyard</strong> 
out of the lineup, and Lawson in particular was being shown up by guards such as 
<strong>Tyrese Rice</strong> and <strong>Jeff Teague</strong>. But Williams 
gathered them together in the locker room after that second loss in Winston-Salem, 
and, in front of everyone, asked a question to assistant coach <strong>Steve 
Robinson</strong>, who had also been on Williams'' staff at Kansas: "Coach, do 
you remember 1991, what we started out the season?"<br /><br />"We started 
out 0-2," Robinson said.<br />"Do you remember where we finished that 
season?"<br />"We played Duke for the national championship."<br /><br />And 
so Williams told his team that, if they did what the coaching staff asked, then 
they''d have a chance and "be there at the end."<br /><br />The Tar Heels were 
more than just <em>there</em> in this NCAA tou ament. They blitzed their way 
through the bracket, beating Radford by 43 in the first round, LSU by 14 in the 
second, Gonzaga by 21 in the Sweet 16, Oklahoma by 12 in the Elite Eight, 
Villanova by 14 in the Final Four and Michigan State by 17 in the final. Carolina only 
trailed its opponents for 10 minutes during the entire dance. They stepped up their 
defense, especially on the perimeter, when it became necessary, and put on an 
exhibition in the title game, forcing the Spartans in to 21 tu overs and just 40 
percent shooting. Carolina lost just four games all season, but, as senior guard 
<strong>Bobby Frasor</strong> said, "If we had played D like this all year, it 
could have been special."<br /><br />There was a sense, coming into Monday 
night''s title game, that the Tar Heels might be running up against something 
special -- a pre-ordained, fairy-tale story for the state of Michigan. Legendary 
Spartans point guard <strong>Earvin </strong>"Magic"<strong> 
Johnson</strong> had called them a "team of destiny" on Saturday, and it seemed 
that Michigan State could be the right team (having knocked off two-straight No. 1 
seeds), playing at the right time (the 30th anniversary of Magic''s title) in the right 
city (Detroit, which desperately needed an emotional diversion from its failing auto 
industry). When the Spartans ran out of their locker room, point guard 
<strong>Kalin Lucas</strong> -- one of two Motor City products -- yelled, "Let''s 
win this for the city!"<br /><br />A raucous crowd -- clad in approximately 65 
percent green and white -- was waiting for them in the stands, and those same fans 
lustily booed Carolina when it took the floor. Late Saturday night, after they beat 
Villanova to clinch a trip to the title game against the home-state team, Williams 
had told his players to prepare for the atmosphere at Ford Field as if it were more 
familiar, hostile territory: "Coach said, ''It''s like going into Cameron again,''" said 
Frasor, referring to Duke''s home court, where he and Hansbrough are 4-0. "And 
for us to make them quiet from the get-go, that was huge."<br /><br />As the 
Spartans faded quickly, so did the power of their fan advantage. It took them until 
the 7:33 mark of the second half to reach the 55 points Carolina had scored in the 
first half, and the building was so quiet with 3:25 left in the game, and Carolina up 
15, that a Michigan State dance team member could be heard saying, "C''mon, 
State! We still believe in you!" Not many others in the stands seemed to share that 
feeling. Seconds later, Lawson sunk two free throws to extend UNC''s lead to 
17.<br /><br />Carolina came into the game exuding the confidence of a club 
that, as even Johnson admitted in a pregame press conference with 1979 NCAA 
final foe <strong>Larry Bird</strong>, was "the best team in basketball, when you 
look at it talent-wise." Izzo said on Sunday that the only way the Spartans could 
win was to have a game plan that altered Carolina''s identity, because, "If we play 
good and they play good, we''re losing." The Heels were unfazed by Izzo scheming 
that took them out of their transition game; they managed to win despite scoring 
just four fast-break points -- the same amount that Michigan State did. They 
taunted Sparty, Michigan State''s mascot, in the tunnel beforehand -- 
<strong>Danny Green</strong> yelled in his face a few times, and someone said 
from a distance, "Sparty''s just a b----!" When the Heels charged out of their locker 
room for the final time before the game began, they created an intimidating 
amount of noise in the tunnel, by clapping in rhythm, barking, and chanting "Here 
... We ... Go!"<br /><br />From there the Heels went, unfazed by the crowd, and 
steamrolled Michigan State to win what was expected of them in the preseason: the 
national title. After they''d watched <em>One Shining Moment</em> together on 
the floor, with Williams, who had the other net around his neck, standing amongst 
them, they raced back to the locker room to perform a final ceremony. As is 
Williams'' tradition during the dance, there was an empty box drawn on their 
whiteboard prior to the game, waiting to be filled in. What goes inside the box is the 
number of teams left in the NCAA tou ament. They''ll typically gather ''round 
Williams to calculate the figure, but this time the math was easy. All that needed to 
be written was a giant number one.</p>',	'champions.jpg',	'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "news_noticias" ("noticia_id", "categoria_id", "reporter_id", "noticia_data_noticia", "noticia_hora_noticia", "noticia_data_pub", "noticia_hora_pub", "noticia_titulo", "noticia_corpo", "noticia_img", "noticia_flag_man_editorial") VALUES (13,	2,	'reporter',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'16:04:17',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'11:33:22',	'Fatal shooting at German courthouse',	'<p>Two people were killed and 
two were severely wounded Tuesday in a shooting at a courthouse in Landshut, 
Germany, police said.<br /><br />The gunman, a 60-year-old man, was among 
the dead, Bavarian Police said in a statement.<br /><br />It happened around 
10:15 a.m. (4:15 a.m. ET) during a break in a court proceeding about inheritance, 
Landshut police spokesman Leonard Mayer told CNN.<br /><br />The man began 
shooting once he stepped outside the courtroom, police said.<br /><br />He 
wounded three people before tu ing the gun on himself, Mayer said. One of the 
victims, a woman, died about 2 1/2 hours later, Bavarian Police said.<br /><br 
/>The lives of the two wounded victims are not in danger, he told CNN.<br /><br 
/>The courthouse has no metal detectors or security checks that would have 
tu ed up the shooter''s weapon, Mayer said.<br /><br />This latest shooting in 
Germany took place less than a month after a school massacre in the southweste  
town of Winnenden, in which a total of 16 people were killed.</p>',	'police.jpg',	'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "news_noticias" ("noticia_id", "categoria_id", "reporter_id", "noticia_data_noticia", "noticia_hora_noticia", "noticia_data_pub", "noticia_hora_pub", "noticia_titulo", "noticia_corpo", "noticia_img", "noticia_flag_man_editorial") VALUES (14,	4,	'reporter',	'$base_date_year-$base_date_month-$base_date_day 00:00:00',	'14:30:49',	NULL,	'14:30:49',	'The 
greatest car chases in movie history',	'<p>LONDON, England - What is it 
about the car chase? This action staple is almost as old as cinema itself, and the 
incredible success of Fast and Furious the latest high-octane 
joyride to hit cinema screens shows the almost supe atural allure the prospect 
of a quality chase exerts on a certain kind of movie-goer.</p> <p>Although 
they date back to silent film series like the Keystone Cops in 
1912, most agree the mode  car chase was bo  with Bullitt in 
1968, which features Steve McQueen as the titular hard-nosed cop detailed to 
protect a star witness.</p> <p>In this endlessly imitated sequence, Bullitt 
screeches up and down the hilly streets of San Francisco at the wheel of a Ford 
Mustang GT, hitting speeds of up to 185km/hour (115 miles/hour). An 
expert automobile and motorcycle racer in real life, the sequence is all 
the more impressive when you find out McQueen did almost all his own 
stunt driving.</p> <p>William Friedkin upped the realism in The 
French Connection (1971), which stars a fresh-faced Gene Hackman as 
New York City police detective Jimmy Popeye Doyle who 
wrestles an increasingly battered-looking 1971 Pontiac LeMans around the road 
unde eath an elevated train he is chasing in Brooklyn.</p> <p>Many of the 
scenes in this chase are real, including the car crash, which was unplanned and 
caused when a local man drove onto the set not realizing what was happening. 
The producers later paid for repairs.</p> <p>Other honorable mentions 
include: Cannonball Run (1981) for the spectacular cars 
including a Ferrari 308 GTS and Aston Martin DB5, The Italian 
Job (1969) for an incredibly hip car chase featuring red, white and blue 
Minis that personify swinging 60s London, Steven Spielberg 1971 
TV movie Duel, which is really just one extended chase 
scene.</p> <p>Car chases have gotten progressively more complicated since 
the 70s, with computer graphics (CGI) allowing filmmakers to conjure up 
scenes that would have been unthinkable using only stuntmen - just 
think of the impossibly violent crashes in the main chase scene in last 
years The Dark Knight.</p> <p>Some critics say all 
this CGI tomfoolery makes chase scenes look fake; that they dont 
require the same amount of skill from stuntmen. The dodgy CGI chase scene in 
Luc Bessons otherwise brilliant The Fifth Element (1997) 
could be held up as an example of this - although quite how they would 
have made taxis really hover 12 stories up is another question 
entirely.</p> <p>One of the most famous proponents of this view is Quentin 
Tarantino, who put his money where his mouth is with Death 
Proof (2007) which features a long, climactic chase scene featuring 
stripped down 1969 Dodge Charger and a heavily modified 1970 Dodge 
Challenger complete with a girl clinging precariously to the hood - and 
absolutely no CGI.</p> <p>Other contemporary chase scenes that deserve an 
honorable mention include the BMW vs. Peugeot car chase through the streets 
of Paris and, nerve-wrackingly, the wrong way up an autoroute in espionage 
caper Ronin (1998) and Paul Greengrass Bou e trilogy.</p>',	'car.jpg',	'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "news_noticias" ("noticia_id", "categoria_id", "reporter_id", "noticia_data_noticia", "noticia_hora_noticia", "noticia_data_pub", "noticia_hora_pub", "noticia_titulo", "noticia_corpo", "noticia_img", "noticia_flag_man_editorial") VALUES (15,	4,	'editor',	'2012-05-14',	'11:53:09:000',	'2012-05-14',	'11:56:14',	'Soccer is going down!',	'<p>Soccer attendence is lowering pass the years.</p>',	'',	'S')
EOT;
		break;
		
		case 'access':
		case 'ado_access':
			$arr_sqls_inserts[] = <<<EOT
insert into news_noticias(noticia_id,categoria_id,reporter_id,noticia_data_noticia,noticia_hora_noticia,noticia_data_pub,noticia_hora_pub,noticia_titulo,noticia_corpo,noticia_img,noticia_flag_man_editorial)select 5,3,'editor',#$base_date_year-$base_date_month-$base_date_day#,#1899-12-30#,#$base_date_year-$base_date_month-$base_date_day#,'11:36:13','The obama agenda','<p>Obama transition began before Election Day 
Even before Sen. Barack Obama won the presidential election, he was quietly 
building a transition team. On Wednesday, the president-elect met with key 
advisers and began making decisions about his transition team, including who will 
serve as his White House chief of staff. Reports say Obama is close to naming 
Illinois Rep. Rahm Emanuel to that post, but that has not been confirmed</p>',0x6F62616D612E6A7067,'N'
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into news_noticias(noticia_id,categoria_id,reporter_id,noticia_data_noticia,noticia_hora_noticia,noticia_data_pub,noticia_hora_pub,noticia_titulo,noticia_corpo,noticia_img,noticia_flag_man_editorial)select 6,1,'editor',#$base_date_year-$base_date_month-$base_date_day#,#1899-12-30#,#$base_date_year-$base_date_month-$base_date_day#,'11:52:00','Swede Stenson leads Champions tou ament','<p>Henrik Stenson 
fires a 7-under 65 in Shanghai on Thursday for a one-stroke first round lead in the 
HSBC Champions tou ament ahead of defending champion Phil Mickelson, Sergio 
Garcia, Anthony Kim and Adam Scott. full story</p>',0x676F6C662E6A7067,'N'
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into news_noticias(noticia_id,categoria_id,reporter_id,noticia_data_noticia,noticia_hora_noticia,noticia_data_pub,noticia_hora_pub,noticia_titulo,noticia_corpo,noticia_img,noticia_flag_man_editorial)select 7,4,'editor',#$base_date_year-$base_date_month-$base_date_day#,#1899-12-30#,#$base_date_year-$base_date_month-$base_date_day#,'11:50:44','Law and Order goes for a record','<p>The outburst comes from 
Anthony Anderson, who is describing the essential qualities of Kevin Be ard, the 
latest detective to join NBC-TV''s long-running Law & Order. The fun-loving and 
funny Anderson debuted last season as Be ard and resumes busting bad guys on 
Wednesday, 10 p.m. ET, with the season opener.</p>',0x6C61772E6A7067,'S'
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into news_noticias(noticia_id,categoria_id,reporter_id,noticia_data_noticia,noticia_hora_noticia,noticia_data_pub,noticia_hora_pub,noticia_titulo,noticia_corpo,noticia_img,noticia_flag_man_editorial)select 8,3,'editor',#$base_date_year-$base_date_month-$base_date_day#,#1899-12-30#,#$base_date_year-$base_date_month-$base_date_day#,'11:45:01','Ahmadinejad''s visit to Brazil draws criticism','<p>Iranian President 
Mahmoud Ahmadinejad and Brazilian counterpart Luiz Inacio Lula da Silva signed a 
series of agreements Monday after the controversial Iranian leader arrived at the 
first of three Latin American nations he will visit this week.</p>n<p>Ahmadinejad 
already visited Gambia on a five-nation trip that also will take him to Bolivia and 
Venezuela in South America and Senegal in Africa</p>n<p>...</p>',0x6C756C612E6A7067,'N'
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into news_noticias(noticia_id,categoria_id,reporter_id,noticia_data_noticia,noticia_hora_noticia,noticia_data_pub,noticia_hora_pub,noticia_titulo,noticia_corpo,noticia_img,noticia_flag_man_editorial)select 10,3,'editor',#$base_date_year-$base_date_month-$base_date_day#,'14:58:57',#$base_date_year-$base_date_month-$base_date_day#,'11:47:24','Obama will change','<p>Obama sad that in your mandat the United 
States will break and lost the title of First Economy of the World.</p>',0x6F62616D61312E6A7067,'N'
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into news_noticias(noticia_id,categoria_id,reporter_id,noticia_data_noticia,noticia_hora_noticia,noticia_data_pub,noticia_hora_pub,noticia_titulo,noticia_corpo,noticia_img,noticia_flag_man_editorial)select 11,3,'editor',#$base_date_year-$base_date_month-$base_date_day#,'16:04:55',#$base_date_year-$base_date_month-$base_date_day#,'11:48:46',' Obama: ''It is time for us to transition to the Iraqis''','<p>President 
Obama lauded the U.S. military in Baghdad on Tuesday during an unannounced 
visit to Iraq, reminding troops that the next 18 months will be difficult as the United 
States plans to start withdrawing its forces.<br /><br />I was just discussing this 
with your commander, but I think it''s something that all of you know. It is time for 
us to transition to the Iraqis, Obama said, according to a transcript from the White 
House. They need to take responsibility for their country and for their 
sovereignty.<br /><br />And in order for them to do that, they have got to make 
political accommodations. They''re going to have to decide that they want to 
resolve their differences through constitutional means and legal means. They are 
going to have to focus on providing gove ment services that encourage 
confidence among their citizens.<br /><br />A new CNN/Opinion Research 
Corporation poll found that 79 percent of Americans surveyed feel that Obama has 
had a more positive effect on how people in other countries view the U.S. Only 19 
percent of those surveyed thought he''s had a more negative effect.<br /><br 
/>The poll also indicated that only 35 percent of Americans currently approve of 
the U.S. war in Iraq; 65 percent disapprove.<br />Almost seven in 10 Americans 
agree with Obama''s plan to remove most U.S. troops from Iraq by next August, 
while leaving a residual force of between 35,000 and 50,000 troops.</p>',0x6F62616D61332E6A7067,'S'
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into news_noticias(noticia_id,categoria_id,reporter_id,noticia_data_noticia,noticia_hora_noticia,noticia_data_pub,noticia_hora_pub,noticia_titulo,noticia_corpo,noticia_img,noticia_flag_man_editorial)select 12,1,'reporter',#$base_date_year-$base_date_month-$base_date_day#,'16:04:04',#$base_date_year-$base_date_month-$base_date_day#,'11:32:13','Tar Heels Tou ey Romp Ends With Title','<p>DETROIT -- The heckling 
always came in summertime pickup games at the Dean Dome, when players from 
North Carolina''s 2005 national-title team would square off against the ringless 
members of the program''s current roster. The worst offenders were <strong>Sean 
May</strong>, <strong>Raymond Felton</strong>, and <strong>Melvin 
Scott</strong>, who tended to end any dispute -- over things as trivial as foul calls 
answer, for the entire careers of current stars <strong>Ty Lawson</strong>, 
<strong>Wayne Ellington</strong> and <strong>Tyler Hansbrough</strong>, had 
been no. And so in the aftermath of Monday''s 89-72 national-championship game 
rout of Michigan State, some of the Tar Heels'' thoughts tu ed to bragging rights. 
As Lawson said, before breaking into one of his trademark, devilish grins, I mean, 
what can they say now?<br /><br />Nothing, really, given the magnitude of the 
rout: The Tar Heels scored 55 first-half points and led by 21 at the break -- both 
title-game records -- and essentially put the game away in the first 10 minutes. It 
was an epic beatdown that brought Carolina its fifth championship and sucked the 
life out of a record crowd of 72,922 in Detroit, an economically struggling city that 
had rallied around Michigan State''s fairy-tale ride to the final. Ellington was named 
MOP after scoring 19 points, but it was Lawson who was masterful, getting to the 
free-throw line for 18 attempts (and converting 15 of them) to finish with 21 points, 
six assists and an amazing eight steals.<br /><br />On Sunday, he had reminisced 
about acting out approximately 20 different NCAA-championship buzzer-beater 
scenarios on his Fisher Price hoop as a child: Sometimes I needed a three to win 
it, sometimes I was on the free-throw line, sometimes I was making a last-second 
drive when we were down one, Lawson said, and we won every single time. But 
when a writer tried to goad Lawson into saying that he was dreaming of making an 
actual, last-second shot on Monday, he said, I hope it won''t be that close. I like 
blowouts better.<br /><br />A blowout is exactly what Lawson got -- one much 
like the 35-point massacre that occurred the first time the two teams met, on Dec. 
3, in the same building. He and Ellington had talked to each other about not starting 
slow, the way they did against Kansas in last year''s Final Four, when they came 
out shell-shocked and fell behind 40-12. Instead, they were the ones giving 
Michigan State what coach <strong>Tom Izzo</strong> described as that deer-in-
the-headlights look, as the Spartans trailed 21-7, then 32-11, then 46-22 and 55-
34 at half. Izzo''s floor leader, senior guard <strong>Travis Walton</strong>, 
admitted that it was a blur the first five minutes, when they jumped out on us so 
fast.<br /><br />When the Tar Heels finally subbed out their starters, en masse, 
with 1:03 left in the game, they led 89-70, and Lawson still hadn''t broken much of 
a sweat. Close games are nerve-wracking, Lawson said. When you have a 
blowout, everyone has fun. Even my boy Marc -- he nodded toward walk-on 
<strong>Marc Campbell</strong>, who had replaced him -- got in and got some 
time on a national stage.<br /><br />As confetti streamed down from the Ford 
Field ceiling in the aftermath, the player who appeared to be having the most fun 
was the one who had, up to that point, been the most robotic and businesslike. 
Hansbrough, who arrived in <strong>Roy Williams</strong>'' first recruiting class 
following that ''05 national title, beamed as he bear-hugged his coach on the court, 
and later jumped into the arms of Carolina strength coach <strong>Jonas 
Sahratian</strong>, the man responsible for giving Hansbrough the nickname 
Psycho T during his freshman year. This, Sahratian said, was the biggest day of 
Tyler''s life, I think. It''s what he''d been working for.<br /><br />Despite winning 
the Wooden and Naismith Awards as a junior, Hansbrough''s legacy was ultimately 
going to be defined by whether or not he added a banner to the Dean Dome 
rafters. Sitting in the locker room with one of the nets around his neck, and 18 
points and seven rebounds in the box score, Hansbrough felt he had put an 
appropriate coda on his college career, and declared, Whoever said [I''m] not 
validated, I''m validated right now.<br /><br />This win over Michigan State also 
validated the entire North Carolina team, which, like it or not, would have been 
regarded as an underachiever had it not won the national title. The Heels began the 
season as the AP Poll''s unanimous No. 1, and were also heavy title favorites in Las 
Vegas -- but then they started 0-2 in the ACC, with losses to Boston College and 
Wake Forest, and, as Williams said, everybody jumped off the ship. Their defense 
appeared to be lacking with senior specialist <strong>Marcus Ginyard</strong> 
out of the lineup, and Lawson in particular was being shown up by guards such as 
<strong>Tyrese Rice</strong> and <strong>Jeff Teague</strong>. But Williams 
gathered them together in the locker room after that second loss in Winston-Salem, 
and, in front of everyone, asked a question to assistant coach <strong>Steve 
Robinson</strong>, who had also been on Williams'' staff at Kansas: Coach, do 
you remember 1991, what we started out the season?<br /><br />We started 
out 0-2, Robinson said.<br />Do you remember where we finished that 
season?<br />We played Duke for the national championship.<br /><br />And 
so Williams told his team that, if they did what the coaching staff asked, then 
they''d have a chance and be there at the end.<br /><br />The Tar Heels were 
more than just <em>there</em> in this NCAA tou ament. They blitzed their way 
through the bracket, beating Radford by 43 in the first round, LSU by 14 in the 
second, Gonzaga by 21 in the Sweet 16, Oklahoma by 12 in the Elite Eight, 
Villanova by 14 in the Final Four and Michigan State by 17 in the final. Carolina only 
trailed its opponents for 10 minutes during the entire dance. They stepped up their 
defense, especially on the perimeter, when it became necessary, and put on an 
exhibition in the title game, forcing the Spartans in to 21 tu overs and just 40 
percent shooting. Carolina lost just four games all season, but, as senior guard 
<strong>Bobby Frasor</strong> said, If we had played D like this all year, it 
could have been special.<br /><br />There was a sense, coming into Monday 
night''s title game, that the Tar Heels might be running up against something 
special -- a pre-ordained, fairy-tale story for the state of Michigan. Legendary 
Spartans point guard <strong>Earvin </strong>Magic<strong> 
Johnson</strong> had called them a team of destiny on Saturday, and it seemed 
that Michigan State could be the right team (having knocked off two-straight No. 1 
seeds), playing at the right time (the 30th anniversary of Magic''s title) in the right 
city (Detroit, which desperately needed an emotional diversion from its failing auto 
industry). When the Spartans ran out of their locker room, point guard 
<strong>Kalin Lucas</strong> -- one of two Motor City products -- yelled, Let''s 
win this for the city!<br /><br />A raucous crowd -- clad in approximately 65 
percent green and white -- was waiting for them in the stands, and those same fans 
lustily booed Carolina when it took the floor. Late Saturday night, after they beat 
Villanova to clinch a trip to the title game against the home-state team, Williams 
had told his players to prepare for the atmosphere at Ford Field as if it were more 
familiar, hostile territory: Coach said, ''It''s like going into Cameron again,'' said 
Frasor, referring to Duke''s home court, where he and Hansbrough are 4-0. And 
for us to make them quiet from the get-go, that was huge.<br /><br />As the 
Spartans faded quickly, so did the power of their fan advantage. It took them until 
the 7:33 mark of the second half to reach the 55 points Carolina had scored in the 
first half, and the building was so quiet with 3:25 left in the game, and Carolina up 
15, that a Michigan State dance team member could be heard saying, C''mon, 
State! We still believe in you! Not many others in the stands seemed to share that 
feeling. Seconds later, Lawson sunk two free throws to extend UNC''s lead to 
17.<br /><br />Carolina came into the game exuding the confidence of a club 
that, as even Johnson admitted in a pregame press conference with 1979 NCAA 
final foe <strong>Larry Bird</strong>, was the best team in basketball, when you 
look at it talent-wise. Izzo said on Sunday that the only way the Spartans could 
win was to have a game plan that altered Carolina''s identity, because, If we play 
good and they play good, we''re losing. The Heels were unfazed by Izzo scheming 
that took them out of their transition game; they managed to win despite scoring 
just four fast-break points -- the same amount that Michigan State did. They 
taunted Sparty, Michigan State''s mascot, in the tunnel beforehand -- 
<strong>Danny Green</strong> yelled in his face a few times, and someone said 
from a distance, Sparty''s just a b----! When the Heels charged out of their locker 
room for the final time before the game began, they created an intimidating 
amount of noise in the tunnel, by clapping in rhythm, barking, and chanting Here 
... We ... Go!<br /><br />From there the Heels went, unfazed by the crowd, and 
steamrolled Michigan State to win what was expected of them in the preseason: the 
national title. After they''d watched <em>One Shining Moment</em> together on 
the floor, with Williams, who had the other net around his neck, standing amongst 
them, they raced back to the locker room to perform a final ceremony. As is 
Williams'' tradition during the dance, there was an empty box drawn on their 
whiteboard prior to the game, waiting to be filled in. What goes inside the box is the 
number of teams left in the NCAA tou ament. They''ll typically gather ''round 
Williams to calculate the figure, but this time the math was easy. All that needed to 
be written was a giant number one.</p>',0x6368616D70696F6E732E6A7067,'S'
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into news_noticias(noticia_id,categoria_id,reporter_id,noticia_data_noticia,noticia_hora_noticia,noticia_data_pub,noticia_hora_pub,noticia_titulo,noticia_corpo,noticia_img,noticia_flag_man_editorial)select 13,2,'reporter',#$base_date_year-$base_date_month-$base_date_day#,'16:04:17',#$base_date_year-$base_date_month-$base_date_day#,'11:33:22','Fatal shooting at German courthouse','<p>Two people were killed and 
two were severely wounded Tuesday in a shooting at a courthouse in Landshut, 
Germany, police said.<br /><br />The gunman, a 60-year-old man, was among 
the dead, Bavarian Police said in a statement.<br /><br />It happened around 
10:15 a.m. (4:15 a.m. ET) during a break in a court proceeding about inheritance, 
Landshut police spokesman Leonard Mayer told CNN.<br /><br />The man began 
shooting once he stepped outside the courtroom, police said.<br /><br />He 
wounded three people before tu ing the gun on himself, Mayer said. One of the 
victims, a woman, died about 2 1/2 hours later, Bavarian Police said.<br /><br 
/>The lives of the two wounded victims are not in danger, he told CNN.<br /><br 
/>The courthouse has no metal detectors or security checks that would have 
tu ed up the shooter''s weapon, Mayer said.<br /><br />This latest shooting in 
Germany took place less than a month after a school massacre in the southweste  
town of Winnenden, in which a total of 16 people were killed.</p>',0x706F6C6963652E6A7067,'S'
EOT;
			$arr_sqls_inserts[] = <<<EOT
insert into news_noticias(noticia_id,categoria_id,reporter_id,noticia_data_noticia,noticia_hora_noticia,noticia_data_pub,noticia_hora_pub,noticia_titulo,noticia_corpo,noticia_img,noticia_flag_man_editorial)select 14,4,'reporter',#$base_date_year-$base_date_month-$base_date_day#,'14:30:49',#2012-07-02#,'11:45:03','The greatest car chases in movie history','<p>LONDON, England ? What is it about the car chase? This action staple is almost as old as cinema itself, and the incredible success of ?Fast & Furious? the latest high-octane joyride to hit cinema screens shows the almost supe atural allure the prospect of a quality chase exerts on a certain kind of movie-goer.</p>
<p> </p>
<p>Although they date back to silent film series like the ?Keystone Cops? in 1912, most agree the mode  car chase was bo  with ?Bullitt? in 1968, which features Steve McQueen as the titular hard-nosed cop detailed to protect a star witness.</p>
<p> </p>
<p>In this endlessly imitated sequence, Bullitt screeches up and down the hilly streets of San Francisco at the wheel of a Ford Mustang GT, hitting speeds of up to 185km/hour (115 miles/hour). An expert automobile and motorcycle racer in real life, the sequence is all the more impressive when you find out McQueen did almost all his own stunt driving.</p>
<p> </p>
<p>William Friedkin upped the realism in ?The French Connection? (1971), which stars a fresh-faced Gene Hackman as New York City police detective Jimmy ?Popeye? Doyle who wrestles an increasingly battered-looking 1971 Pontiac LeMans around the road unde eath an elevated train he is chasing in Brooklyn.</p>
<p> </p>
<p>Many of the scenes in this chase are real, including the car crash, which was unplanned and caused when a local man drove onto the set not realizing what was happening. The producers later paid for repairs.</p>
<p> </p>
<p>Other honorable mentions include: ?Cannonball Run? (1981) for the spectacular cars including a Ferrari 308 GTS and Aston Martin DB5, ?The Italian Job? (1969) for an incredibly hip car chase featuring red, white and blue Minis that personify swinging 60s London, Steven Spielberg?s 1971 TV movie ?Duel,? which is really just one extended chase scene.</p>
<p> </p>
<p>Car chases have gotten progressively more complicated since the 70s, with computer graphics (CGI) allowing filmmakers to conjure up scenes that would have been unthinkable using only stuntmen ? just think of the impossibly violent crashes in the main chase scene in last year?s ?The Dark Knight.?</p>
<p> </p>
<p>Some critics say all this CGI tomfoolery makes chase scenes look fake; that they don?t require the same amount of skill from stuntmen. The dodgy CGI chase scene in Luc Besson?s otherwise brilliant ?The Fifth Element? (1997) could be held up as an example of this ? although quite how they would have made taxis really hover 12 stories up is another question entirely.</p>
<p> </p>
<p>One of the most famous proponents of this view is Quentin Tarantino, who put his money where his mouth is with ?Death Proof? (2007) which features a long, climactic chase scene featuring stripped down 1969 Dodge Charger and a heavily modified 1970 Dodge Challenger complete with a girl clinging precariously to the hood ? and absolutely no CGI.</p>
<p> </p>
<p>Other contemporary chase scenes that deserve an honorable mention include the BMW vs. Peugeot car chase through the streets of Paris and, nerve-wrackingly, the wrong way up an autoroute in espionage caper ?Ronin? (1998) and Paul Greengrass? ?Bou e? trilogy.</p>',0x6361722E6A7067,'S';
EOT;
		break;
		
		case 'postgres7':
		case 'pdo_pgsql':
		case 'postgres64':
		case 'postgres':
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('5', '3', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '00:00:00', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:36:13', 'The obama agenda', '<p>Obama transition began before Election Day 
Even before Sen. Barack Obama won the presidential election, he was quietly 
building a transition team. On Wednesday, the president-elect met with key 
advisers and began making decisions about his transition team, including who will 
serve as his White House chief of staff. Reports say Obama is close to naming 
Illinois Rep. Rahm Emanuel to that post, but that has not been confirmed</p>', E'obama.jpg', 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('6', '1', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '00:00:00', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:52:00', 'Swede Stenson leads Champions tournament', '<p>Henrik Stenson 
fires a 7-under 65 in Shanghai on Thursday for a one-stroke first round lead in the 
HSBC Champions tournament ahead of defending champion Phil Mickelson, Sergio 
Garcia, Anthony Kim and Adam Scott. full story</p>', E'golf.jpg', 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('7', '4', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '00:00:00', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:50:44', 'Law and Order goes for a record', '<p>The outburst comes from 
Anthony Anderson, who is describing the essential qualities of Kevin Bernard, the 
latest detective to join NBC-TV''s long-running Law & Order. The fun-loving and 
funny Anderson debuted last season as Bernard and resumes busting bad guys on 
Wednesday, 10 p.m. ET, with the season opener.</p>', E'law.jpg', 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('8', '3', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '00:00:00', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:45:01', 'Ahmadinejad''s visit to Brazil draws criticism', '<p>Iranian President 
Mahmoud Ahmadinejad and Brazilian counterpart Luiz Inacio Lula da Silva signed a 
series of agreements Monday after the controversial Iranian leader arrived at the 
first of three Latin American nations he will visit this week.</p>n<p>Ahmadinejad 
already visited Gambia on a five-nation trip that also will take him to Bolivia and 
Venezuela in South America and Senegal in Africa</p>n<p>...</p>', E'lula.jpg', 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('10', '3', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '14:58:57', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:47:24', 'Obama will change', '<p>Obama sad that in your mandat the United 
States will break and lost the title of First Economy of the World.</p>', E'obama1.jpg', 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('11', '3', 'editor', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '16:04:55', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:48:46', ' Obama: ''It is time for us to transition to the Iraqis''', '<p>President 
Obama lauded the U.S. military in Baghdad on Tuesday during an unannounced 
visit to Iraq, reminding troops that the next 18 months will be difficult as the United 
States plans to start withdrawing its forces.<br /><br />I was just discussing this 
with your commander, but I think it''s something that all of you know. It is time for 
us to transition to the Iraqis, Obama said, according to a transcript from the White 
House. They need to take responsibility for their country and for their 
sovereignty.<br /><br />And in order for them to do that, they have got to make 
political accommodations. They''re going to have to decide that they want to 
resolve their differences through constitutional means and legal means. They are 
going to have to focus on providing government services that encourage 
confidence among their citizens.<br /><br />A new CNN/Opinion Research 
Corporation poll found that 79 percent of Americans surveyed feel that Obama has 
had a more positive effect on how people in other countries view the U.S. Only 19 
percent of those surveyed thought he''s had a more negative effect.<br /><br 
/>The poll also indicated that only 35 percent of Americans currently approve of 
the U.S. war in Iraq; 65 percent disapprove.<br />Almost seven in 10 Americans 
agree with Obama''s plan to remove most U.S. troops from Iraq by next August, 
while leaving a residual force of between 35,000 and 50,000 troops.</p>', E'obama3.jpg', 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('12', '1', 'reporter', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '16:04:04', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:32:13', 'Tar Heels Tourney Romp Ends With Title', '<p>DETROIT -- The heckling 
always came in summertime pickup games at the Dean Dome, when players from 
North Carolina''s 2005 national-title team would square off against the ringless 
members of the program''s current roster. The worst offenders were <strong>Sean 
May</strong>, <strong>Raymond Felton</strong>, and <strong>Melvin 
Scott</strong>, who tended to end any dispute -- over things as trivial as foul calls 
answer, for the entire careers of current stars <strong>Ty Lawson</strong>, 
<strong>Wayne Ellington</strong> and <strong>Tyler Hansbrough</strong>, had 
been no. And so in the aftermath of Monday''s 89-72 national-championship game 
rout of Michigan State, some of the Tar Heels'' thoughts turned to bragging rights. 
As Lawson said, before breaking into one of his trademark, devilish grins, I mean, 
what can they say now?<br /><br />Nothing, really, given the magnitude of the 
rout: The Tar Heels scored 55 first-half points and led by 21 at the break -- both 
title-game records -- and essentially put the game away in the first 10 minutes. It 
was an epic beatdown that brought Carolina its fifth championship and sucked the 
life out of a record crowd of 72,922 in Detroit, an economically struggling city that 
had rallied around Michigan State''s fairy-tale ride to the final. Ellington was named 
MOP after scoring 19 points, but it was Lawson who was masterful, getting to the 
free-throw line for 18 attempts (and converting 15 of them) to finish with 21 points, 
six assists and an amazing eight steals.<br /><br />On Sunday, he had reminisced 
about acting out approximately 20 different NCAA-championship buzzer-beater 
scenarios on his Fisher Price hoop as a child: Sometimes I needed a three to win 
it, sometimes I was on the free-throw line, sometimes I was making a last-second 
drive when we were down one, Lawson said, and we won every single time. But 
when a writer tried to goad Lawson into saying that he was dreaming of making an 
actual, last-second shot on Monday, he said, I hope it won''t be that close. I like 
blowouts better.<br /><br />A blowout is exactly what Lawson got -- one much 
like the 35-point massacre that occurred the first time the two teams met, on Dec. 
3, in the same building. He and Ellington had talked to each other about not starting 
slow, the way they did against Kansas in last year''s Final Four, when they came 
out shell-shocked and fell behind 40-12. Instead, they were the ones giving 
Michigan State what coach <strong>Tom Izzo</strong> described as that deer-in-
the-headlights look, as the Spartans trailed 21-7, then 32-11, then 46-22 and 55-
34 at half. Izzo''s floor leader, senior guard <strong>Travis Walton</strong>, 
admitted that it was a blur the first five minutes, when they jumped out on us so 
fast.<br /><br />When the Tar Heels finally subbed out their starters, en masse, 
with 1:03 left in the game, they led 89-70, and Lawson still hadn''t broken much of 
a sweat. Close games are nerve-wracking, Lawson said. When you have a 
blowout, everyone has fun. Even my boy Marc -- he nodded toward walk-on 
<strong>Marc Campbell</strong>, who had replaced him -- got in and got some 
time on a national stage.<br /><br />As confetti streamed down from the Ford 
Field ceiling in the aftermath, the player who appeared to be having the most fun 
was the one who had, up to that point, been the most robotic and businesslike. 
Hansbrough, who arrived in <strong>Roy Williams</strong>'' first recruiting class 
following that ''05 national title, beamed as he bear-hugged his coach on the court, 
and later jumped into the arms of Carolina strength coach <strong>Jonas 
Sahratian</strong>, the man responsible for giving Hansbrough the nickname 
Psycho T during his freshman year. This, Sahratian said, was the biggest day of 
Tyler''s life, I think. It''s what he''d been working for.<br /><br />Despite winning 
the Wooden and Naismith Awards as a junior, Hansbrough''s legacy was ultimately 
going to be defined by whether or not he added a banner to the Dean Dome 
rafters. Sitting in the locker room with one of the nets around his neck, and 18 
points and seven rebounds in the box score, Hansbrough felt he had put an 
appropriate coda on his college career, and declared, Whoever said [I''m] not 
validated, I''m validated right now.<br /><br />This win over Michigan State also 
validated the entire North Carolina team, which, like it or not, would have been 
regarded as an underachiever had it not won the national title. The Heels began the 
season as the AP Poll''s unanimous No. 1, and were also heavy title favorites in Las 
Vegas -- but then they started 0-2 in the ACC, with losses to Boston College and 
Wake Forest, and, as Williams said, everybody jumped off the ship. Their defense 
appeared to be lacking with senior specialist <strong>Marcus Ginyard</strong> 
out of the lineup, and Lawson in particular was being shown up by guards such as 
<strong>Tyrese Rice</strong> and <strong>Jeff Teague</strong>. But Williams 
gathered them together in the locker room after that second loss in Winston-Salem, 
and, in front of everyone, asked a question to assistant coach <strong>Steve 
Robinson</strong>, who had also been on Williams'' staff at Kansas: Coach, do 
you remember 1991, what we started out the season?<br /><br />We started 
out 0-2, Robinson said.<br />Do you remember where we finished that 
season?<br />We played Duke for the national championship.<br /><br />And 
so Williams told his team that, if they did what the coaching staff asked, then 
they''d have a chance and be there at the end.<br /><br />The Tar Heels were 
more than just <em>there</em> in this NCAA tournament. They blitzed their way 
through the bracket, beating Radford by 43 in the first round, LSU by 14 in the 
second, Gonzaga by 21 in the Sweet 16, Oklahoma by 12 in the Elite Eight, 
Villanova by 14 in the Final Four and Michigan State by 17 in the final. Carolina only 
trailed its opponents for 10 minutes during the entire dance. They stepped up their 
defense, especially on the perimeter, when it became necessary, and put on an 
exhibition in the title game, forcing the Spartans in to 21 turnovers and just 40 
percent shooting. Carolina lost just four games all season, but, as senior guard 
<strong>Bobby Frasor</strong> said, If we had played D like this all year, it 
could have been special.<br /><br />There was a sense, coming into Monday 
night''s title game, that the Tar Heels might be running up against something 
special -- a pre-ordained, fairy-tale story for the state of Michigan. Legendary 
Spartans point guard <strong>Earvin </strong>Magic<strong> 
Johnson</strong> had called them a team of destiny on Saturday, and it seemed 
that Michigan State could be the right team (having knocked off two-straight No. 1 
seeds), playing at the right time (the 30th anniversary of Magic''s title) in the right 
city (Detroit, which desperately needed an emotional diversion from its failing auto 
industry). When the Spartans ran out of their locker room, point guard 
<strong>Kalin Lucas</strong> -- one of two Motor City products -- yelled, Let''s 
win this for the city!<br /><br />A raucous crowd -- clad in approximately 65 
percent green and white -- was waiting for them in the stands, and those same fans 
lustily booed Carolina when it took the floor. Late Saturday night, after they beat 
Villanova to clinch a trip to the title game against the home-state team, Williams 
had told his players to prepare for the atmosphere at Ford Field as if it were more 
familiar, hostile territory: Coach said, ''It''s like going into Cameron again,'' said 
Frasor, referring to Duke''s home court, where he and Hansbrough are 4-0. And 
for us to make them quiet from the get-go, that was huge.<br /><br />As the 
Spartans faded quickly, so did the power of their fan advantage. It took them until 
the 7:33 mark of the second half to reach the 55 points Carolina had scored in the 
first half, and the building was so quiet with 3:25 left in the game, and Carolina up 
15, that a Michigan State dance team member could be heard saying, C''mon, 
State! We still believe in you! Not many others in the stands seemed to share that 
feeling. Seconds later, Lawson sunk two free throws to extend UNC''s lead to 
17.<br /><br />Carolina came into the game exuding the confidence of a club 
that, as even Johnson admitted in a pregame press conference with 1979 NCAA 
final foe <strong>Larry Bird</strong>, was the best team in basketball, when you 
look at it talent-wise. Izzo said on Sunday that the only way the Spartans could 
win was to have a game plan that altered Carolina''s identity, because, If we play 
good and they play good, we''re losing. The Heels were unfazed by Izzo scheming 
that took them out of their transition game; they managed to win despite scoring 
just four fast-break points -- the same amount that Michigan State did. They 
taunted Sparty, Michigan State''s mascot, in the tunnel beforehand -- 
<strong>Danny Green</strong> yelled in his face a few times, and someone said 
from a distance, Sparty''s just a b----! When the Heels charged out of their locker 
room for the final time before the game began, they created an intimidating 
amount of noise in the tunnel, by clapping in rhythm, barking, and chanting Here 
... We ... Go!<br /><br />From there the Heels went, unfazed by the crowd, and 
steamrolled Michigan State to win what was expected of them in the preseason: the 
national title. After they''d watched <em>One Shining Moment</em> together on 
the floor, with Williams, who had the other net around his neck, standing amongst 
them, they raced back to the locker room to perform a final ceremony. As is 
Williams'' tradition during the dance, there was an empty box drawn on their 
whiteboard prior to the game, waiting to be filled in. What goes inside the box is the 
number of teams left in the NCAA tournament. They''ll typically gather ''round 
Williams to calculate the figure, but this time the math was easy. All that needed to 
be written was a giant number one.</p>', 'champions.jpg', 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('13', '2', 'reporter', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '16:04:17', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '11:33:22', 'Fatal shooting at German courthouse', '<p>Two people were killed and 
two were severely wounded Tuesday in a shooting at a courthouse in Landshut, 
Germany, police said.<br /><br />The gunman, a 60-year-old man, was among 
the dead, Bavarian Police said in a statement.<br /><br />It happened around 
10:15 a.m. (4:15 a.m. ET) during a break in a court proceeding about inheritance, 
Landshut police spokesman Leonard Mayer told CNN.<br /><br />The man began 
shooting once he stepped outside the courtroom, police said.<br /><br />He 
wounded three people before turning the gun on himself, Mayer said. One of the 
victims, a woman, died about 2 1/2 hours later, Bavarian Police said.<br /><br 
/>The lives of the two wounded victims are not in danger, he told CNN.<br /><br 
/>The courthouse has no metal detectors or security checks that would have 
turned up the shooter''s weapon, Mayer said.<br /><br />This latest shooting in 
Germany took place less than a month after a school massacre in the southwestern 
town of Winnenden, in which a total of 16 people were killed.</p>', E'police.jpg', 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('14', '4', 'reporter', '$base_date_year-$base_date_month-$base_date_day 00:00:00', '14:30:49', '2012-07-05 00:00:00', '08:00:47', 'The greatest car chases in movie history', '<p>LONDON, England ? What is it about the car chase? This action staple isrnalmost as old as cinema itself, and the incredible success of ?Fastrn& Furious? the latest high-octane joyride to hit cinema screensrnshows the almost supernatural allure the prospect of a quality chasernexerts on a certain kind of movie-goer.</p>
<p>rn</p>
<p>Although they date back to silent film series like the ?KeystonernCops? in 1912, most agree the modern car chase was born with ?Bullitt?rnin 1968, which features Steve McQueen as the titular hard-nosed coprndetailed to protect a star witness.</p>
<p>rn</p>
<p>In this endlessly imitated sequence, Bullitt screeches up and downrnthe hilly streets of San Francisco at the wheel of a Ford Mustang GT,rnhitting speeds of up to 185km/hour (115 miles/hour). An expertrnautomobile and motorcycle racer in real life, the sequence is all thernmore impressive when you find out McQueen did almost all his own stuntrndriving.</p>
<p>rn</p>
<p>William Friedkin upped the realism in ?The French Connection?rn(1971), which stars a fresh-faced Gene Hackman as New York City policerndetective Jimmy ?Popeye? Doyle who wrestles an increasinglyrnbattered-looking 1971 Pontiac LeMans around the road underneath anrnelevated train he is chasing in Brooklyn.</p>
<p>rn</p>
<p>Many of the scenes in this chase are real, including the car crash,rnwhich was unplanned and caused when a local man drove onto the set notrnrealizing what was happening. The producers later paid for repairs.</p>
<p>rn</p>
<p>Other honorable mentions include: ?Cannonball Run? (1981) for thernspectacular cars including a Ferrari 308 GTS and Aston Martin DB5, ?ThernItalian Job? (1969) for an incredibly hip car chase featuring red,rnwhite and blue Minis that  personify swinging 60s London, StevenrnSpielberg?s 1971 TV movie ?Duel,? which is really just one extendedrnchase scene.</p>
<p>rn</p>
<p>Car chases have gotten progressively more complicated since the 70s,rnwith computer graphics (CGI) allowing filmmakers to conjure up scenesrnthat would have been unthinkable using only stuntmen ? just think ofrnthe impossibly violent crashes in the main chase scene in last year?srn?The Dark Knight.?</p>
<p>rn</p>
<p>Some critics say all this CGI tomfoolery makes chase scenes lookrnfake; that they don?t require the same amount of skill from stuntmen.rnThe dodgy CGI chase scene in Luc Besson?s otherwise brilliant ?ThernFifth Element? (1997) could be held up as an example of this ? althoughrnquite how they would have made taxis really hover 12 stories up isrnanother question entirely.</p>
<p>rn</p>
<p>One of the most famous proponents of this view is Quentin Tarantino,rnwho put his money where his mouth is with ?Death Proof? (2007) whichrnfeatures a long, climactic chase scene featuring stripped down 1969rnDodge Charger and a heavily modified 1970 Dodge Challenger completernwith a girl clinging precariously to the hood ? and absolutely no CGI.</p>
<p>rn</p>
<p>Other contemporary chase scenes that deserve an honorable mentionrninclude the BMW vs. Peugeot car chase through the streets of Paris and,rnnerve-wrackingly, the wrong way up an autoroute in espionage caperrn?Ronin? (1998) and Paul Greengrass? ?Bourne? trilogy.</p>', E'car.jpg', 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('15', '4', 'editor', '2012-05-11 00:00:00', '11:03:33', '2012-05-11 00:00:00', '11:04:37', 'Cirque in town!!', '<p>Cirque in town</p>', E'', 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('16', '2', 'editor', '2012-07-04 00:00:00', '18:11:48', '2012-07-04 00:00:00', '18:11:59', 'Cirque in town', '<p>asdasdasd</p>', E'', 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "public"."news_noticias" VALUES ('17', '2', 'reporter', '2012-07-04 00:00:00', '18:18:15', '2012-07-05 00:00:00', '08:01:12', 'Nautico wins again!', '<p>Nautico 2 x 0 Sport</p>', E'', 'N')
EOT;
		break;
		
		case 'oci805':
		case 'odbc_oracle':
		case 'oci8':
		case 'oci8po':
		case 'oracle':
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "NEWS_NOTICIAS" VALUES (5, 3, 'editor', TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('18991230000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('20120801113613', 'yyyy-mm-dd hh24:mi:ss'), 'The obama agenda', '<p>Obama transition began before Election Day 
Even before Sen. Barack Obama won the presidential election, he was quietly 
building a transition team. On Wednesday, the president-elect met with key 
advisers and began making decisions about his transition team, including who will 
serve as his White House chief of staff. Reports say Obama is close to naming 
Illinois Rep. Rahm Emanuel to that post, but that has not been confirmed</p>', HEXTORAW('6F62616D612E6A7067'), 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "NEWS_NOTICIAS" VALUES (6, 1, 'editor', TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('18991230000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('20120801115200', 'yyyy-mm-dd hh24:mi:ss'), 'Swede Stenson leads Champions tournament', '<p>Henrik Stenson 
fires a 7-under 65 in Shanghai on Thursday for a one-stroke first round lead in the 
HSBC Champions tournament ahead of defending champion Phil Mickelson, Sergio 
Garcia, Anthony Kim and Adam Scott. full story</p>', HEXTORAW('676F6C662E6A7067'), 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "NEWS_NOTICIAS" VALUES (7, 4, 'editor', TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('18991230000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('20120801115044', 'yyyy-mm-dd hh24:mi:ss'), 'Law and Order goes for a record', '<p>The outburst comes from 
Anthony Anderson, who is describing the essential qualities of Kevin Bernard, the 
latest detective to join NBC-TV''s long-running Law & Order. The fun-loving and 
funny Anderson debuted last season as Bernard and resumes busting bad guys on 
Wednesday, 10 p.m. ET, with the season opener.</p>', HEXTORAW('6C61772E6A7067'), 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "NEWS_NOTICIAS" VALUES (8, 3, 'editor', TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('18991230000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('20120801114501', 'yyyy-mm-dd hh24:mi:ss'), 'Ahmadinejad''s visit to Brazil draws criticism', '<p>Iranian President 
Mahmoud Ahmadinejad and Brazilian counterpart Luiz Inacio Lula da Silva signed a 
series of agreements Monday after the controversial Iranian leader arrived at the 
first of three Latin American nations he will visit this week.</p>n<p>Ahmadinejad 
already visited Gambia on a five-nation trip that also will take him to Bolivia and 
Venezuela in South America and Senegal in Africa</p>n<p>...</p>', HEXTORAW('6C756C612E6A7067'), 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "NEWS_NOTICIAS" VALUES (10, 3, 'editor', TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('20120801145857', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('20120801114724', 'yyyy-mm-dd hh24:mi:ss'), 'Obama will change', '<p>Obama sad that in your mandat the United 
States will break and lost the title of First Economy of the World.</p>', HEXTORAW('6F62616D61312E6A7067'), 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO "NEWS_NOTICIAS" VALUES (11, 3, 'editor', TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('20120801160455', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('$base_date_year-$base_date_month-$base_date_day 000000', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('20120801114846', 'yyyy-mm-dd hh24:mi:ss'), ' Obama: ''It is time for us to transition to the Iraqis''', '<p>President 
Obama lauded the U.S. military in Baghdad on Tuesday during an unannounced 
visit to Iraq, reminding troops that the next 18 months will be difficult as the United 
States plans to start withdrawing its forces.<br /><br />I was just discussing this 
with your commander, but I think it''s something that all of you know. It is time for 
us to transition to the Iraqis, Obama said, according to a transcript from the White 
House. They need to take responsibility for their country and for their 
sovereignty.<br /><br />And in order for them to do that, they have got to make 
political accommodations. They''re going to have to decide that they want to 
resolve their differences through constitutional means and legal means. They are 
going to have to focus on providing government services that encourage 
confidence among their citizens.<br /><br />A new CNN/Opinion Research 
Corporation poll found that 79 percent of Americans surveyed feel that Obama has 
had a more positive effect on how people in other countries view the U.S. Only 19 
percent of those surveyed thought he''s had a more negative effect.<br /><br 
/>The poll also indicated that only 35 percent of Americans currently approve of 
the U.S. war in Iraq; 65 percent disapprove.<br />Almost seven in 10 Americans 
agree with Obama''s plan to remove most U.S. troops from Iraq by next August, 
while leaving a residual force of between 35,000 and 50,000 troops.</p>', HEXTORAW('6F62616D61332E6A7067'), 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS VALUES ('12', '1', 'reporter', TO_DATE('$base_date_year-$base_date_month-$base_date_day 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2012-08-01 16:04:04', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-$base_date_day 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2012-08-01 11:32:13', 'YYYY-MM-DD HH24:MI:SS'), 'Tar Heels Tourney Romp Ends With Title', empty_clob(), HexToRaw('6368616D70696F6E732E6A7067'), 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
UPDATE NEWS_NOTICIAS SET NOTICIA_CORPO = CONCAT(NOTICIA_CORPO, 'DETROIT -- The heckling always came in summertime pickup games at the Dean Dome, when players from North Carolina''s 2005 national-title team would square off against the ringless members of the program''s current roster. The worst offenders were Sean May, Raymond Felton, and Melvin Scott, who tended to end any dispute -- over things as trivial as foul calls answer, for the entire careers of current stars Ty Lawson, Wayne Ellington and Tyler Hansbrough, had been no. And so in the aftermath of Monday''s 89-72 national-championship game rout of Michigan State, some of the Tar Heels'' thoughts turned to bragging rights. As Lawson said, before breaking into one of his trademark, devilish grins, I mean, what can they say now?

Nothing, really, given the magnitude of the rout: The Tar Heels scored 55 first-half points and led by 21 at the break -- both title-game records -- and essentially put the game away in the first 10 minutes. It was an epic beatdown that brought Carolina its fifth championship and sucked the life out of a record crowd of 72,922 in Detroit, an economically struggling city that had rallied around Michigan State''s fairy-tale ride to the final. Ellington was named MOP after scoring 19 points, but it was Lawson who was masterful, getting to the free-throw line for 18 attempts (and converting 15 of them) to finish with 21 points, six assists and an amazing eight steals.

On Sunday, he had reminisced about acting out approximately 20 different NCAA-championship buzzer-beater scenarios on his Fisher Price hoop as a child: Sometimes I needed a three to win it, sometimes I was on the free-throw line, sometimes I was making a last-second drive when we were down one, Lawson said, and we won every single time. But when a writer tried to goad Lawson into saying that he was dreaming of making an actual, last-second shot on Monday, he said, I hope it won''t be that close. I like blowouts better.

A blowout is exactly what Lawson got -- one much like the 35-point massacre that occurred the first time the two teams met, on Dec. 3, in the same building. He and Ellington had talked to each other about not starting slow, the way they did against Kansas in last year''s Final Four, when they came out shell-shocked and fell behind 40-12. Instead, they were the ones giving Michigan State what coach Tom Izzo described as that deer-in- the-headlights look, as the Spartans trailed 21-7, then 32-11, then 46-22 and 55- 34 at half. Izzo''s floor leader, senior guard Travis Walton, admitted that it was a blur the first five minutes, when they jumped out on us so fast.

When the Tar Heels finally subbed out their starters, en masse, with 1:03 left in the game, they led 89-70, and Lawson still hadn''t broken much of a sweat. Close games are nerve-wracking, Lawson said. When you have a blowout, everyone has fun. Even my boy Marc -- he nodded toward walk-on Marc Campbell, who had replaced him -- got in and got some time on a national stage.

As confetti streamed down from the Ford Field ceiling in the aftermath, the player who appeared to be having the most fun was the one who had, up to that point, been the most robotic and businesslike. Hansbrough, who arrived in Roy Williams'' first recruiting class following that ''05 national title, beamed as he bear-hugged his coach on the court, and later jumped into the arms of Carolina strength coach Jonas Sahratian, the man responsible for giving Hansbrough the nickname Psycho T ') WHERE NOTICIA_ID = 12
EOT;
			$arr_sqls_inserts[] = <<<EOT
UPDATE NEWS_NOTICIAS SET NOTICIA_CORPO = CONCAT(NOTICIA_CORPO, 'during his freshman year. This, Sahratian said, was the biggest day of Tyler''s life, I think. It''s what he''d been working for.

Despite winning the Wooden and Naismith Awards as a junior, Hansbrough''s legacy was ultimately going to be defined by whether or not he added a banner to the Dean Dome rafters. Sitting in the locker room with one of the nets around his neck, and 18 points and seven rebounds in the box score, Hansbrough felt he had put an appropriate coda on his college career, and declared, Whoever said [I''m] not validated, I''m validated right now.

This win over Michigan State also validated the entire North Carolina team, which, like it or not, would have been regarded as an underachiever had it not won the national title. The Heels began the season as the AP Poll''s unanimous No. 1, and were also heavy title favorites in Las Vegas -- but then they started 0-2 in the ACC, with losses to Boston College and Wake Forest, and, as Williams said, everybody jumped off the ship. Their defense appeared to be lacking with senior specialist Marcus Ginyard out of the lineup, and Lawson in particular was being shown up by guards such as Tyrese Rice and Jeff Teague. But Williams gathered them together in the locker room after that second loss in Winston-Salem, and, in front of everyone, asked a question to assistant coach Steve Robinson, who had also been on Williams'' staff at Kansas: Coach, do you remember 1991, what we started out the season?

We started out 0-2, Robinson said.
Do you remember where we finished that season?
We played Duke for the national championship.

And so Williams told his team that, if they did what the coaching staff asked, then they''d have a chance and be there at the end.

The Tar Heels were more than just there in this NCAA tournament. They blitzed their way through the bracket, beating Radford by 43 in the first round, LSU by 14 in the second, Gonzaga by 21 in the Sweet 16, Oklahoma by 12 in the Elite Eight, Villanova by 14 in the Final Four and Michigan State by 17 in the final. Carolina only trailed its opponents for 10 minutes during the entire dance. They stepped up their defense, especially on the perimeter, when it became necessary, and put on an exhibition in the title game, forcing the Spartans in to 21 turnovers and just 40 percent shooting. Carolina lost just four games all season, but, as senior guard Bobby Frasor said, If we had played D like this all year, it could have been special.

There was a sense, coming into Monday night''s title game, that the Tar Heels might be running up against something special -- a pre-ordained, fairy-tale story for the state of Michigan. Legendary Spartans point guard Earvin Magic Johnson had called them a team of destiny on Saturday, and it seemed that Michigan State could be the right team (having knocked off two-straight No. 1 seeds), playing at the right time (the 30th anniversary of Magic''s title) in the right city (Detroit, which desperately needed an emotional diversion from its failing auto industry). When the Spartans ran out of their locker room, point guard Kalin Lucas -- one of two Motor City products -- yelled, Let''s win this for the city!

A raucous crowd -- clad in approximately 65 percent green and white -- was waiting for them in the stands, and those same fans lustily booed Carolina when it took the floor. Late Saturday night, after they beat Villanova to clinch a trip to the title game against the home-state team, William') WHERE NOTICIA_ID = 12

EOT;
			$arr_sqls_inserts[] = <<<EOT
UPDATE NEWS_NOTICIAS SET NOTICIA_CORPO = CONCAT(NOTICIA_CORPO, 's had told his players to prepare for the atmosphere at Ford Field as if it were more familiar, hostile territory: Coach said, ''It''s like going into Cameron again,'' said Frasor, referring to Duke''s home court, where he and Hansbrough are 4-0. And for us to make them quiet from the get-go, that was huge.

As the Spartans faded quickly, so did the power of their fan advantage. It took them until the 7:33 mark of the second half to reach the 55 points Carolina had scored in the first half, and the building was so quiet with 3:25 left in the game, and Carolina up 15, that a Michigan State dance team member could be heard saying, C''mon, State! We still believe in you! Not many others in the stands seemed to share that feeling. Seconds later, Lawson sunk two free throws to extend UNC''s lead to 17.

Carolina came into the game exuding the confidence of a club that, as even Johnson admitted in a pregame press conference with 1979 NCAA final foe Larry Bird, was the best team in basketball, when you look at it talent-wise. Izzo said on Sunday that the only way the Spartans could win was to have a game plan that altered Carolina''s identity, because, If we play good and they play good, we''re losing. The Heels were unfazed by Izzo scheming that took them out of their transition game; they managed to win despite scoring just four fast-break points -- the same amount that Michigan State did. They taunted Sparty, Michigan State''s mascot, in the tunnel beforehand -- Danny Green yelled in his face a few times, and someone said from a distance, Sparty''s just a b----! When the Heels charged out of their locker room for the final time before the game began, they created an intimidating amount of noise in the tunnel, by clapping in rhythm, barking, and chanting Here ... We ... Go!

From there the Heels went, unfazed by the crowd, and steamrolled Michigan State to win what was expected of them in the preseason: the national title. After they''d watched One Shining Moment together on the floor, with Williams, who had the other net around his neck, standing amongst them, they raced back to the locker room to perform a final ceremony. As is Williams'' tradition during the dance, there was an empty box drawn on their whiteboard prior to the game, waiting to be filled in. What goes inside the box is the number of teams left in the NCAA tournament. They''ll typically gather ''round Williams to calculate the figure, but this time the math was easy. All that needed to be written was a giant number one.') WHERE NOTICIA_ID = 12
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS VALUES ('13', '2', 'reporter', TO_DATE('$base_date_year-$base_date_month-$base_date_day 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2012-08-01 16:04:17', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('$base_date_year-$base_date_month-$base_date_day 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2012-08-01 11:33:22', 'YYYY-MM-DD HH24:MI:SS'), 'Fatal shooting at German courthouse', '<p>Two people were killed and \ntwo were severely wounded Tuesday in a shooting at a courthouse in Landshut, \nGermany, police said.<br /><br />The gunman, a 60-year-old man, was among \nthe dead, Bavarian Police said in a statement.<br /><br />It happened around \n10:15 a.m. (4:15 a.m. ET) during a break in a court proceeding about inheritance, \nLandshut police spokesman Leonard Mayer told CNN.<br /><br />The man began \nshooting once he stepped outside the courtroom, police said.<br /><br />He \nwounded three people before turning the gun on himself, Mayer said. One of the \nvictims, a woman, died about 2 1/2 hours later, Bavarian Police said.<br /><br \n/>The lives of the two wounded victims are not in danger, he told CNN.<br /><br \n/>The courthouse has no metal detectors or security checks that would have \nturned up the shooter\s weapon, Mayer said.<br /><br />This latest shooting in \nGermany took place less than a month after a school massacre in the southwestern \ntown of Winnenden, in which a total of 16 people were killed.</p>', HexToRaw('706F6C6963652E6A7067'), 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS VALUES ('14', '4', 'reporter', TO_DATE('2012-05-11 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2012-08-01 14:30:49', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2012-05-11 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2012-08-01 11:45:03', 'YYYY-MM-DD HH24:MI:SS'), 'The greatest car chases in movie history', '<p>LONDON, England ? What is it about the car chase? This action staple isrnalmost as old as cinema itself, and the incredible success of ?Fastrn& Furious? the latest high-octane joyride to hit cinema screensrnshows the almost supernatural allure the prospect of a quality chasernexerts on a certain kind of movie-goer.</p>
<p>rn</p>
<p>Although they date back to silent film series like the ?KeystonernCops? in 1912, most agree the modern car chase was born with ?Bullitt?rnin 1968, which features Steve McQueen as the titular hard-nosed coprndetailed to protect a star witness.</p>
<p>rn</p>
<p>In this endlessly imitated sequence, Bullitt screeches up and downrnthe hilly streets of San Francisco at the wheel of a Ford Mustang GT,rnhitting speeds of up to 185km/hour (115 miles/hour). An expertrnautomobile and motorcycle racer in real life, the sequence is all thernmore impressive when you find out McQueen did almost all his own stuntrndriving.</p>
<p>rn</p>
<p>William Friedkin upped the realism in ?The French Connection?rn(1971), which stars a fresh-faced Gene Hackman as New York City policerndetective Jimmy ?Popeye? Doyle who wrestles an increasinglyrnbattered-looking 1971 Pontiac LeMans around the road underneath anrnelevated train he is chasing in Brooklyn.</p>
<p>rn</p>
<p>Many of the scenes in this chase are real, including the car crash,rnwhich was unplanned and caused when a local man drove onto the set notrnrealizing what was happening. The producers later paid for repairs.</p>
<p>rn</p>
<p>Other honorable mentions include: ?Cannonball Run? (1981) for thernspectacular cars including a Ferrari 308 GTS and Aston Martin DB5, ?ThernItalian Job? (1969) for an incredibly hip car chase featuring red,rnwhite and blue Minis that personify swinging 60s London, StevenrnSpielberg?s 1971 TV movie ?Duel,? which is really just one extendedrnchase scene.</p>
<p>rn</p>
<p>Car chases have gotten progressively more complicated since the 70s,rnwith computer graphics (CGI) allowing filmmakers to conjure up scenesrnthat would have been unthinkable using only stuntmen ? just think ofrnthe impossibly violent crashes in the main chase scene in last year?srn?The Dark Knight.?</p>
<p>rn</p>
<p>Some critics say all this CGI tomfoolery makes chase scenes lookrnfake; that they don?t require the same amount of skill from stuntmen.rnThe dodgy CGI chase scene in Luc Besson?s otherwise brilliant ?ThernFifth Element? (1997) could be held up as an example of this ? althoughrnquite how they would have made taxis really hover 12 stories up isrnanother question entirely.</p>
<p>rn</p>
<p>One of the most famous proponents of this view is Quentin Tarantino,rnwho put his money where his mouth is with ?Death Proof? (2007) whichrnfeatures a long, climactic chase scene featuring stripped down 1969rnDodge Charger and a heavily modified 1970 Dodge Challenger completernwith a girl clinging precariously to the hood ? and absolutely no CGI.</p>
<p>rn</p>
<p>Other contemporary chase scenes that deserve an honorable mentionrninclude the BMW vs. Peugeot car chase through the streets of Paris and,rnnerve-wrackingly, the wrong way up an autoroute in espionage caperrn?Ronin? (1998) and Paul Greengrass? ?Bourne? trilogy.</p>', HexToRaw('6361722E6A7067'), 'S')
EOT;
		break;
		
		case 'borland_ibase';
		case 'ibase';
		case 'firebird';
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS
VALUES (5, 3, 'editor', '$base_date_year-$base_date_month-$base_date_day', '00:00:00', '$base_date_year-$base_date_month-$base_date_day', '11:36:13', 'The obama agenda', '<p>Obama transition began before Election Day 
Even before Sen. Barack Obama won the presidential election, he was quietly 
building a transition team. On Wednesday, the president-elect met with key 
advisers and began making decisions about his transition team, including who will 
serve as his White House chief of staff. Reports say Obama is close to naming 
Illinois Rep. Rahm Emanuel to that post, but that has not been confirmed</p>', 'obama.jpg', 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS
VALUES (6, 1, 'editor', '$base_date_year-$base_date_month-$base_date_day', '00:00:00', '$base_date_year-$base_date_month-$base_date_day', '11:52:00', 'Swede Stenson leads Champions tournament', '<p>Henrik Stenson 
fires a 7-under 65 in Shanghai on Thursday for a one-stroke first round lead in the 
HSBC Champions tournament ahead of defending champion Phil Mickelson, Sergio 
Garcia, Anthony Kim and Adam Scott. full story</p>', 'golf.jpg', 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS
VALUES (7, 4, 'editor', '$base_date_year-$base_date_month-$base_date_day', '00:00:00', '$base_date_year-$base_date_month-$base_date_day', '11:50:44', 'Law and Order goes for a record', '<p>The outburst comes from 
Anthony Anderson, who is describing the essential qualities of Kevin Bernard, the 
latest detective to join NBC-TV''s long-running Law & Order. The fun-loving and 
funny Anderson debuted last season as Bernard and resumes busting bad guys on 
Wednesday, 10 p.m. ET, with the season opener.</p>', 'law.jpg', 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS
VALUES (8, 3, 'editor', '$base_date_year-$base_date_month-$base_date_day', '00:00:00', '$base_date_year-$base_date_month-$base_date_day', '11:45:01', 'Ahmadinejad''s visit to Brazil draws criticism', '<p>Iranian President 
Mahmoud Ahmadinejad and Brazilian counterpart Luiz Inacio Lula da Silva signed a 
series of agreements Monday after the controversial Iranian leader arrived at the 
first of three Latin American nations he will visit this week.</p>n<p>Ahmadinejad 
already visited Gambia on a five-nation trip that also will take him to Bolivia and 
Venezuela in South America and Senegal in Africa</p>n<p>...</p>', 'lula.jpg', 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS
VALUES (10, 3, 'editor', '$base_date_year-$base_date_month-$base_date_day', '14:58:57', '$base_date_year-$base_date_month-$base_date_day', '11:47:24', 'Obama will change', '<p>Obama sad that in your mandat the United 
States will break and lost the title of First Economy of the World.</p>', 'obama1.jpg', 'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS
VALUES (11, 3, 'editor', '$base_date_year-$base_date_month-$base_date_day', '16:04:55', '$base_date_year-$base_date_month-$base_date_day', '11:48:46', ' Obama: ''It is time for us to transition to the Iraqis''', '<p>President 
Obama lauded the U.S. military in Baghdad on Tuesday during an unannounced 
visit to Iraq, reminding troops that the next 18 months will be difficult as the United 
States plans to start withdrawing its forces.<br /><br />I was just discussing this 
with your commander, but I think it''s something that all of you know. It is time for 
us to transition to the Iraqis, Obama said, according to a transcript from the White 
House. They need to take responsibility for their country and for their 
sovereignty.<br /><br />And in order for them to do that, they have got to make 
political accommodations. They''re going to have to decide that they want to 
resolve their differences through constitutional means and legal means. They are 
going to have to focus on providing government services that encourage 
confidence among their citizens.<br /><br />A new CNN/Opinion Research 
Corporation poll found that 79 percent of Americans surveyed feel that Obama has 
had a more positive effect on how people in other countries view the U.S. Only 19 
percent of those surveyed thought he''s had a more negative effect.<br /><br 
/>The poll also indicated that only 35 percent of Americans currently approve of 
the U.S. war in Iraq; 65 percent disapprove.<br />Almost seven in 10 Americans 
agree with Obama''s plan to remove most U.S. troops from Iraq by next August, 
while leaving a residual force of between 35,000 and 50,000 troops.</p>', 'obama3.jpg', 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS
VALUES (12, 1, 'reporter', '$base_date_year-$base_date_month-$base_date_day', '16:04:04', '$base_date_year-$base_date_month-$base_date_day', '11:32:13', 'Tar Heels Tourney Romp Ends With Title', '<p>DETROIT -- The heckling 
always came in summertime pickup games at the Dean Dome, when players from 
North Carolina''s 2005 national-title team would square off against the ringless 
members of the program''s current roster. The worst offenders were <strong>Sean 
May</strong>, <strong>Raymond Felton</strong>, and <strong>Melvin 
Scott</strong>, who tended to end any dispute -- over things as trivial as foul calls 
answer, for the entire careers of current stars <strong>Ty Lawson</strong>, 
<strong>Wayne Ellington</strong> and <strong>Tyler Hansbrough</strong>, had 
been no. And so in the aftermath of Monday''s 89-72 national-championship game 
rout of Michigan State, some of the Tar Heels'' thoughts turned to bragging rights. 
As Lawson said, before breaking into one of his trademark, devilish grins, I mean, 
what can they say now?<br /><br />Nothing, really, given the magnitude of the 
rout: The Tar Heels scored 55 first-half points and led by 21 at the break -- both 
title-game records -- and essentially put the game away in the first 10 minutes. It 
was an epic beatdown that brought Carolina its fifth championship and sucked the 
life out of a record crowd of 72,922 in Detroit, an economically struggling city that 
had rallied around Michigan State''s fairy-tale ride to the final. Ellington was named 
MOP after scoring 19 points, but it was Lawson who was masterful, getting to the 
free-throw line for 18 attempts (and converting 15 of them) to finish with 21 points, 
six assists and an amazing eight steals.<br /><br />On Sunday, he had reminisced 
about acting out approximately 20 different NCAA-championship buzzer-beater 
scenarios on his Fisher Price hoop as a child: Sometimes I needed a three to win 
it, sometimes I was on the free-throw line, sometimes I was making a last-second 
drive when we were down one, Lawson said, and we won every single time. But 
when a writer tried to goad Lawson into saying that he was dreaming of making an 
actual, last-second shot on Monday, he said, I hope it won''t be that close. I like 
blowouts better.<br /><br />A blowout is exactly what Lawson got -- one much 
like the 35-point massacre that occurred the first time the two teams met, on Dec. 
3, in the same building. He and Ellington had talked to each other about not starting 
slow, the way they did against Kansas in last year''s Final Four, when they came 
out shell-shocked and fell behind 40-12. Instead, they were the ones giving 
Michigan State what coach <strong>Tom Izzo</strong> described as that deer-in-
the-headlights look, as the Spartans trailed 21-7, then 32-11, then 46-22 and 55-
34 at half. Izzo''s floor leader, senior guard <strong>Travis Walton</strong>, 
admitted that it was a blur the first five minutes, when they jumped out on us so 
fast.<br /><br />When the Tar Heels finally subbed out their starters, en masse, 
with 1:03 left in the game, they led 89-70, and Lawson still hadn''t broken much of 
a sweat. Close games are nerve-wracking, Lawson said. When you have a 
blowout, everyone has fun. Even my boy Marc -- he nodded toward walk-on 
<strong>Marc Campbell</strong>, who had replaced him -- got in and got some 
time on a national stage.<br /><br />As confetti streamed down from the Ford 
Field ceiling in the aftermath, the player who appeared to be having the most fun 
was the one who had, up to that point, been the most robotic and businesslike. 
Hansbrough, who arrived in <strong>Roy Williams</strong>'' first recruiting class 
following that ''05 national title, beamed as he bear-hugged his coach on the court, 
and later jumped into the arms of Carolina strength coach <strong>Jonas 
Sahratian</strong>, the man responsible for giving Hansbrough the nickname 
Psycho T during his freshman year. This, Sahratian said, was the biggest day of 
Tyler''s life, I think. It''s what he''d been working for.<br /><br />Despite winning 
the Wooden and Naismith Awards as a junior, Hansbrough''s legacy was ultimately 
going to be defined by whether or not he added a banner to the Dean Dome 
rafters. Sitting in the locker room with one of the nets around his neck, and 18 
points and seven rebounds in the box score, Hansbrough felt he had put an 
appropriate coda on his college career, and declared, Whoever said [I''m] not 
validated, I''m validated right now.<br /><br />This win over Michigan State also 
validated the entire North Carolina team, which, like it or not, would have been 
regarded as an underachiever had it not won the national title. The Heels began the 
season as the AP Poll''s unanimous No. 1, and were also heavy title favorites in Las 
Vegas -- but then they started 0-2 in the ACC, with losses to Boston College and 
Wake Forest, and, as Williams said, everybody jumped off the ship. Their defense 
appeared to be lacking with senior specialist <strong>Marcus Ginyard</strong> 
out of the lineup, and Lawson in particular was being shown up by guards such as 
<strong>Tyrese Rice</strong> and <strong>Jeff Teague</strong>. But Williams 
gathered them together in the locker room after that second loss in Winston-Salem, 
and, in front of everyone, asked a question to assistant coach <strong>Steve 
Robinson</strong>, who had also been on Williams'' staff at Kansas: Coach, do 
you remember 1991, what we started out the season?<br /><br />We started 
out 0-2, Robinson said.<br />Do you remember where we finished that 
season?<br />We played Duke for the national championship.<br /><br />And 
so Williams told his team that, if they did what the coaching staff asked, then 
they''d have a chance and be there at the end.<br /><br />The Tar Heels were 
more than just <em>there</em> in this NCAA tournament. They blitzed their way 
through the bracket, beating Radford by 43 in the first round, LSU by 14 in the 
second, Gonzaga by 21 in the Sweet 16, Oklahoma by 12 in the Elite Eight, 
Villanova by 14 in the Final Four and Michigan State by 17 in the final. Carolina only 
trailed its opponents for 10 minutes during the entire dance. They stepped up their 
defense, especially on the perimeter, when it became necessary, and put on an 
exhibition in the title game, forcing the Spartans in to 21 turnovers and just 40 
percent shooting. Carolina lost just four games all season, but, as senior guard 
<strong>Bobby Frasor</strong> said, If we had played D like this all year, it 
could have been special.<br /><br />There was a sense, coming into Monday 
night''s title game, that the Tar Heels might be running up against something 
special -- a pre-ordained, fairy-tale story for the state of Michigan. Legendary 
Spartans point guard <strong>Earvin </strong>Magic<strong> 
Johnson</strong> had called them a team of destiny on Saturday, and it seemed 
that Michigan State could be the right team (having knocked off two-straight No. 1 
seeds), playing at the right time (the 30th anniversary of Magic''s title) in the right 
city (Detroit, which desperately needed an emotional diversion from its failing auto 
industry). When the Spartans ran out of their locker room, point guard 
<strong>Kalin Lucas</strong> -- one of two Motor City products -- yelled, Let''s 
win this for the city!<br /><br />A raucous crowd -- clad in approximately 65 
percent green and white -- was waiting for them in the stands, and those same fans 
lustily booed Carolina when it took the floor. Late Saturday night, after they beat 
Villanova to clinch a trip to the title game against the home-state team, Williams 
had told his players to prepare for the atmosphere at Ford Field as if it were more 
familiar, hostile territory: Coach said, ''It''s like going into Cameron again,'' said 
Frasor, referring to Duke''s home court, where he and Hansbrough are 4-0. And 
for us to make them quiet from the get-go, that was huge.<br /><br />As the 
Spartans faded quickly, so did the power of their fan advantage. It took them until 
the 7:33 mark of the second half to reach the 55 points Carolina had scored in the 
first half, and the building was so quiet with 3:25 left in the game, and Carolina up 
15, that a Michigan State dance team member could be heard saying, C''mon, 
State! We still believe in you! Not many others in the stands seemed to share that 
feeling. Seconds later, Lawson sunk two free throws to extend UNC''s lead to 
17.<br /><br />Carolina came into the game exuding the confidence of a club 
that, as even Johnson admitted in a pregame press conference with 1979 NCAA 
final foe <strong>Larry Bird</strong>, was the best team in basketball, when you 
look at it talent-wise. Izzo said on Sunday that the only way the Spartans could 
win was to have a game plan that altered Carolina''s identity, because, If we play 
good and they play good, we''re losing. The Heels were unfazed by Izzo scheming 
that took them out of their transition game; they managed to win despite scoring 
just four fast-break points -- the same amount that Michigan State did. They 
taunted Sparty, Michigan State''s mascot, in the tunnel beforehand -- 
<strong>Danny Green</strong> yelled in his face a few times, and someone said 
from a distance, Sparty''s just a b----! When the Heels charged out of their locker 
room for the final time before the game began, they created an intimidating 
amount of noise in the tunnel, by clapping in rhythm, barking, and chanting Here 
... We ... Go!<br /><br />From there the Heels went, unfazed by the crowd, and 
steamrolled Michigan State to win what was expected of them in the preseason: the 
national title. After they''d watched <em>One Shining Moment</em> together on 
the floor, with Williams, who had the other net around his neck, standing amongst 
them, they raced back to the locker room to perform a final ceremony. As is 
Williams'' tradition during the dance, there was an empty box drawn on their 
whiteboard prior to the game, waiting to be filled in. What goes inside the box is the 
number of teams left in the NCAA tournament. They''ll typically gather ''round 
Williams to calculate the figure, but this time the math was easy. All that needed to 
be written was a giant number one.</p>', 'champions.jpg', 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS
VALUES (13, 2, 'reporter', '$base_date_year-$base_date_month-$base_date_day', '16:04:17', '$base_date_year-$base_date_month-$base_date_day', '11:33:22', 'Fatal shooting at German courthouse', '<p>Two people were killed and 
two were severely wounded Tuesday in a shooting at a courthouse in Landshut, 
Germany, police said.<br /><br />The gunman, a 60-year-old man, was among 
the dead, Bavarian Police said in a statement.<br /><br />It happened around 
10:15 a.m. (4:15 a.m. ET) during a break in a court proceeding about inheritance, 
Landshut police spokesman Leonard Mayer told CNN.<br /><br />The man began 
shooting once he stepped outside the courtroom, police said.<br /><br />He 
wounded three people before turning the gun on himself, Mayer said. One of the 
victims, a woman, died about 2 1/2 hours later, Bavarian Police said.<br /><br 
/>The lives of the two wounded victims are not in danger, he told CNN.<br /><br 
/>The courthouse has no metal detectors or security checks that would have 
turned up the shooter''s weapon, Mayer said.<br /><br />This latest shooting in 
Germany took place less than a month after a school massacre in the southwestern 
town of Winnenden, in which a total of 16 people were killed.</p>', 'police.jpg', 'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
INSERT INTO NEWS_NOTICIAS
VALUES (14, 4, 'reporter', '2012-05-11', '14:30:49', '2012-05-11', '11:45:03', 'The greatest car chases in movie history', '<p>LONDON, England ? What is it about the car chase? This action staple isrnalmost as old as cinema itself, and the incredible success of ?Fastrn& Furious? the latest high-octane joyride to hit cinema screensrnshows the almost supernatural allure the prospect of a quality chasernexerts on a certain kind of movie-goer.</p>
<p>rn</p>
<p>Although they date back to silent film series like the ?KeystonernCops? in 1912, most agree the modern car chase was born with ?Bullitt?rnin 1968, which features Steve McQueen as the titular hard-nosed coprndetailed to protect a star witness.</p>
<p>rn</p>
<p>In this endlessly imitated sequence, Bullitt screeches up and downrnthe hilly streets of San Francisco at the wheel of a Ford Mustang GT,rnhitting speeds of up to 185km/hour (115 miles/hour). An expertrnautomobile and motorcycle racer in real life, the sequence is all thernmore impressive when you find out McQueen did almost all his own stuntrndriving.</p>
<p>rn</p>
<p>William Friedkin upped the realism in ?The French Connection?rn(1971), which stars a fresh-faced Gene Hackman as New York City policerndetective Jimmy ?Popeye? Doyle who wrestles an increasinglyrnbattered-looking 1971 Pontiac LeMans around the road underneath anrnelevated train he is chasing in Brooklyn.</p>
<p>rn</p>
<p>Many of the scenes in this chase are real, including the car crash,rnwhich was unplanned and caused when a local man drove onto the set notrnrealizing what was happening. The producers later paid for repairs.</p>
<p>rn</p>
<p>Other honorable mentions include: ?Cannonball Run? (1981) for thernspectacular cars including a Ferrari 308 GTS and Aston Martin DB5, ?ThernItalian Job? (1969) for an incredibly hip car chase featuring red,rnwhite and blue Minis that personify swinging 60s London, StevenrnSpielberg?s 1971 TV movie ?Duel,? which is really just one extendedrnchase scene.</p>
<p>rn</p>
<p>Car chases have gotten progressively more complicated since the 70s,rnwith computer graphics (CGI) allowing filmmakers to conjure up scenesrnthat would have been unthinkable using only stuntmen ? just think ofrnthe impossibly violent crashes in the main chase scene in last year?srn?The Dark Knight.?</p>
<p>rn</p>
<p>Some critics say all this CGI tomfoolery makes chase scenes lookrnfake; that they don?t require the same amount of skill from stuntmen.rnThe dodgy CGI chase scene in Luc Besson?s otherwise brilliant ?ThernFifth Element? (1997) could be held up as an example of this ? althoughrnquite how they would have made taxis really hover 12 stories up isrnanother question entirely.</p>
<p>rn</p>
<p>One of the most famous proponents of this view is Quentin Tarantino,rnwho put his money where his mouth is with ?Death Proof? (2007) whichrnfeatures a long, climactic chase scene featuring stripped down 1969rnDodge Charger and a heavily modified 1970 Dodge Challenger completernwith a girl clinging precariously to the hood ? and absolutely no CGI.</p>
<p>rn</p>
<p>Other contemporary chase scenes that deserve an honorable mentionrninclude the BMW vs. Peugeot car chase through the streets of Paris and,rnnerve-wrackingly, the wrong way up an autoroute in espionage caperrn?Ronin? (1998) and Paul Greengrass? ?Bourne? trilogy.</p>', 'car.jpg', 'S')
EOT;

		break;
		
		case 'ado_mssql':
		case 'pdo_sqlsrv':
		case 'mssqlnative':
		case 'odbc_mssql':
		case 'mssql':
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
INSERT INTO dbo.news_noticias (noticia_id, categoria_id, reporter_id, noticia_data_noticia, noticia_hora_noticia, noticia_data_pub, noticia_hora_pub, noticia_titulo, noticia_corpo, noticia_img, noticia_flag_man_editorial) VALUES (N'5', N'3', N'editor', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1899-12-30 00:00:00.000', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 11:36:13.000', N'The obama agenda', N'<p>Obama transition began before Election Day Even before Sen. Barack Obama won the presidential election, he was quietly building a transition team. On Wednesday, the president-elect met with key advisers and began making decisions about his transition team, including who will serve as his White House chief of staff. Reports say Obama is close to naming Illinois Rep. Rahm Emanuel to that post, but that has not been confirmed</p>', 0x6F62616D612E6A7067, N'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
INSERT INTO dbo.news_noticias (noticia_id, categoria_id, reporter_id, noticia_data_noticia, noticia_hora_noticia, noticia_data_pub, noticia_hora_pub, noticia_titulo, noticia_corpo, noticia_img, noticia_flag_man_editorial) VALUES (N'6', N'1', N'editor', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1899-12-30 00:00:00.000', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 11:52:00.000', N'Swede Stenson leads Champions tournament', N'<p>Henrik Stenson fires a 7-under 65 in Shanghai on Thursday for a one-stroke first round lead in the HSBC Champions tournament ahead of defending champion Phil Mickelson, Sergio Garcia, Anthony Kim and Adam Scott. full story</p>', 0x676F6C662E6A7067, N'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
INSERT INTO dbo.news_noticias (noticia_id, categoria_id, reporter_id, noticia_data_noticia, noticia_hora_noticia, noticia_data_pub, noticia_hora_pub, noticia_titulo, noticia_corpo, noticia_img, noticia_flag_man_editorial) VALUES (N'7', N'4', N'editor', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1899-12-30 00:00:00.000', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 11:50:44.000', N'Law and Order goes for a record', N'<p>The outburst comes from Anthony Anderson, who is describing the essential qualities of Kevin Bernard, the latest detective to join NBC-TV''s long-running Law & Order. The fun-loving and funny Anderson debuted last season as Bernard and resumes busting bad guys on Wednesday, 10 p.m. ET, with the season opener.</p>', 0x6C61772E6A7067, N'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
INSERT INTO dbo.news_noticias (noticia_id, categoria_id, reporter_id, noticia_data_noticia, noticia_hora_noticia, noticia_data_pub, noticia_hora_pub, noticia_titulo, noticia_corpo, noticia_img, noticia_flag_man_editorial) VALUES (N'8', N'3', N'editor', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1899-12-30 00:00:00.000', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 11:45:01.000', N'Ahmadinejad''s visit to Brazil draws criticism', N'<p>Iranian President Mahmoud Ahmadinejad and Brazilian counterpart Luiz Inacio Lula da Silva signed a series of agreements Monday after the controversial Iranian leader arrived at the first of three Latin American nations he will visit this week.</p>n<p>Ahmadinejad already visited Gambia on a five-nation trip that also will take him to Bolivia and Venezuela in South America and Senegal in Africa</p>n<p>...</p>', 0x6C756C612E6A7067, N'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
INSERT INTO dbo.news_noticias (noticia_id, categoria_id, reporter_id, noticia_data_noticia, noticia_hora_noticia, noticia_data_pub, noticia_hora_pub, noticia_titulo, noticia_corpo, noticia_img, noticia_flag_man_editorial) VALUES (N'10', N'3', N'editor', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 14:58:57.000', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 11:47:24.000', N'Obama will change', N'<p>Obama sad that in your mandat the United States will break and lost the title of First Economy of the World.</p>', 0x6F62616D61312E6A7067, N'N')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
INSERT INTO dbo.news_noticias (noticia_id, categoria_id, reporter_id, noticia_data_noticia, noticia_hora_noticia, noticia_data_pub, noticia_hora_pub, noticia_titulo, noticia_corpo, noticia_img, noticia_flag_man_editorial) VALUES (N'11', N'3', N'editor', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 16:04:55.000', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 11:48:46.000', N' Obama: ''It is time for us to transition to the Iraqis''', N'<p>President Obama lauded the U.S. military in Baghdad on Tuesday during an unannounced visit to Iraq, reminding troops that the next 18 months will be difficult as the United States plans to start withdrawing its forces.<br /><br />I was just discussing this with your commander, but I think it''s something that all of you know. It is time for us to transition to the Iraqis, Obama said, according to a transcript from the White House. They need to take responsibility for their country and for their sovereignty.<br /><br />And in order for them to do that, they have got to make political accommodations. They''re going to have to decide that they want to resolve their differences through constitutional means and legal means. They are going to have to focus on providing government services that encourage confidence among their citizens.<br /><br />A new CNN/Opinion Research Corporation poll found that 79 percent of Americans surveyed feel that Obama has had a more positive effect on how people in other countries view the U.S. Only 19 percent of those surveyed thought he''s had a more negative effect.<br /><br />The poll also indicated that only 35 percent of Americans currently approve of the U.S. war in Iraq; 65 percent disapprove.<br />Almost seven in 10 Americans agree with Obama''s plan to remove most U.S. troops from Iraq by next August, while leaving a residual force of between 35,000 and 50,000 troops.</p>', 0x6F62616D61332E6A7067, N'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
INSERT INTO dbo.news_noticias (noticia_id, categoria_id, reporter_id, noticia_data_noticia, noticia_hora_noticia, noticia_data_pub, noticia_hora_pub, noticia_titulo, noticia_corpo, noticia_img, noticia_flag_man_editorial) VALUES (N'12', N'1', N'reporter', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 16:04:04.000', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 11:32:13.000', N'Tar Heels Tourney Romp Ends With Title', N'<p>DETROIT -- The heckling always came in summertime pickup games at the Dean Dome, when players from North Carolina''s 2005 national-title team would square off against the ringless members of the program''s current roster. The worst offenders were <strong>Sean May</strong>, <strong>Raymond Felton</strong>, and <strong>Melvin Scott</strong>, who tended to end any dispute -- over things as trivial as foul calls answer, for the entire careers of current stars <strong>Ty Lawson</strong>, <strong>Wayne Ellington</strong> and <strong>Tyler Hansbrough</strong>, had been no. And so in the aftermath of Monday''s 89-72 national-championship game rout of Michigan State, some of the Tar Heels'' thoughts turned to bragging rights. As Lawson said, before breaking into one of his trademark, devilish grins, I mean, what can they say now?<br /><br />Nothing, really, given the magnitude of the rout: The Tar Heels scored 55 first-half points and led by 21 at the break -- both title-game records -- and essentially put the game away in the first 10 minutes. It was an epic beatdown that brought Carolina its fifth championship and sucked the life out of a record crowd of 72,922 in Detroit, an economically struggling city that had rallied around Michigan State''s fairy-tale ride to the final. Ellington was named MOP after scoring 19 points, but it was Lawson who was masterful, getting to the free-throw line for 18 attempts (and converting 15 of them) to finish with 21 points, six assists and an amazing eight steals.<br /><br />On Sunday, he had reminisced about acting out approximately 20 different NCAA-championship buzzer-beater scenarios on his Fisher Price hoop as a child: Sometimes I needed a three to win it, sometimes I was on the free-throw line, sometimes I was making a last-second drive when we were down one, Lawson said, and we won every single time. But when a writer tried to goad Lawson into saying that he was dreaming of making an actual, last-second shot on Monday, he said, I hope it won''t be that close. I like blowouts better.<br /><br />A blowout is exactly what Lawson got -- one much like the 35-point massacre that occurred the first time the two teams met, on Dec. 3, in the same building. He and Ellington had talked to each other about not starting slow, the way they did against Kansas in last year''s Final Four, when they came out shell-shocked and fell behind 40-12. Instead, they were the ones giving Michigan State what coach <strong>Tom Izzo</strong> described as that deer-in- the-headlights look, as the Spartans trailed 21-7, then 32-11, then 46-22 and 55- 34 at half. Izzo''s floor leader, senior guard <strong>Travis Walton</strong>, admitted that it was a blur the first five minutes, when they jumped out on us so fast.<br /><br />When the Tar Heels finally subbed out their starters, en masse, with 1:03 left in the game, they led 89-70, and Lawson still hadn''t broken much of a sweat. Close games are nerve-wracking, Lawson said. When you have a blowout, everyone has fun. Even my boy Marc -- he nodded toward walk-on <strong>Marc Campbell</strong>, who had replaced him -- got in and got some time on a national stage.<br /><br />As confetti streamed down from the Ford Field ceiling in the aftermath, the player who appeared to be having the most fun was the one who had, up to that point, been the most robotic and businesslike. Hansbrough, who arrived in <strong>Roy Williams</strong>'' first recruiting class following that ''05 national title, beamed as he bear-hugged his coach on the court, and later jumped into the arms of Carolina strength coach <strong>Jonas Sahratian</strong>, the man responsible for giving Hansbrough the nickname Psycho T during his freshman year. This, Sahratian said, was the biggest day of Tyler''s life, I think. It''s what he''d been working for.<br /><br />Despite winning the Wooden and Naismith Awards as a junior, Hansbrough''s legacy was ultimately going to be defined by whether or not he added a banner to the Dean Dome rafters. Sitting in the locker room with one of the nets around his neck, and 18 points and seven rebounds in the box score, Hansbrough felt he had put an appropriate coda on his college career, and declared, Whoever said [I''m] not validated, I''m validated right now.<br /><br />This win over Michigan State also validated the entire North Carolina team, which, like it or not, would have been regarded as an underachiever had it not won the national title. The Heels began the season as the AP Poll''s unanimous No. 1, and were also heavy title favorites in Las Vegas -- but then they started 0-2 in the ACC, with losses to Boston College and Wake Forest, and, as Williams said, everybody jumped off the ship. Their defense appeared to be lacking with senior specialist <strong>Marcus Ginyard</strong> out of the lineup, and Lawson in particular was being shown up by guards such as <strong>Tyrese Rice</strong> and <strong>Jeff Teague</strong>. But Williams gathered them together in the locker room after that second loss in Winston-Salem, and, in front of everyone, asked a question to assistant coach <strong>Steve Robinson</strong>, who had also been on Williams'' staff at Kansas: Coach, do you remember 1991, what we started out the season?<br /><br />We started out 0-2, Robinson said.<br />Do you remember where we finished that season?<br />We played Duke for the national championship.<br /><br />And so Williams told his team that, if they did what the coaching staff asked, then they''d have a chance and be there at the end.<br /><br />The Tar Heels were more than just <em>there</em> in this NCAA tournament. They blitzed their way through the bracket, beating Radford by 43 in the first round, LSU by 14 in the second, Gonzaga by 21 in the Sweet 16, Oklahoma by 12 in the Elite Eight, Villanova by 14 in the Final Four and Michigan State by 17 in the final. Carolina only trailed its opponents for 10 minutes during the entire dance. They stepped up their defense, especially on the perimeter, when it became necessary, and put on an exhibition in the title game, forcing the Spartans in to 21 turnovers and just 40 percent shooting. Carolina lost just four games all season, but, as senior guard <strong>Bobby Frasor</strong> said, If we had played D like this all year, it could have been special.<br /><br />There was a sense, coming into Monday night''s title game, that the Tar Heels might be running up against something special -- a pre-ordained, fairy-tale story for the state of Michigan. Legendary Spartans point guard <strong>Earvin </strong>Magic<strong> Johnson</strong> had called them a team of destiny on Saturday, and it seemed that Michigan State could be the right team (having knocked off two-straight No. 1 seeds), playing at the right time (the 30th anniversary of Magic''s title) in the right city (Detroit, which desperately needed an emotional diversion from its failing auto industry). When the Spartans ran out of their locker room, point guard <strong>Kalin Lucas</strong> -- one of two Motor City products -- yelled, Let''s win this for the city!<br /><br />A raucous crowd -- clad in approximately 65 percent green and white -- was waiting for them in the stands, and those same fans lustily booed Carolina when it took the floor. Late Saturday night, after they beat Villanova to clinch a trip to the title game against the home-state team, Williams had told his players to prepare for the atmosphere at Ford Field as if it were more familiar, hostile territory: Coach said, ''It''s like going into Cameron again,'' said Frasor, referring to Duke''s home court, where he and Hansbrough are 4-0. And for us to make them quiet from the get-go, that was huge.<br /><br />As the Spartans faded quickly, so did the power of their fan advantage. It took them until the 7:33 mark of the second half to reach the 55 points Carolina had scored in the first half, and the building was so quiet with 3:25 left in the game, and Carolina up 15, that a Michigan State dance team member could be heard saying, C''mon, State! We still believe in you! Not many others in the stands seemed to share that feeling. Seconds later, Lawson sunk two free throws to extend UNC''s lead to 17.<br /><br />Carolina came into the game exuding the confidence of a club that, as even Johnson admitted in a pregame press conference with 1979 NCAA final foe <strong>Larry Bird</strong>, was the best team in basketball, when you look at it talent-wise. Izzo said on Sunday that the only way the Spartans could win was to have a game plan that altered Carolina''s identity, because, If we play good and they play good, we''re losing. The Heels were unfazed by Izzo scheming that took them out of their transition game; they managed to win despite scoring just four fast-break points -- the same amount that Michigan State did. They taunted Sparty, Michigan State''s mascot, in the tunnel beforehand -- <strong>Danny Green</strong> yelled in his face a few times, and someone said from a distance, Sparty''s just a b----! When the Heels charged out of their locker room for the final time before the game began, they created an intimidating amount of noise in the tunnel, by clapping in rhythm, barking, and chanting Here ... We ... Go!<br /><br />From there the Heels went, unfazed by the crowd, and steamrolled Michigan State to win what was expected of them in the preseason: the national title. After they''d watched <em>One Shining Moment</em> together on the floor, with Williams, who had the other net around his neck, standing amongst them, they raced back to the locker room to perform a final ceremony. As is Williams'' tradition during the dance, there was an empty box drawn on their whiteboard prior to the game, waiting to be filled in. What goes inside the box is the number of teams left in the NCAA tournament. They''ll typically gather ''round Williams to calculate the figure, but this time the math was easy. All that needed to be written was a giant number one.</p>', 0x6368616D70696F6E732E6A7067, N'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
INSERT INTO dbo.news_noticias (noticia_id, categoria_id, reporter_id, noticia_data_noticia, noticia_hora_noticia, noticia_data_pub, noticia_hora_pub, noticia_titulo, noticia_corpo, noticia_img, noticia_flag_man_editorial) VALUES (N'13', N'2', N'reporter', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 16:04:17.000', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 11:33:22.000', N'Fatal shooting at German courthouse', N'<p>Two people were killed and two were severely wounded Tuesday in a shooting at a courthouse in Landshut, Germany, police said.<br /><br />The gunman, a 60-year-old man, was among the dead, Bavarian Police said in a statement.<br /><br />It happened around 10:15 a.m. (4:15 a.m. ET) during a break in a court proceeding about inheritance, Landshut police spokesman Leonard Mayer told CNN.<br /><br />The man began shooting once he stepped outside the courtroom, police said.<br /><br />He wounded three people before turning the gun on himself, Mayer said. One of the victims, a woman, died about 2 1/2 hours later, Bavarian Police said.<br /><br />The lives of the two wounded victims are not in danger, he told CNN.<br /><br />The courthouse has no metal detectors or security checks that would have turned up the shooter''s weapon, Mayer said.<br /><br />This latest shooting in Germany took place less than a month after a school massacre in the southwestern town of Winnenden, in which a total of 16 people were killed.</p>', 0x706F6C6963652E6A7067, N'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
INSERT INTO dbo.news_noticias (noticia_id, categoria_id, reporter_id, noticia_data_noticia, noticia_hora_noticia, noticia_data_pub, noticia_hora_pub, noticia_titulo, noticia_corpo, noticia_img, noticia_flag_man_editorial) VALUES (N'14', N'4', N'reporter', N'$base_date_year-$base_date_month-$base_date_day 00:00:00.000', N'1900-01-01 14:30:49.000', N'2012-07-02 00:00:00.000', N'1900-01-01 11:45:03.000', N'The greatest car chases in movie history', N'<p>LONDON, England ? What is it about the car chase? This action staple isrnalmost as old as cinema itself, and the incredible success of ?Fastrn& Furious? the latest high-octane joyride to hit cinema screensrnshows the almost supernatural allure the prospect of a quality chasernexerts on a certain kind of movie-goer.</p> <p>rn</p> <p>Although they date back to silent film series like the ?KeystonernCops? in 1912, most agree the modern car chase was born with ?Bullitt?rnin 1968, which features Steve McQueen as the titular hard-nosed coprndetailed to protect a star witness.</p> <p>rn</p> <p>In this endlessly imitated sequence, Bullitt screeches up and downrnthe hilly streets of San Francisco at the wheel of a Ford Mustang GT,rnhitting speeds of up to 185km/hour (115 miles/hour). An expertrnautomobile and motorcycle racer in real life, the sequence is all thernmore impressive when you find out McQueen did almost all his own stuntrndriving.</p> <p>rn</p> <p>William Friedkin upped the realism in ?The French Connection?rn(1971), which stars a fresh-faced Gene Hackman as New York City policerndetective Jimmy ?Popeye? Doyle who wrestles an increasinglyrnbattered-looking 1971 Pontiac LeMans around the road underneath anrnelevated train he is chasing in Brooklyn.</p> <p>rn</p> <p>Many of the scenes in this chase are real, including the car crash,rnwhich was unplanned and caused when a local man drove onto the set notrnrealizing what was happening. The producers later paid for repairs.</p> <p>rn</p> <p>Other honorable mentions include: ?Cannonball Run? (1981) for thernspectacular cars including a Ferrari 308 GTS and Aston Martin DB5, ?ThernItalian Job? (1969) for an incredibly hip car chase featuring red,rnwhite and blue Minis that personify swinging 60s London, StevenrnSpielberg?s 1971 TV movie ?Duel,? which is really just one extendedrnchase scene.</p> <p>rn</p> <p>Car chases have gotten progressively more complicated since the 70s,rnwith computer graphics (CGI) allowing filmmakers to conjure up scenesrnthat would have been unthinkable using only stuntmen ? just think ofrnthe impossibly violent crashes in the main chase scene in last year?srn?The Dark Knight.?</p> <p>rn</p> <p>Some critics say all this CGI tomfoolery makes chase scenes lookrnfake; that they don?t require the same amount of skill from stuntmen.rnThe dodgy CGI chase scene in Luc Besson?s otherwise brilliant ?ThernFifth Element? (1997) could be held up as an example of this ? althoughrnquite how they would have made taxis really hover 12 stories up isrnanother question entirely.</p> <p>rn</p> <p>One of the most famous proponents of this view is Quentin Tarantino,rnwho put his money where his mouth is with ?Death Proof? (2007) whichrnfeatures a long, climactic chase scene featuring stripped down 1969rnDodge Charger and a heavily modified 1970 Dodge Challenger completernwith a girl clinging precariously to the hood ? and absolutely no CGI.</p> <p>rn</p> <p>Other contemporary chase scenes that deserve an honorable mentionrninclude the BMW vs. Peugeot car chase through the streets of Paris and,rnnerve-wrackingly, the wrong way up an autoroute in espionage caperrn?Ronin? (1998) and Paul Greengrass? ?Bourne? trilogy.</p>', 0x6361722E6A7067, N'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
INSERT INTO dbo.news_noticias (noticia_id, categoria_id, reporter_id, noticia_data_noticia, noticia_hora_noticia, noticia_data_pub, noticia_hora_pub, noticia_titulo, noticia_corpo, noticia_img, noticia_flag_man_editorial) VALUES (N'15', N'4', N'editor', N'2012-05-11 00:00:00.000', N'1900-01-01 11:03:33.000', N'2012-05-11 00:00:00.000', N'1900-01-01 11:04:37.000', N'Cirque in town!!', N'<p>Cirque in town</p>', 0x, N'S')
EOT;
			$arr_sqls_inserts[] = <<<EOT
SET DATEFORMAT ymd;
INSERT INTO dbo.news_noticias (noticia_id, categoria_id, reporter_id, noticia_data_noticia, noticia_hora_noticia, noticia_data_pub, noticia_hora_pub, noticia_titulo, noticia_corpo, noticia_img, noticia_flag_man_editorial) VALUES (N'16', N'1', N'editor', N'2012-07-02 00:00:00.000', N'1900-01-01 11:19:34.000', N'2012-07-02 00:00:00.000', N'1900-01-01 11:43:30.000', N'Nautico wins again!', N'<p>one more time, we can''t belive.</p>', 0x, N'S')
EOT;
		break;
	}
	
	if(is_array($arr_sqls_inserts) && !empty($arr_sqls_inserts))
	{
		foreach($arr_sqls_inserts as $sql)
		{
			sc_exec_sql($sql);
		}
	}
}
}
?>